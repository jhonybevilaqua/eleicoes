// gctse GRAFICOS - desenha os graficos de Presidente a partir de dados.js.
// Tudo e SVG: escala para qualquer tela e vira PNG sem perder qualidade.
(function () {
  "use strict";

  // Paleta categorica validada contra o fundo #0b1220 (8 cores; as 3
  // primeiras passam tambem comparando todas contra todas - as do mapa).
  var PALETA = ["#2b84ff", "#ef5b16", "#00aa76", "#c98400", "#e8478a", "#159c15", "#9078ff", "#f05252"];
  var C = {
    fundo: "#0b1220", texto: "#ffffff", apagado: "#8ea3bd", apagado2: "#6b7f99",
    trilho: "#283548", linha: "#1f2b3c", vermelho: "#d03b3b", verde: "#16b216",
    destaque: "#2b84ff", validos: "#7398cf", brancos: "#dfe6f2", nulos: "#e8964a",
    abstencao: "#7f8ca3", comparec: "#2b84ff", semDado: "#6b7688", outros: "#7f8ca3"
  };
  var FONTE = "'Segoe UI', 'DejaVu Sans', Arial, sans-serif";
  // Cor do PARTIDO (pedido da redacao): PT vermelho, PL azul. Os demais pela
  // paleta, sem o azul e o vermelho (para nao confundir com PL e PT).
  // config-graficos.json "cores" continua mandando por cima de tudo.
  var CORES_PARTIDO = { "PT": "#e5132d", "PL": "#2f6bff" };
  var PALETA_OUTROS = ["#ef5b16", "#00aa76", "#c98400", "#e8478a", "#159c15", "#9078ff"];
  // ARTE da TV: fundo (web\arte\fundo-h.jpg / fundo-v.jpg) e logo ELEICOES
  // 2026 (web\arte\logo.png) no canto superior direito. Sem o arquivo,
  // fica o fundo liso de sempre e nenhuma logo.
  // Fotos guardadas pelo GUARDAR-DADOS-TSE.bat (web\fotos-tse): usadas no
  // lugar da do TSE quando existem (o TSE pode ficar lento ou fora no dia).
  function viaLocal(url) {
    var L = window.GCTSE_FOTOS_LOCAIS, m = L ? /\/fotos\/([a-z]{2})\/(\d+)\.jpe?g$/i.exec(url) : null;
    return m && L[m[1].toLowerCase() + "/" + m[2]] ? L[m[1].toLowerCase() + "/" + m[2]] : url;
  }
  function arteFundo(W, H) {
    var v = H > W ? "v" : "h";
    return '<image href="arte/fundo-' + v + '.jpg" data-arte="fundo-' + v + '" x="0" y="0" width="' + W + '" height="' + H +
      '" preserveAspectRatio="xMidYMid slice"/>';
  }
  function arteLogo(W, H, margem) {
    var v = H > W, w = v ? 100 : 182, h = Math.round(w * 355 / 1044), x = W - margem - w, y = v ? 4 : 14;
    return '<image href="arte/logo.png" data-arte="logo" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '"/>';
  }


  // ---------------------------------------------------------------- formatos
  function esc(t) {
    return String(t == null ? "" : t).replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function pct(v) { return (v == null || isNaN(v)) ? "—" : Number(v).toFixed(2).replace(".", ",") + "%"; }
  function inteiro(v) {
    if (v == null || isNaN(v)) return "—";
    return Math.round(v).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  }
  function corta(t, n) { t = String(t || ""); return t.length > n ? t.slice(0, n - 1) + "…" : t; }

  // ----------------------------------------------------------------- dados
  // O Windows PowerShell 5.1 as vezes grava lista como {"value":[...],"Count":n}:
  // aceita os dois jeitos.
  function comoLista(x) { return Array.isArray(x) ? x : (x && Array.isArray(x.value) ? x.value : []); }
  function normalizar(d) {
    if (!d || d.__ok) return d;
    [d.br].concat(Object.keys(d.ufs || {}).map(function (k) { return d.ufs[k]; })).forEach(function (a) {
      if (a && a.tem) a.candidatos = comoLista(a.candidatos);
    });
    d.__ok = true;
    return d;
  }
  function D() { return normalizar(window.GCTSE_DADOS) || { modo: "OFICIAL", br: { tem: false }, ufs: {} }; }
  function br() { var b = D().br; return (b && b.tem) ? b : null; }
  function uf(u) { var x = (D().ufs || {})[u]; return (x && x.tem) ? x : null; }
  function candidatos(b) { return (b && b.candidatos) ? b.candidatos : []; }
  function lider(b) {
    var cs = candidatos(b);
    return (cs.length && cs[0].votos > 0) ? cs[0] : null;
  }

  function cor(c) {
    if (!c) return C.semDado;
    var cores = D().cores || {};
    if (cores[c.numero]) return cores[c.numero];
    if (cores[c.partido]) return cores[c.partido];
    var sg = String(c.partido || "").toUpperCase().trim();
    if (CORES_PARTIDO[sg]) return CORES_PARTIDO[sg];
    var slot = (D().cor_slot || {})[c.numero];
    if (slot == null || slot >= PALETA.length) return C.outros;
    return PALETA_OUTROS[slot % PALETA_OUTROS.length];
  }

  function selo() {
    var d = D(), b = br();
    if (ensaioAtivo()) return { texto: (window.GCTSE_DADOS || {}).reprise ? "REPRISE — NÃO VAI AO AR" : "ENSAIO — NÃO VAI AO AR", cor: C.vermelho };
    if (d.modo === "SIMULADO") return { texto: "SIMULADO — NÃO OFICIAL", cor: C.vermelho };
    if (b && b.andamento === "f") return { texto: "TOTALIZAÇÃO FINAL", cor: C.verde };
    // Antes da 1a urna (arquivo do TSE ja publicado com tudo zerado, ou
    // nenhum arquivo ainda): selo neutro, nada de vermelho.
    var pct = b && b.secoes ? b.secoes.pct : null;
    if (!b || !(pct > 0)) return { texto: "AGUARDANDO APURAÇÃO", cor: C.trilho };
    // 100% das secoes apuradas (pst do TSE), mas o TSE ainda nao marcou o
    // Brasil como final (exterior/revisao): nao e mais "parcial" no ar.
    if (pct >= 100) return { texto: "100% DAS URNAS", cor: C.verde };
    return { texto: "PARCIAL", cor: C.vermelho };
  }
  function subtitulo() {
    var b = br();
    if (!b) return "aguardando o primeiro boletim";
    var h = String(b.hora || "").slice(0, 5);
    return h ? "atualizado às " + h + " (horário do TSE)" : "boletim do TSE";
  }
  function estadosComBoletim() {
    var n = 0, ufs = D().ufs || {};
    for (var k in ufs) if (ufs[k] && ufs[k].tem) n++;
    return n;
  }

  // ----------------------------------------------------------- pecas de SVG
  function t(x, y, txt, o) {
    o = o || {};
    return '<text x="' + x + '" y="' + y + '" font-size="' + (o.s || 16) + '"' +
      (o.b ? ' font-weight="700"' : "") + ' fill="' + (o.c || C.texto) + '"' +
      (o.a ? ' text-anchor="' + o.a + '"' : "") +
      (o.ls ? ' letter-spacing="' + o.ls + '"' : "") +
      (o.max ? ' data-max="' + o.max + '"' : "") +
      (o.extra || "") + ">" + esc(txt) + "</text>";
  }
  function r(x, y, w, h, c, rx) {
    return '<rect x="' + x + '" y="' + y + '" width="' + Math.max(0, w) + '" height="' + h + '" fill="' + c + '"' +
      (rx ? ' rx="' + rx + '"' : "") + "/>";
  }
  // O selo tem a largura medida DEPOIS de desenhado (ver ajustarSelos).
  var SELO_ENSAIO = { texto: "ENSAIO — NÃO VAI AO AR", cor: "#d03b3b" };
  Object.defineProperty(SELO_ENSAIO, "texto", { get: function () { return (window.GCTSE_DADOS || {}).reprise ? "REPRISE — NÃO VAI AO AR" : "ENSAIO — NÃO VAI AO AR"; } });
  function seloH(W, sl) {
    var s = ensaioAtivo() ? SELO_ENSAIO : sl || selo();
    // a esquerda da logo (canto superior direito)
    return '<g data-selo="dir" data-x="' + (W - 73 - 200) + '">' + r(W - 520, 29, 247, 32, s.cor, 3) +
      t(W - 281, 51, s.texto, { s: 18, b: true, a: "end" }) + "</g>";
  }
  function seloV(W, sl) {
    var s = ensaioAtivo() ? SELO_ENSAIO : sl || selo();
    return r(35, 127, W - 70, 26, s.cor, 2) + t(W / 2, 146, s.texto, { s: 16, b: true, a: "middle" });
  }
  function cabecalhoH(W, titulo, sub) {
    return t(73, 57, titulo, { s: 36, b: true, ls: 1, max: W - 73 - 540 }) + t(73, 85, sub, { s: 19, c: C.apagado, max: W - 146 }) + seloH(W);
  }
  function cabecalhoV(W, titulo, sub) {
    return r(35, 48, 6, 38, C.destaque) + t(53, 80, titulo, { s: 32, b: true, ls: 1, max: W - 53 - 35 }) +
      t(53, 106, sub, { s: 16, c: C.apagado, max: W - 53 - 35 }) + seloV(W);
  }
  // Marca "ENSAIO" (so se o dado vier com ensaio=true; a coleta oficial grava false).
  function ensaioAtivo() { return !!((window.GCTSE_DADOS || {}).ensaio || (window.GCTSE_ESTADOS || {}).ensaio); }
  function marcaEnsaio(W, H) {
    if (!ensaioAtivo()) return "";
    var cx = W / 2, cy = H / 2, s = Math.round(Math.min(W, H) / 7.5), rp = !!(window.GCTSE_DADOS || {}).reprise;
    return '<g pointer-events="none"><text x="' + cx + '" y="' + cy + '" text-anchor="middle" dominant-baseline="middle" font-size="' + s +
      '" font-weight="800" fill="#ff2a2a" fill-opacity="0.22" transform="rotate(' + (W > H ? -18 : -55) + " " + cx + " " + cy + ')">' + (rp ? "REPRISE" : "ENSAIO") + '</text>' +
      '<rect x="0" y="' + (H - 30) + '" width="' + W + '" height="30" fill="#c00000"/>' +
      '<text x="' + cx + '" y="' + (H - 9) + '" text-anchor="middle" font-size="17" font-weight="800" fill="#ffffff">' + (rp ? "REPRISE (TREINO) — DADOS DE OUTRA NOITE — NÃO VAI AO AR" : "ENSAIO — DADOS FICTÍCIOS — NÃO VAI AO AR") + '</text></g>';
  }
  function svg(W, H, corpo) {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + " " + H + '" width="' + W + '" height="' + H +
      '" font-family="' + FONTE + '">' + r(0, 0, W, H, C.fundo) + arteFundo(W, H) + corpo + marcaEnsaio(W, H) + arteLogo(W, H, 35 + (W > H ? 38 : 0)) + "</svg>";
  }
  function barra(x, y, w, h, frac, c) {
    frac = Math.max(0, Math.min(1, frac || 0));
    return r(x, y, w, h, C.trilho, 4) + (frac > 0 ? r(x, y, Math.max(8, w * frac), h, c, 4) : "");
  }
  function etiqueta(x, y, c) {
    if (c && c.eleito) return r(x, y - 15, 74, 20, C.verde, 3) + t(x + 37, y, "ELEITO", { s: 13, b: true, a: "middle" });
    if (c && c.segundo_turno) return r(x, y - 15, 86, 20, C.destaque, 3) + t(x + 43, y, "2º TURNO", { s: 13, b: true, a: "middle" });
    return "";
  }

  // Foto oficial do TSE (sem pasta). Some se o TSE nao tiver; 3 falhas sem
  // nenhum acerto desligam as fotos (404 em excesso pode bloquear o IP).
  var FOTO = { falhou: {}, falhas: 0, acertos: 0 };
  window.__gctseFotoP = function (img, ok) {
    var url = img.getAttribute("href");
    if (ok) { FOTO.acertos++; return; }
    if (!FOTO.falhou[url]) { FOTO.falhou[url] = true; FOTO.falhas++; }
    var g = img.parentNode; if (g && g.parentNode) g.parentNode.removeChild(g);
    clearTimeout(FOTO.timer);
    FOTO.timer = setTimeout(function () { if (window.__gctseRedesenhar) window.__gctseRedesenhar(); }, 300);
  };
  function urlFoto(c) {
    var tse = D().tse;
    // Chave unica em web\fotos-config.js (sem ela: sem fotos). O PNG sai sem
    // fotos: o navegador nao deixa embutir imagem de outro site no PNG.
    if (window.GCTSE_FOTOS_DO_TSE !== true || window.__gctseSemFotos) return "";
    if (!tse || !tse.base || !c || !c.sqcand) return "";
    if (FOTO.falhas >= 3 && FOTO.acertos === 0 && !window.GCTSE_FOTOS_LOCAIS) return "";
    var url = tse.base + "/" + tse.ciclo + "/" + tse.eleicao + "/fotos/br/" + c.sqcand + ".jpeg"; url = viaLocal(url);
    return FOTO.falhou[url] ? "" : url;
  }
  function foto(url, x, y, w, h) {
    return "<g>" + r(x, y, w, h, C.trilho, 3) + '<image href="' + esc(url) + '" x="' + x + '" y="' + y + '" width="' + w +
      '" height="' + h + '" preserveAspectRatio="xMidYMid slice" onload="__gctseFotoP(this,true)" onerror="__gctseFotoP(this,false)"/></g>';
  }

  // Rosca: arcos proporcionais com 2px de separacao entre as fatias.
  function rosca(cx, cy, raio, esp, fatias) {
    var total = 0, i, out = '<circle cx="' + cx + '" cy="' + cy + '" r="' + raio + '" fill="none" stroke="' + C.trilho +
      '" stroke-width="' + esp + '"/>';
    for (i = 0; i < fatias.length; i++) total += Math.max(0, fatias[i].v || 0);
    if (total <= 0) return out;
    var circ = 2 * Math.PI * raio, acum = 0, gap = fatias.filter(function (f) { return f.v > 0; }).length > 1 ? 2 : 0;
    for (i = 0; i < fatias.length; i++) {
      var v = Math.max(0, fatias[i].v || 0);
      if (v <= 0) continue;
      var len = circ * v / total;
      var vis = Math.max(0.5, len - gap);
      out += '<circle cx="' + cx + '" cy="' + cy + '" r="' + raio + '" fill="none" stroke="' + fatias[i].c +
        '" stroke-width="' + esp + '" stroke-dasharray="' + vis.toFixed(2) + " " + (circ - vis).toFixed(2) +
        '" stroke-dashoffset="' + (-acum).toFixed(2) + '" transform="rotate(-90 ' + cx + " " + cy + ')"/>';
      acum += len;
    }
    return out;
  }

  // Mapa: estados pintados com a cor de quem lidera em cada um.
  var PEQUENOS = ["rn", "pb", "pe", "al", "se", "df", "es", "rj"];
  function mapa(x, y, escala, opc) {
    var M = window.MAPA_BRASIL, out = '<g transform="translate(' + x + " " + y + ") scale(" + escala + ')">';
    var k, e, u, l;
    for (k in M.estados) {
      e = M.estados[k]; u = uf(k); l = lider(u);
      out += '<path d="' + e.path + '" fill="' + (l ? cor(l) : C.semDado) + '" stroke="' + C.fundo +
        '" stroke-width="' + (1.2 / escala).toFixed(2) + '" stroke-linejoin="round"/>';
    }
    // rotulos (texto com contorno escuro para ler sobre qualquer cor)
    var contorno = ' stroke="' + C.fundo + '" stroke-width="' + (3 / escala).toFixed(2) + '" paint-order="stroke" stroke-linejoin="round"';
    for (k in M.estados) {
      if (opc.chamadas && PEQUENOS.indexOf(k) >= 0) continue;
      if (!opc.chamadas && PEQUENOS.indexOf(k) >= 0 && opc.semPequenos) continue;
      e = M.estados[k]; u = uf(k); l = lider(u);
      var fs = opc.fonte / escala;
      out += '<text x="' + e.cx + '" y="' + (e.cy + (opc.sub ? -2 / escala : fs * 0.35)) + '" font-size="' + fs.toFixed(1) +
        '" font-weight="700" fill="#fff" text-anchor="middle"' + contorno + ">" + k.toUpperCase() + "</text>";
      if (opc.sub) {
        out += '<text x="' + e.cx + '" y="' + (e.cy + fs * 0.95) + '" font-size="' + (fs * 0.8).toFixed(1) +
          '" fill="#fff" text-anchor="middle"' + contorno + ">" + esc(l ? corta(l.partido, 9) : "—") + "</text>";
      }
    }
    out += "</g>";
    if (opc.chamadas) {
      // estados pequenos: sigla puxada para fora do mapa, com uma linha
      var pos = { rn: 130, pb: 156, pe: 182, al: 208, se: 234, df: 300, es: 370, rj: 420 };
      var xc = x + 640 * escala;
      for (var i = 0; i < PEQUENOS.length; i++) {
        k = PEQUENOS[i]; e = M.estados[k]; u = uf(k); l = lider(u);
        var yc = y + pos[k] * escala + (k === "rn" ? 0 : 0);
        var ex = x + e.cx * escala, ey = y + e.cy * escala;
        out += '<line x1="' + ex.toFixed(1) + '" y1="' + ey.toFixed(1) + '" x2="' + (xc - 4) + '" y2="' + yc.toFixed(1) +
          '" stroke="' + C.apagado2 + '" stroke-width="1"/>';
        out += r(xc - 3, yc - 7, 10, 14, l ? cor(l) : C.semDado, 1);
        out += t(xc + 12, yc + 5, k.toUpperCase() + " " + (l ? corta(l.partido, 8) : "—"), { s: 14, b: true });
      }
    }
    return out;
  }

  // Quantos estados cada candidato lidera.
  function placarEstados() {
    var cont = {}, ref = {}, ufs = D().ufs || {};
    for (var k in ufs) {
      var l = lider(uf(k));
      if (!l) continue;
      cont[l.numero] = (cont[l.numero] || 0) + 1; ref[l.numero] = l;
    }
    var lista = [];
    for (var n in cont) lista.push({ c: ref[n], n: cont[n] });
    lista.sort(function (a, b) { return b.n - a.n || String(a.c.numero).localeCompare(String(b.c.numero)); });
    return lista;
  }

  // ------------------------------------------------------------- graficos
  var G = {};

  // ===== horizontais 1280x720 ==========================================
  // Com mais candidatos do que linhas, a ultima vira "OUTROS N CANDIDATOS"
  // com a soma - assim a tela fecha 100%.
  function linhasPresidente(cs, n) {
    if (cs.length <= n) return cs.slice(0, n);
    var resto = cs.slice(n - 1), soma = { nome: "OUTROS " + resto.length + " CANDIDATOS", partido: "soma dos demais",
      votos: 0, pct: 0, outros: true };
    resto.forEach(function (k) { soma.votos += k.votos || 0; soma.pct += k.pct || 0; });
    return cs.slice(0, n - 1).concat([soma]);
  }
  // "FULANO à frente por X pontos (N votos)" - so com votos de verdade.
  function diferenca(cs) {
    if (cs.length < 2 || !(cs[0].votos > 0)) return "";
    return cs[0].nome + " à frente por " + Number(cs[0].pct - cs[1].pct).toFixed(2).replace(".", ",") +
      " pontos (" + inteiro(cs[0].votos - cs[1].votos) + " votos)";
  }
  // Marca dos 50% na barra: quem passa dela vence no 1o turno.
  function marca50(x, y, w, h) { return r(x + w / 2 - 1.5, y - 4, 3, h + 8, "#ffffff", 0); }

  G["presidente-h"] = function () {
    var W = 1280, H = 720, b = br(), todos = candidatos(b), cs = linhasPresidente(todos, 6);
    // 2o turno (so 2 candidatos): 2 linhas no meio, sem linhas vazias
    var nl = todos.length >= 2 && todos.length < 6 ? todos.length : 6, passo = nl >= 6 ? 84.4 : Math.min(150, 506 / nl), y0 = 152 + (506 - passo * nl) / 2;
    var o = cabecalhoH(W, "PRESIDENTE — BRASIL", "% dos votos válidos  ·  " + subtitulo());
    o += t(727, 124, "50% DOS VÁLIDOS", { s: 13, b: true, c: C.apagado, a: "middle", ls: 1 });
    for (var i = 0; i < nl; i++) {
      var c = cs[i], cy = y0 + i * passo, url = c && !c.outros ? urlFoto(c) : "", dx = 0;
      o += r(73, cy - 20, 6, 42, c ? cor(c) : C.outros, 1);
      if (url) { o += foto(url, 87, cy - 30, 54, 72); dx = 64; }
      o += t(93 + dx, cy + 3, c ? (c.outros ? c.nome : corta(c.nome, 22)) : "—", { s: 26, b: true, max: 320 - dx });
      o += t(93 + dx, cy + 29, c ? corta(c.partido, 30) : "—", { s: 15, c: C.apagado, max: 320 - dx });
      o += etiqueta(427, cy - 20, c);
      o += barra(427, cy - 13, 600, 30, c ? c.pct / 100 : 0, c && !c.outros ? cor(c) : C.outros) + marca50(427, cy - 13, 600, 30);
      o += t(1027, cy + 39, c ? inteiro(c.votos) : "0", { s: 15, c: C.apagado, a: "end" });
      o += t(1200, cy + 10, c ? pct(c.pct) : "0,00%", { s: 30, b: true, a: "end" });
    }
    var s = b ? b.secoes : null;
    o += t(73, 690, s ? inteiro(s.totalizadas) + " de " + inteiro(s.total) + " urnas · " + pct(s.pct) : "0 de 0 urnas",
      { s: 14, c: C.apagado2 });
    var dif = diferenca(todos);
    if (dif) o += t(1200, 690, dif, { s: 18, b: true, a: "end", max: 760 });
    o += t(727, 666, nl === 2 ? "▏ 50% dos válidos" : "▏ 50% dos válidos = vence no 1º turno", { s: 13, c: C.apagado2, a: "middle" });
    return svg(W, H, o);
  };

  G["votos-h"] = function () {
    var W = 1280, H = 720, b = br(), v = b ? b.votos : {}, e = b ? b.eleitorado : {};
    var o = cabecalhoH(W, "COMO O BRASIL VOTOU", subtitulo());
    o += rosca(347, 413, 153, 70, [{ v: v.validos, c: C.validos }, { v: v.brancos, c: C.brancos }, { v: v.nulos, c: C.nulos }]);
    var bn = (v.pct_brancos != null && v.pct_nulos != null) ? v.pct_brancos + v.pct_nulos : null;
    o += t(347, 410, b ? pct(bn) : "0,00%", { s: 60, b: true, a: "middle" });
    o += t(347, 446, "BRANCOS + NULOS", { s: 18, c: C.apagado, a: "middle", ls: 2 });
    var linhas = [["Válidos", C.validos, v.pct_validos, v.validos], ["Brancos", C.brancos, v.pct_brancos, v.brancos],
                  ["Nulos", C.nulos, v.pct_nulos, v.nulos]];
    for (var i = 0; i < 3; i++) {
      var y = 211 + i * 56, L = linhas[i];
      o += r(673, y - 10, 20, 20, L[1], 2) + t(707, y + 9, L[0], { s: 26, b: true }) +
        t(914, y + 9, b ? pct(L[2]) : "0,00%", { s: 24, c: C.apagado }) + t(1207, y + 9, b ? inteiro(L[3]) : "0", { s: 24, a: "end" });
    }
    o += '<line x1="673" y1="385" x2="1207" y2="385" stroke="' + C.linha + '" stroke-width="1"/>';
    o += t(707, 426, "Abstenção", { s: 26, b: true }) + t(914, 426, b ? pct(e.pct_abstencao) : "0,00%", { s: 24, c: C.apagado }) +
      t(1207, 426, b ? inteiro(e.abstencao) : "0", { s: 24, a: "end" });
    o += t(707, 460, "Válidos, brancos e nulos sobre os votos", { s: 15, c: C.apagado2 }) +
      t(707, 480, "apurados. Abstenção sobre o eleitorado apto.", { s: 15, c: C.apagado2 });
    o += t(73, 690, "Fonte: TSE — Divulgação de Resultados", { s: 14, c: C.apagado2 });
    return svg(W, H, o);
  };

  G["urnas-h"] = function () {
    var W = 1280, H = 720, b = br(), s = b ? b.secoes : null;
    var o = cabecalhoH(W, "APURAÇÃO NACIONAL", subtitulo());
    o += t(73, 220, "URNAS TOTALIZADAS", { s: 22, c: C.apagado, ls: 4 });
    o += t(73, 333, s ? inteiro(s.totalizadas) : "0", { s: 110, b: true, max: 1134 });
    o += t(73, 381, (s ? "de " + inteiro(s.total) + " · " + pct(s.pct) : "de 0 · 0,00%"), { s: 30, c: C.apagado });
    o += barra(73, 440, 1134, 20, s ? (s.pct || 0) / 100 : 0, C.destaque);
    var faltam = (s && s.total != null && s.totalizadas != null) ? s.total - s.totalizadas : null;
    o += t(73, 527, faltam == null ? "Faltam —" : (faltam === 0 ? "Todas as urnas totalizadas" : "Faltam " + inteiro(faltam) + " urnas"), { s: 28 });
    o += t(73, 690, "Fonte: TSE — Divulgação de Resultados", { s: 14, c: C.apagado2 });
    return svg(W, H, o);
  };

  G["estados-h"] = function () {
    var W = 1280, H = 720, n = estadosComBoletim();
    var o = cabecalhoH(W, "COMO CADA ESTADO VOTOU", n + " de 27 estados com boletim publicado");
    o += mapa(28, 112, 0.868, { fonte: 14, semPequenos: true });
    var M = window.MAPA_BRASIL, ufs = Object.keys(M.estados).sort();
    for (var i = 0; i < ufs.length; i++) {
      var k = ufs[i], col = i < 14 ? 0 : 1, lin = i < 14 ? i : i - 14;
      var x = 587 + col * 347, y = 133 + lin * 40, u = uf(k), l = lider(u);
      o += r(x, y - 12, 4, 24, l ? cor(l) : C.semDado, 1) + t(x + 14, y + 7, k.toUpperCase(), { s: 20, b: true });
      if (l) {
        o += t(x + 62, y + 7, corta(l.nome, 16), { s: 17, max: 180 }) + t(x + 322, y + 7, pct(l.pct), { s: 17, b: true, a: "end" });
      } else {
        o += t(x + 62, y + 7, "aguardando", { s: 18, c: C.apagado });
      }
    }
    o += t(73, 690, "Fonte: TSE — Divulgação de Resultados", { s: 14, c: C.apagado2 });
    return svg(W, H, o);
  };

  function listaPartidos(x, y, larg, passo, max) {
    var lista = placarEstados(), o = "";
    if (!lista.length) return t(x, y + 8, "aguardando boletim", { s: 20, c: C.apagado });
    var topo = lista[0].n;
    for (var i = 0; i < Math.min(max, lista.length); i++) {
      var it = lista[i], yy = y + i * passo;
      o += r(x, yy - 10, 16, 16, cor(it.c), 2);
      o += t(x + 26, yy + 4, corta(it.c.partido, 12) + " · " + corta(it.c.nome, 18), { s: 18, b: true });
      o += t(x + larg, yy + 4, it.n + (it.n === 1 ? " estado" : " estados"), { s: 18, a: "end" });
      o += barra(x, yy + 14, larg, 8, it.n / 27, cor(it.c));
    }
    if (lista.length > max) o += t(x, y + max * passo + 4, "+ " + (lista.length - max) + " outro(s)", { s: 15, c: C.apagado2 });
    return o;
  }

  G["lideranca-h"] = function () {
    var W = 1280, H = 720, n = estadosComBoletim();
    var o = cabecalhoH(W, "LIDERANÇA POR ESTADO", n + " de 27 estados com boletim publicado");
    o += mapa(75, 112, 0.81, { fonte: 16, sub: true, chamadas: true });
    o += t(807, 147, "ESTADOS POR PARTIDO", { s: 18, b: true, c: C.apagado, ls: 2 });
    o += listaPartidos(807, 190, 400, 58, 7);
    o += t(73, 690, "Fonte: TSE — Divulgação de Resultados", { s: 14, c: C.apagado2 });
    return svg(W, H, o);
  };

  // ===== verticais 540x960 =============================================
  var RODAPE_V = function () { return t(35, 932, "Fonte: TSE", { s: 12, c: C.apagado2 }); };

  G["urnas-v"] = function () {
    var W = 540, H = 960, b = br(), s = b ? b.secoes : null;
    var o = cabecalhoV(W, "URNAS APURADAS", subtitulo());
    o += t(35, 215, "URNAS TOTALIZADAS", { s: 18, c: C.apagado, ls: 3 });
    o += t(35, 300, s ? inteiro(s.totalizadas) : "0", { s: 96, b: true, max: 470 });
    o += t(35, 331, s ? "de " + inteiro(s.total) : "de 0", { s: 22, c: C.apagado });
    o += barra(35, 370, 470, 26, s ? (s.pct || 0) / 100 : 0, C.destaque);
    o += t(35, 485, s ? pct(s.pct) : "0,00%", { s: 80, b: true, max: 470 });
    o += t(35, 516, "da apuração concluída", { s: 20, c: C.apagado });
    return svg(W, H, o + RODAPE_V());
  };

  G["votos-v"] = function () {
    var W = 540, H = 960, b = br(), v = b ? b.votos : {};
    var o = cabecalhoV(W, "BRANCOS E NULOS", subtitulo());
    o += rosca(270, 400, 129, 58, [{ v: v.validos, c: C.validos }, { v: v.brancos, c: C.brancos }, { v: v.nulos, c: C.nulos }]);
    var bn = (v.pct_brancos != null && v.pct_nulos != null) ? v.pct_brancos + v.pct_nulos : null;
    o += t(270, 403, b ? pct(bn) : "0,00%", { s: 52, b: true, a: "middle" });
    o += t(270, 436, "BRANCOS + NULOS", { s: 14, c: C.apagado, a: "middle", ls: 2 });
    var linhas = [["Brancos", C.brancos, v.pct_brancos, v.brancos], ["Nulos", C.nulos, v.pct_nulos, v.nulos],
                  ["Válidos", C.validos, v.pct_validos, v.validos]];
    for (var i = 0; i < 3; i++) {
      var y = 642 + i * 74, L = linhas[i];
      o += r(35, y - 9, 18, 18, L[1], 2) + t(65, y + 8, L[0], { s: 24, b: true }) +
        t(505, y + 8, b ? inteiro(L[3]) : "0", { s: 22, a: "end" }) + t(505, y + 34, b ? pct(L[2]) : "0,00%", { s: 17, c: C.apagado, a: "end" });
    }
    o += t(35, 882, "sobre os votos apurados", { s: 14, c: C.apagado2 });
    return svg(W, H, o + RODAPE_V());
  };

  G["presidente-v"] = function () {
    var W = 540, H = 960, b = br(), todos = candidatos(b), cs = linhasPresidente(todos, 5);
    var nl = todos.length >= 2 && todos.length < 5 ? todos.length : 5, passo = nl >= 5 ? 134 : 180, y0 = 212 + (nl >= 5 ? 0 : (670 - passo * nl) / 2);
    var o = cabecalhoV(W, "PRESIDENTE", "% dos votos válidos · " + subtitulo());
    for (var i = 0; i < nl; i++) {
      var c = cs[i], y = y0 + i * passo, url = c && !c.outros ? urlFoto(c) : "", dx = 0;
      o += r(35, y - 18, 5, 34, c ? cor(c) : C.outros, 1);
      if (url) { o += foto(url, 47, y - 24, 45, 60); dx = 55; }
      o += t(51 + dx, y + 6, c ? (c.outros ? c.nome : corta(c.nome, 16)) : "—", { s: 26, b: true, max: 300 - dx });
      o += t(51 + dx, y + 30, c ? corta(c.partido, 22) : "—", { s: 14, c: C.apagado, max: 300 - dx });
      o += t(505, y + 12, c ? pct(c.pct) : "0,00%", { s: 32, b: true, a: "end" });
      o += barra(35, y + 44, 470, 12, c ? c.pct / 100 : 0, c && !c.outros ? cor(c) : C.outros) + marca50(35, y + 44, 470, 12);
      o += t(35, y + 74, c ? inteiro(c.votos) : "0", { s: 15, c: C.apagado });
      if (c && (c.eleito || c.segundo_turno)) o += etiqueta(505 - (c.eleito ? 74 : 86), y + 78, c);
    }
    o += t(35, 862, nl === 2 ? "▏ 50% dos válidos" : "▏ 50% dos válidos = vence no 1º turno", { s: 13, c: C.apagado2 });
    var dif = diferenca(todos);
    if (dif) o += t(35, 892, dif, { s: 16, b: true, max: 470 });
    return svg(W, H, o + RODAPE_V());
  };

  G["comparecimento-v"] = function () {
    var W = 540, H = 960, b = br(), e = b ? b.eleitorado : null;
    var o = cabecalhoV(W, "COMPARECIMENTO", subtitulo());
    o += t(35, 215, "FORAM VOTAR", { s: 18, c: C.apagado, ls: 3 });
    o += t(35, 300, e ? inteiro(e.comparecimento) : "0", { s: 96, b: true, max: 470 });
    o += t(35, 331, e ? "de " + inteiro(e.aptos) + " eleitores aptos" : "de 0 eleitores aptos", { s: 20, c: C.apagado });
    o += t(35, 412, e ? pct(e.pct_comparec) : "0,00%", { s: 80, b: true, max: 470 });
    var fr = e && e.pct_comparec != null ? e.pct_comparec / 100 : 0;
    o += r(35, 450, 470, 26, C.abstencao, 4) + (fr > 0 ? r(35, 450, Math.max(8, 470 * fr - 2), 26, C.comparec, 4) : "");
    o += r(35, 541, 18, 18, C.comparec, 2) + t(65, 558, "Compareceram", { s: 24, b: true }) +
      t(505, 558, e ? inteiro(e.comparecimento) : "0", { s: 22, a: "end" }) + t(505, 584, e ? pct(e.pct_comparec) : "0,00%", { s: 17, c: C.apagado, a: "end" });
    o += r(35, 615, 18, 18, C.abstencao, 2) + t(65, 632, "Abstenção", { s: 24, b: true }) +
      t(505, 632, e ? inteiro(e.abstencao) : "0", { s: 22, a: "end" }) + t(505, 658, e ? pct(e.pct_abstencao) : "0,00%", { s: 17, c: C.apagado, a: "end" });
    return svg(W, H, o + RODAPE_V());
  };

  G["lideranca-v"] = function () {
    var W = 540, H = 960, n = estadosComBoletim();
    var o = cabecalhoV(W, "LIDERANÇA POR ESTADO", n + " de 27 estados com boletim");
    o += mapa(35, 175, 0.767, { fonte: 13, semPequenos: true });
    o += t(35, 722, "ESTADOS POR PARTIDO", { s: 16, c: C.apagado, ls: 2 });
    o += listaPartidos(35, 762, 470, 48, 3);
    return svg(W, H, o + RODAPE_V());
  };

  // O selo cresce com o texto: mede depois de desenhado e ajusta a caixa.
  function ajustarSelos(raiz) {
    // Numero grande e titulo encolhem para caber (ex.: 124.800.000 eleitores
    // no vertical de 540 px). Mede depois de desenhado.
    var ms = raiz.querySelectorAll("text[data-max]");
    for (var j = 0; j < ms.length; j++) {
      var max = parseFloat(ms[j].getAttribute("data-max")), lg = ms[j].getComputedTextLength();
      if (lg > max) {
        var fs = parseFloat(ms[j].getAttribute("font-size"));
        ms[j].setAttribute("font-size", Math.floor(fs * max / lg));
      }
    }
    var gs = raiz.querySelectorAll("g[data-selo]");
    for (var i = 0; i < gs.length; i++) {
      var tx = gs[i].querySelector("text"), rc = gs[i].querySelector("rect");
      var w = tx.getComputedTextLength() + 16, xd = parseFloat(gs[i].getAttribute("data-x"));
      rc.setAttribute("x", (xd - w).toFixed(1)); rc.setAttribute("width", w.toFixed(1));
      tx.setAttribute("x", (xd - 8).toFixed(1));
    }
  }

  // ABSTENCAO, BRANCOS E NULOS: tres numeros grandes, do boletim do Brasil.
  function linhasABN() {
    var b = br(), v = b ? b.votos : null, e = b ? b.eleitorado : null;
    return [
      { cor: C.abstencao, antes: "ABSTENÇÃO", valor: e ? pct(e.pct_abstencao) : "0,00%", depois: "",
        sub: e && e.abstencao != null ? inteiro(e.abstencao) + " eleitores não foram votar" : "" },
      { cor: C.brancos, antes: "BRANCOS SOMAM", valor: v ? pct(v.pct_brancos) : "0,00%", depois: "DOS VOTOS",
        sub: v && v.brancos != null ? inteiro(v.brancos) + " votos em branco" : "" },
      { cor: C.nulos, antes: "NULOS REPRESENTAM", valor: v ? pct(v.pct_nulos) : "0,00%", depois: "DOS VOTOS",
        sub: v && v.nulos != null ? inteiro(v.nulos) + " votos nulos" : "" }
    ];
  }
  G["abstencao-h"] = function () {
    var W = 1280, H = 720, o = cabecalhoH(W, "ABSTENÇÃO, BRANCOS E NULOS", subtitulo());
    linhasABN().forEach(function (L, i) {
      var y = 150 + i * 172;
      o += r(73, y, W - 146, 150, C.linha, 8) + r(73, y, 10, 150, L.cor, 3);
      o += t(113, y + 62, L.antes, { s: 40, b: true, ls: 1, max: 560 });
      if (L.depois) o += t(113, y + 108, L.depois, { s: 30, b: true, c: C.apagado, ls: 1 });
      else if (L.sub) o += t(113, y + 108, L.sub, { s: 22, c: C.apagado, max: 560 });
      o += t(W - 103, y + 104, L.valor, { s: 104, b: true, a: "end" });
      if (L.depois && L.sub) o += t(W - 103, y + 138, L.sub, { s: 18, c: C.apagado, a: "end" });
    });
    o += t(73, 700, "Fonte: TSE — Divulgação de Resultados", { s: 14, c: C.apagado2 });
    return svg(W, H, o);
  };
  G["abstencao-v"] = function () {
    var W = 540, H = 960, o = cabecalhoV(W, "ABSTENÇÃO, BRANCOS E NULOS", subtitulo());
    linhasABN().forEach(function (L, i) {
      var y = 172 + i * 250;
      o += r(35, y, W - 70, 230, C.linha, 8) + r(35, y, 8, 230, L.cor, 3);
      o += t(65, y + 50, L.antes, { s: 30, b: true, ls: 1, max: W - 110 });
      o += t(65, y + 140, L.valor, { s: 88, b: true, max: W - 110 });
      if (L.depois) o += t(65, y + 180, L.depois, { s: 24, b: true, c: C.apagado, ls: 1 });
      if (L.sub) o += t(65, y + (L.depois ? 212 : 184), L.sub, { s: 16, c: C.apagado, max: W - 110 });
    });
    return svg(W, H, o + RODAPE_V());
  };

  // MAPA DA ABSTENCAO: cada estado pela % de eleitores que nao votaram.
  // Faixas FIXAS (a cor de um estado so muda se o numero dele mudar de
  // faixa); um so tom. No fundo escuro, mais abstencao = mais claro e
  // forte (o tom mais escuro ainda aparece contra o azul do fundo).
  var FAIXAS_ABST = [
    { ate: 15, cor: "#8a5516", rot: "até 15%" }, { ate: 18, cor: "#b8741c", rot: "15 a 18%" },
    { ate: 21, cor: "#d9922a", rot: "18 a 21%" }, { ate: 24, cor: "#f0b44e", rot: "21 a 24%" },
    { ate: 999, cor: "#ffd98c", rot: "acima de 24%" }
  ];
  function corAbst(p) {
    if (p == null || !(p > 0)) return C.semDado;
    for (var i = 0; i < FAIXAS_ABST.length; i++) if (p <= FAIXAS_ABST[i].ate) return FAIXAS_ABST[i].cor;
    return FAIXAS_ABST[FAIXAS_ABST.length - 1].cor;
  }
  function abstUf(k) { var x = uf(k); return x && x.eleitorado && x.eleitorado.pct_abstencao > 0 ? x.eleitorado.pct_abstencao : null; }
  function mapaAbst(x, y, escala, fonte) {
    var M = window.MAPA_BRASIL, out = '<g transform="translate(' + x + " " + y + ") scale(" + escala + ')">', k, e;
    for (k in M.estados) {
      e = M.estados[k];
      out += '<path d="' + e.path + '" fill="' + corAbst(abstUf(k)) + '" stroke="' + C.fundo +
        '" stroke-width="' + (1.2 / escala).toFixed(2) + '" stroke-linejoin="round"/>';
    }
    var contorno = ' stroke="' + C.fundo + '" stroke-width="' + (3 / escala).toFixed(2) + '" paint-order="stroke" stroke-linejoin="round"';
    for (k in M.estados) {
      if (PEQUENOS.indexOf(k) >= 0) continue;
      e = M.estados[k];
      out += '<text x="' + e.cx + '" y="' + (e.cy + 5) + '" font-size="' + (fonte / escala).toFixed(1) +
        '" font-weight="700" fill="#fff" text-anchor="middle"' + contorno + ">" + k.toUpperCase() + "</text>";
    }
    return out + "</g>";
  }
  function rankingAbst() {
    var L = [];
    for (var k in (window.MAPA_BRASIL || {}).estados) { var p = abstUf(k); if (p != null) L.push({ u: k.toUpperCase(), p: p }); }
    return L.sort(function (a, b) { return b.p - a.p; });
  }
  function legendaAbst(x, y, passo, s) {
    var o = "";
    FAIXAS_ABST.forEach(function (f, i) {
      o += r(x, y + i * passo - s, s + 4, s + 4, f.cor, 3) + t(x + s + 16, y + i * passo, f.rot, { s: s, c: C.apagado });
    });
    return o;
  }
  G["abstencao-mapa-h"] = function () {
    var W = 1280, H = 720, b = br(), e = b ? b.eleitorado : null, L = rankingAbst();
    var o = cabecalhoH(W, "MAPA DA ABSTENÇÃO", "% de eleitores que não foram votar, por estado");
    o += mapaAbst(60, 118, 0.86, 15);
    var px = 700;
    o += t(px, 160, "BRASIL", { s: 20, b: true, c: C.apagado, ls: 2 });
    o += t(px, 228, e ? pct(e.pct_abstencao) : "0,00%", { s: 72, b: true });
    if (L.length) {
      o += t(px, 290, "MAIOR ABSTENÇÃO", { s: 16, b: true, c: C.apagado, ls: 2 });
      L.slice(0, 3).forEach(function (it, i) { o += t(px, 322 + i * 30, it.u + "  " + pct(it.p), { s: 22, b: true }); });
      o += t(px + 260, 290, "MENOR ABSTENÇÃO", { s: 16, b: true, c: C.apagado, ls: 2 });
      L.slice(-3).reverse().forEach(function (it, i) { o += t(px + 260, 322 + i * 30, it.u + "  " + pct(it.p), { s: 22, b: true }); });
    } else {
      o += t(px, 300, "aguardando os boletins dos estados", { s: 20, c: C.apagado });
    }
    o += legendaAbst(px, 470, 34, 18);
    o += t(73, 690, "Fonte: TSE — Divulgação de Resultados · urnas já apuradas", { s: 14, c: C.apagado2 });
    return svg(W, H, o);
  };
  G["abstencao-mapa-v"] = function () {
    var W = 540, H = 960, b = br(), e = b ? b.eleitorado : null, L = rankingAbst();
    var o = cabecalhoV(W, "MAPA DA ABSTENÇÃO", "% de eleitores que não foram votar");
    o += mapaAbst(35, 170, 0.767, 13);
    o += t(35, 700, "BRASIL", { s: 16, b: true, c: C.apagado, ls: 2 }) + t(35, 752, e ? pct(e.pct_abstencao) : "0,00%", { s: 52, b: true });
    if (L.length) {
      o += t(280, 700, "MAIOR", { s: 14, b: true, c: C.apagado, ls: 2 });
      L.slice(0, 2).forEach(function (it, i) { o += t(280, 726 + i * 26, it.u + "  " + pct(it.p), { s: 18, b: true }); });
      o += t(410, 700, "MENOR", { s: 14, b: true, c: C.apagado, ls: 2 });
      L.slice(-2).reverse().forEach(function (it, i) { o += t(410, 726 + i * 26, it.u + "  " + pct(it.p), { s: 18, b: true }); });
    }
    FAIXAS_ABST.forEach(function (f, i) {
      var cx = 35 + (i % 3) * 160, cy = 812 + Math.floor(i / 3) * 34;
      o += r(cx, cy - 15, 20, 20, f.cor, 3) + t(cx + 30, cy, f.rot, { s: 15, c: C.apagado });
    });
    return svg(W, H, o + RODAPE_V());
  };

  // =========================================================== RESULTADO FINAL
  // ---- Presidente: so os dois do 2o turno ----------------------------------
  // "Vao ao 2o turno" com a palavra do TSE (2o turno no st) ou com a
  // totalizacao final sem ninguem acima de 50%; antes disso, a tela diz
  // "1o e 2o colocados" e o selo fica PARCIAL.
  function doisDoSegundoTurno() {
    var b = br(), cs = candidatos(b);
    // Boletim do 2o turno: o TSE manda so os dois candidatos.
    if (cs.length === 2) return { cs: cs, definido: true, turno2: true, fim: !!(b && b.andamento === "f") };
    var marcados = cs.filter(function (c) { return c.segundo_turno; });
    if (marcados.length >= 2) return { cs: marcados.slice(0, 2), definido: true };
    var top = cs.slice(0, 2);
    var fim = !!(b && b.andamento === "f" && top.length === 2 && !(top[0].pct > 50));
    return { cs: top, definido: fim };
  }
  function cartaoPres(x, y, w, h, c, pos, k) {
    var o = r(x, y, w, h, "rgba(8,14,32,0.78)", 10);
    if (!c) return o + t(x + 32 * k, y + 80 * k, "aguardando o TSE", { s: Math.round(24 * k), c: C.apagado });
    o += r(x, y, w, 8, cor(c), 4);
    var url = urlFoto(c), px = x + 32 * k, dx = 0;
    if (url) { var fw = 165 * k, fh = fw * 4 / 3; o += foto(url, px, y + 44 * k, fw, fh); dx = fw + 28 * k; }
    o += t(px + dx, y + 74 * k, pos + "º COLOCADO", { s: Math.round(16 * k), b: true, c: C.apagado, ls: 2 });
    o += t(px + dx, y + 118 * k, c.nome, { s: Math.round(40 * k), b: true, max: w - 64 * k - dx, nome: true });
    o += t(px + dx, y + 152 * k, c.partido, { s: Math.round(22 * k), c: C.apagado, max: w - 64 * k - dx });
    o += t(x + w - 32 * k, y + h - 110 * k, pct(c.pct), { s: Math.round(92 * k), b: true, a: "end" });
    o += t(x + w - 32 * k, y + h - 74 * k, "dos votos válidos", { s: Math.round(18 * k), c: C.apagado, a: "end" });
    o += t(x + w - 32 * k, y + h - 38 * k, inteiro(c.votos) + " votos", { s: Math.round(22 * k), c: C.apagado, a: "end" });
    if (c.eleito) o += r(px + dx, y + 172 * k, 112 * k, 32 * k, C.verde, 4) + t(px + dx + 56 * k, y + 195 * k, "ELEITO", { s: Math.round(20 * k), b: true, a: "middle" });
    return o;
  }
  function titulos2t(d) {
    if (d.turno2) return { tit: "PRESIDENTE — 2º TURNO", sub: "% dos votos válidos" + (d.fim ? "" : "  ·  parcial") };
    return { tit: d.definido ? "PRESIDENTE — 2º TURNO" : "PRESIDENTE — 1º E 2º COLOCADOS",
             sub: (d.definido ? "vão ao 2º turno" : "parcial") + "  ·  % dos votos válidos no 1º turno" };
  }
  G["pres2t-h"] = function () {
    var W = 1280, H = 720, d = doisDoSegundoTurno(), b = br();
    var tt = titulos2t(d), o = cabecalhoH(W, tt.tit, tt.sub + "  ·  " + subtitulo());
    o += cartaoPres(73, 130, 544, 510, d.cs[0], 1, 1) + cartaoPres(663, 130, 544, 510, d.cs[1], 2, 1);
    var s = b ? b.secoes : null;
    o += t(73, 690, (s ? "urnas apuradas " + pct(s.pct) + "  ·  " : "") + "Fonte: TSE", { s: 14, c: C.apagado2 });
    var dif = diferenca(d.cs);
    if (dif) o += t(1207, 690, dif, { s: 18, b: true, a: "end", max: 760 });
    return svg(W, H, o);
  };
  G["pres2t-v"] = function () {
    var W = 540, H = 960, d = doisDoSegundoTurno();
    var o = cabecalhoV(W, d.definido ? "PRESIDENTE — 2º TURNO" : "PRESIDENTE",
      (d.turno2 ? "% dos votos válidos" : (d.definido ? "vão ao 2º turno" : "1º e 2º colocados")) + " · " + subtitulo());
    o += cartaoPres(35, 170, 470, 360, d.cs[0], 1, 0.74) + cartaoPres(35, 545, 470, 360, d.cs[1], 2, 0.74);
    var dif = diferenca(d.cs);
    if (dif) o += t(35, 925, dif, { s: 14, b: true, max: 470 });
    return svg(W, H, o + t(35, 950, "Fonte: TSE", { s: 12, c: C.apagado2 }));
  };

  // ---- Senado: hemiciclo (81 cadeiras), atual x 2027 ------------------------
  // Numeros por partido em web\senado-config.js (nao saem do boletim do TSE).
  function senado() {
    var cfg = window.GCTSE_SENADO || { partidos: [] }, ps = (cfg.partidos || []).filter(function (p) { return p && p.sigla; });
    var sa = 0, sn = 0;
    ps.forEach(function (p) { sa += +p.atual || 0; sn += +p.em2027 || 0; });
    return { ps: ps, totalAtual: sa, total2027: sn, fonte: cfg.fonte || "" };
  }
  // Cadeiras em fileiras concentricas; partidos em fatias, da esquerda para
  // a direita na ordem do senado-config.js.
  function hemiciclo(cx, cy, R, r0, ps, campo) {
    var n = 0; ps.forEach(function (p) { n += Math.max(0, +p[campo] || 0); });
    if (!n) return "";
    var filas = n <= 40 ? 3 : (n <= 100 ? 5 : Math.round(Math.sqrt(n / 3))), raios = [], soma = 0, i, j;
    for (i = 0; i < filas; i++) { raios.push(r0 + (R - r0) * i / (filas - 1)); soma += raios[i]; }
    var porFila = raios.map(function (rr) { return Math.max(1, Math.round(n * rr / soma)); });
    var dif = n - porFila.reduce(function (a, b) { return a + b; }, 0);
    porFila[filas - 1] += dif;
    var pos = [];
    for (i = 0; i < filas; i++) for (j = 0; j < porFila[i]; j++) {
      var ang = porFila[i] > 1 ? Math.PI - Math.PI * j / (porFila[i] - 1) : Math.PI / 2;
      pos.push({ a: ang, r: raios[i] });
    }
    pos.sort(function (p, q) { return (q.a - p.a) || (p.r - q.r); });
    var passoR = (R - r0) / (filas - 1), passoA = Math.PI * R / Math.max(1, porFila[filas - 1] - 1);
    var raio = Math.min(passoR, passoA) * 0.42, cores = [], o = "";
    ps.forEach(function (p) { for (var k = 0; k < (+p[campo] || 0); k++) cores.push(p.cor || C.outros); });
    pos.forEach(function (p, k) {
      o += '<circle cx="' + (cx + p.r * Math.cos(p.a)).toFixed(1) + '" cy="' + (cy - p.r * Math.sin(p.a)).toFixed(1) +
        '" r="' + raio.toFixed(1) + '" fill="' + (cores[k] || C.trilho) + '"/>';
    });
    return o;
  }
  function saldo(p) {
    var d = (+p.em2027 || 0) - (+p.atual || 0);
    if (d > 0) return { txt: "+" + d, c: "#69db7c" };
    if (d < 0) return { txt: "−" + (-d), c: "#ff8787" };
    return { txt: "0", c: C.apagado };
  }
  function tabelaSenado(x0, x1, y, passo, ps, s, colunas) {
    var o = t(x0 + 20, y, "PARTIDO", { s: s - 4, b: true, c: C.apagado, ls: 1 });
    colunas.forEach(function (cl) { o += t(cl.x, y, cl.rot, { s: s - 4, b: true, c: C.apagado, a: "end", ls: 1 }); });
    o += r(x0, y + 10, x1 - x0, 1, C.linha);
    var lin = ps.slice().sort(function (a, b) { return (b.em2027 - a.em2027) || (b.atual - a.atual) || String(a.sigla).localeCompare(b.sigla); });
    lin.forEach(function (p, i) {
      var yy = y + 10 + passo * (i + 1) - passo * 0.3;
      o += '<circle cx="' + (x0 + 7) + '" cy="' + (yy - s * 0.35).toFixed(1) + '" r="' + (s * 0.33).toFixed(1) + '" fill="' + (p.cor || C.outros) + '"/>';
      o += t(x0 + 20, yy, p.sigla, { s: s, b: true });
      colunas.forEach(function (cl) {
        if (cl.campo === "saldo") { var sd = saldo(p); o += t(cl.x, yy, sd.txt, { s: s, b: true, c: sd.c, a: "end" }); }
        else o += t(cl.x, yy, String(+p[cl.campo] || 0), { s: s, b: cl.campo === "em2027", c: cl.campo === "em2027" ? C.texto : C.apagado, a: "end" });
      });
    });
    return o;
  }
  function rotuloHemi(cx, cy, txt, n, k) {
    return t(cx, cy - 44 * k, txt, { s: Math.round(16 * k), b: true, c: C.apagado, a: "middle", ls: 2 }) +
      t(cx, cy - 4 * k, String(n), { s: Math.round(42 * k), b: true, a: "middle" });
  }
  G["senado-h"] = function () {
    var W = 1280, H = 720, sd = senado();
    var o = t(73, 57, "SENADO FEDERAL", { s: 36, b: true, ls: 1 }) +
      t(73, 85, sd.total2027 + " cadeiras  ·  composição atual e a partir de 2027", { s: 19, c: C.apagado });
    o += hemiciclo(300, 345, 200, 92, sd.ps, "atual") + rotuloHemi(300, 345, "ATUAL", sd.totalAtual, 1);
    o += hemiciclo(300, 640, 200, 92, sd.ps, "em2027") + rotuloHemi(300, 640, "2027", sd.total2027, 1);
    o += tabelaSenado(620, 1207, 150, 31.5, sd.ps, 20,
      [{ x: 960, rot: "ATUAL", campo: "atual" }, { x: 1085, rot: "2027", campo: "em2027" }, { x: 1207, rot: "SALDO", campo: "saldo" }]);
    if (sd.fonte) o += t(73, 700, sd.fonte, { s: 13, c: C.apagado2 });
    return svg(W, H, o);
  };
  G["senado-v"] = function () {
    var W = 540, H = 960, sd = senado();
    var o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "SENADO FEDERAL", { s: 32, b: true, ls: 1 }) +
      t(53, 106, sd.total2027 + " cadeiras a partir de 2027", { s: 16, c: C.apagado });
    o += hemiciclo(270, 405, 225, 100, sd.ps, "em2027") + rotuloHemi(270, 405, "2027", sd.total2027, 1);
    o += tabelaSenado(40, 505, 452, 28, sd.ps, 19,
      [{ x: 330, rot: "ATUAL", campo: "atual" }, { x: 420, rot: "2027", campo: "em2027" }, { x: 505, rot: "SALDO", campo: "saldo" }]);
    if (sd.fonte) o += t(35, 950, sd.fonte, { s: 12, c: C.apagado2 });
    return svg(W, H, o);
  };

  // ---- Camara dos Deputados: bancadas eleitas (TSE) -------------------------
  function corPartidoCamara(sg, i) {
    var cfg = window.GCTSE_CAMARA || {}, k = String(sg || "").toUpperCase().trim();
    if (cfg.cores && cfg.cores[k]) return cfg.cores[k];
    var sen = ((window.GCTSE_SENADO || {}).partidos || []).filter(function (p) { return String(p.sigla).toUpperCase() === k; })[0];
    if (sen && sen.cor) return sen.cor;
    var reserva = ["#7f8ca3", "#9aa7bd", "#6b7688", "#b0bccf"];
    return reserva[i % reserva.length];
  }
  function camara() {
    var e = window.GCTSE_ESTADOS || {}, cm = e.camara || {}, soma = {}, vagas = 0, eleitos = 0, ufs = 0, finais = 0;
    Object.keys(cm).forEach(function (u) {
      var x = cm[u]; if (!x) return;
      ufs++; vagas += +x.vagas || 0; eleitos += +x.eleitos || 0; if (x.andamento === "f") finais++;
      var ps = x.partidos || {};
      Object.keys(ps).forEach(function (sg) { soma[sg] = (soma[sg] || 0) + (+ps[sg] || 0); });
    });
    var cfg = window.GCTSE_CAMARA || {}, atual = cfg.atual || {}, temAtual = Object.keys(atual).length > 0;
    var lista = Object.keys(soma).map(function (sg) { return { sigla: sg, em2027: soma[sg], atual: +atual[sg] || 0 }; });
    if (temAtual) Object.keys(atual).forEach(function (sg) { if (!(sg in soma)) lista.push({ sigla: sg, em2027: 0, atual: +atual[sg] || 0 }); });
    lista.sort(function (a, b) { return (b.em2027 - a.em2027) || (b.atual - a.atual) || a.sigla.localeCompare(b.sigla); });
    lista.forEach(function (p, i) { p.cor = corPartidoCamara(p.sigla, i); });
    // 513 = total fixo da Camara (LC 78/1993); a soma das vagas so vale com os 27 estados lidos.
    return { ps: lista, vagas: ufs >= 27 && vagas ? vagas : 513, eleitos: eleitos, ufs: ufs, finais: finais, temAtual: temAtual, fonteAtual: cfg.fonte_atual || "" };
  }
  // Tabela com no maximo n linhas: o resto vira "OUTROS (k partidos)".
  function linhasCamara(ps, n) {
    if (ps.length <= n) return ps;
    var resto = ps.slice(n - 1), o = { sigla: "OUTROS (" + resto.length + ")", em2027: 0, atual: 0, cor: "#5c6b82" };
    resto.forEach(function (p) { o.em2027 += p.em2027; o.atual += p.atual; });
    return ps.slice(0, n - 1).concat([o]);
  }
  function tabelaCamara(x0, x1, y, passo, cm, s, n, colX) {
    var lin = linhasCamara(cm.ps, n), cols = cm.temAtual ?
      [{ x: colX[0], rot: "ATUAL", f: function (p) { return String(p.atual); }, c: C.apagado },
       { x: colX[1], rot: "2027", f: function (p) { return String(p.em2027); }, c: C.texto, b: true },
       { x: colX[2], rot: "SALDO", saldo: true }] :
      [{ x: colX[1], rot: "CADEIRAS", f: function (p) { return String(p.em2027); }, c: C.texto, b: true },
       { x: colX[2], rot: "%", f: function (p) { return cm.eleitos ? (p.em2027 / cm.eleitos * 100).toFixed(1).replace(".", ",") + "%" : "—"; }, c: C.apagado }];
    var o = t(x0 + 20, y, "PARTIDO", { s: s - 4, b: true, c: C.apagado, ls: 1 });
    cols.forEach(function (cl) { o += t(cl.x, y, cl.rot, { s: s - 4, b: true, c: C.apagado, a: "end", ls: 1 }); });
    o += r(x0, y + 10, x1 - x0, 1, C.linha);
    lin.forEach(function (p, i) {
      var yy = y + 10 + passo * (i + 1) - passo * 0.3;
      o += '<circle cx="' + (x0 + 7) + '" cy="' + (yy - s * 0.35).toFixed(1) + '" r="' + (s * 0.33).toFixed(1) + '" fill="' + p.cor + '"/>';
      o += t(x0 + 20, yy, p.sigla, { s: s, b: true, max: (cm.temAtual ? colX[0] : colX[1]) - x0 - 85 });
      cols.forEach(function (cl) {
        if (cl.saldo) { var sd = saldo(p); o += t(cl.x, yy, sd.txt, { s: s, b: true, c: sd.c, a: "end" }); }
        else o += t(cl.x, yy, cl.f(p), { s: s, b: !!cl.b, c: cl.c, a: "end" });
      });
    });
    return o;
  }
  // Enquanto o TSE nao define todas as vagas, as cadeiras que faltam aparecem
  // vazias (cor do trilho) no fim do hemiciclo.
  function hemiCamara(cm) {
    var l = linhasCamara(cm.ps, 15), falta = cm.vagas - cm.eleitos;
    return falta > 0 ? l.concat([{ sigla: "", em2027: falta, cor: C.trilho }]) : l;
  }
  function subCamara(cm) {
    if (!cm.ufs) return "aguardando os deputados eleitos (ESTADOS.bat)";
    if (cm.eleitos >= cm.vagas) return cm.vagas + " cadeiras  ·  bancadas eleitas em 2026";
    return cm.eleitos + " de " + cm.vagas + " cadeiras definidas pelo TSE";
  }
  function rodapeCamara(cm) {
    return "Fonte: TSE — deputados federais eleitos" + (cm.temAtual && cm.fonteAtual ? "  ·  composição atual: " + cm.fonteAtual : "");
  }
  G["camara-h"] = function () {
    var W = 1280, H = 720, cm = camara();
    var o = t(73, 57, "CÂMARA DOS DEPUTADOS", { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, subCamara(cm), { s: 19, c: C.apagado });
    // O hemiciclo usa as mesmas linhas da tabela (o "OUTROS" fica cinza nos dois).
    o += hemiciclo(385, 640, 320, 120, hemiCamara(cm), "em2027") + rotuloHemi(385, 640, "2027", cm.eleitos, 1.1);
    o += tabelaCamara(745, 1207, 150, 32, cm, 20, 15, [1010, 1110, 1207]);
    o += t(73, 700, rodapeCamara(cm), { s: 13, c: C.apagado2, max: 1134 });
    return svg(W, H, o);
  };
  G["camara-v"] = function () {
    var W = 540, H = 960, cm = camara();
    var o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "CÂMARA DOS DEPUTADOS", { s: 30, b: true, ls: 1, max: W - 53 - 35 }) +
      t(53, 106, subCamara(cm), { s: 15, c: C.apagado, max: W - 53 - 35 });
    o += hemiciclo(270, 400, 232, 88, hemiCamara(cm), "em2027") + rotuloHemi(270, 400, "2027", cm.eleitos, 1);
    o += tabelaCamara(40, 505, 448, 29, cm, 19, 15, [330, 420, 505]);
    return svg(W, H, o + t(35, 950, rodapeCamara(cm), { s: 11, c: C.apagado2, max: 470 }));
  };
  // ---- ASSEMBLEIA LEGISLATIVA (deputados estaduais; DF: distritais) ---------
  // Por estado, escolhido no gerenciador (?a=pr ou rodizio "assembleia:pr").
  // Bancadas = candidatos que o TSE marcou como eleitos (ESTADOS.bat, cargo
  // 7; no DF, cargo 8). Mesmo desenho da Camara.
  function assembleia(u) {
    var x = ((window.GCTSE_ESTADOS || {}).assembleia || {})[u], soma = (x && x.partidos) || {};
    var lista = Object.keys(soma).map(function (sg) { return { sigla: sg, em2027: +soma[sg] || 0, atual: 0 }; })
      .sort(function (a, b) { return (b.em2027 - a.em2027) || a.sigla.localeCompare(b.sigla); });
    lista.forEach(function (p, i) { p.cor = corPartidoCamara(p.sigla, i); });
    return { ps: lista, vagas: x ? +x.vagas || 0 : 0, eleitos: x ? +x.eleitos || 0 : 0, ufs: x ? 1 : 0, temAtual: false, urnas: x ? x.urnas_pct : null, top: x ? comoLista(x.lista) : [] };
  }
  function nomeCasa(u) { return u === "df" ? "CÂMARA LEGISLATIVA" : "ASSEMBLEIA LEGISLATIVA"; }
  function subAsm(u, cm) {
    var cargo = u === "df" ? "deputados distritais" : "deputados estaduais";
    if (!cm.ufs) return "aguardando os " + cargo + " eleitos (ESTADOS.bat)";
    if (cm.eleitos >= cm.vagas) return cm.vagas + " cadeiras  ·  " + cargo + " eleitos em 2026";
    return cm.eleitos + " de " + cm.vagas + " cadeiras definidas pelo TSE";
  }
  function semAsm(W, H, v, u) {
    var mot = ((window.GCTSE_ESTADOS || {}).assembleia_motivos || {})[u];
    return t(W / 2, H / 2, "aguardando os eleitos de " + (DEP_UF[u] || u.toUpperCase()), { s: v ? 18 : 24, c: C.apagado, a: "middle", max: W - 60 }) +
      (mot ? t(W / 2, H / 2 + 30, mot, { s: v ? 12 : 15, c: C.apagado2, a: "middle", max: W - 60 }) : "");
  }
  function seloAsm(cm) {
    if (!cm.eleitos) return { texto: "AGUARDANDO", cor: C.trilho };
    return cm.eleitos >= cm.vagas ? { texto: "TOTALIZAÇÃO FINAL", cor: C.verde } : { texto: "PARCIAL", cor: C.vermelho };
  }
  function telaAsm(v) {
    var u = alvoAtual(); if (!DEP_UF[u]) u = "sp";
    var cm = assembleia(u), W = v ? 540 : 1280, H = v ? 960 : 720, o, rod = "Fonte: TSE — " + (u === "df" ? "deputados distritais (cargo 8)" : "deputados estaduais (cargo 7)") + " eleitos";
    var n = cm.ps.length > 15 ? 15 : Math.max(cm.ps.length, 1);
    if (!v) {
      o = t(73, 57, DEP_UF[u], { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, nomeCasa(u) + "  ·  " + subAsm(u, cm), { s: 18, c: C.apagado, max: 660 }) + seloH(W, seloAsm(cm));
      if (!cm.eleitos) return svg(W, H, o + semAsm(W, H, false, u));
      o += hemiciclo(385, 640, 320, 120, hemiCamara(cm), "em2027") + rotuloHemi(385, 640, "2027", cm.eleitos, 1.1);
      o += tabelaCamara(745, 1207, 150, Math.min(32, 480 / n), cm, 20, 15, [1010, 1110, 1207]);
      return svg(W, H, o + t(73, 700, rod, { s: 13, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, DEP_UF[u], { s: 30, b: true, ls: 1, max: W - 88 }) + t(53, 106, nomeCasa(u) + " · " + subAsm(u, cm), { s: 13, c: C.apagado, max: W - 88 }) +
      seloV(W, seloAsm(cm));
    if (!cm.eleitos) return svg(W, H, o + semAsm(W, H, true, u));
    o += hemiciclo(270, 400, 232, 88, hemiCamara(cm), "em2027") + rotuloHemi(270, 400, "2027", cm.eleitos, 1);
    o += tabelaCamara(40, 505, 448, Math.min(29, 460 / n), cm, 19, 15, [330, 420, 505]);
    return svg(W, H, o + t(35, 950, rod, { s: 11, c: C.apagado2, max: 470 }));
  }
  G["assembleia-h"] = function () { return telaAsm(false); };
  G["assembleia-v"] = function () { return telaAsm(true); };

  // ---- ASSEMBLEIAS: PANORAMA BRASIL (soma dos 27 estados, por partido) ------
  function assembleiasBr() {
    var a = (window.GCTSE_ESTADOS || {}).assembleia || {}, soma = {}, vagas = 0, eleitos = 0, ufs = 0, comEl = 0;
    Object.keys(a).forEach(function (u) {
      var x = a[u]; if (!x) return;
      ufs++; vagas += +x.vagas || 0; eleitos += +x.eleitos || 0; if (+x.eleitos > 0) comEl++;
      var ps = x.partidos || {};
      Object.keys(ps).forEach(function (sg) { soma[sg] = (soma[sg] || 0) + (+ps[sg] || 0); });
    });
    var lista = Object.keys(soma).map(function (sg) { return { sigla: sg, em2027: soma[sg], atual: 0 }; })
      .sort(function (p, q) { return (q.em2027 - p.em2027) || p.sigla.localeCompare(q.sigla); });
    lista.forEach(function (p, i) { p.cor = corPartidoCamara(p.sigla, i); });
    return { ps: lista, vagas: vagas, eleitos: eleitos, ufs: ufs, comEl: comEl, temAtual: false };
  }
  function subAsmBr(cm) {
    if (!cm.eleitos) return "aguardando os deputados estaduais eleitos (ESTADOS.bat)";
    var n = inteiro(cm.eleitos);
    return n + " deputados estaduais e distritais eleitos" + (cm.comEl < 27 ? " · " + cm.comEl + " de 27 estados" : " · soma dos 27 estados");
  }
  function telaAsmBr(v) {
    var cm = assembleiasBr(), W = v ? 540 : 1280, H = v ? 960 : 720, o, tit = "ASSEMBLEIAS LEGISLATIVAS";
    var sl = !cm.eleitos ? { texto: "AGUARDANDO", cor: C.trilho } : (cm.comEl >= 27 && cm.eleitos >= cm.vagas ? { texto: "TOTALIZAÇÃO FINAL", cor: C.verde } : { texto: "PARCIAL", cor: C.vermelho });
    var rod = "Fonte: TSE — deputados estaduais (cargo 7) e distritais do DF (cargo 8) eleitos, somados por partido";
    // o hemiciclo vira por partido em proporcao (1.059 cadeiras nao cabem uma a uma)
    if (!v) {
      o = t(73, 57, tit + " — BRASIL", { s: 34, b: true, ls: 1, max: 667 }) + t(73, 85, subAsmBr(cm), { s: 18, c: C.apagado, max: 660 }) + seloH(W, sl);
      if (!cm.eleitos) return svg(W, H, marcaVazio() + o + t(640, 380, "aguardando o ESTADOS.bat ler as Assembleias", { s: 22, c: C.apagado, a: "middle" }));
      o += hemiciclo(385, 640, 320, 120, hemiCamara(cm), "em2027") + rotuloHemi(385, 640, "2027", cm.eleitos, 1.1);
      o += tabelaCamara(745, 1207, 150, 32, cm, 20, 15, [1010, 1110, 1207]);
      return svg(W, H, o + t(73, 700, rod, { s: 12, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "ASSEMBLEIAS — BRASIL", { s: 28, b: true, ls: 1, max: W - 88 }) + t(53, 106, subAsmBr(cm), { s: 13, c: C.apagado, max: W - 88 }) + seloV(W, sl);
    if (!cm.eleitos) return svg(W, H, marcaVazio() + o + t(270, 480, "aguardando o ESTADOS.bat", { s: 18, c: C.apagado, a: "middle" }));
    o += hemiciclo(270, 400, 232, 88, hemiCamara(cm), "em2027") + rotuloHemi(270, 400, "2027", cm.eleitos, 1);
    o += tabelaCamara(40, 505, 448, 29, cm, 19, 15, [330, 420, 505]);
    return svg(W, H, o + t(35, 950, "Fonte: TSE — deputados estaduais e distritais eleitos", { s: 11, c: C.apagado2, max: 470 }));
  }
  G["assembleias-h"] = function () { return telaAsmBr(false); };
  G["assembleias-v"] = function () { return telaAsmBr(true); };

  // ---- OS 10 DEPUTADOS FEDERAIS MAIS VOTADOS DO BRASIL ----------------------
  // Eleitos marcados pelo TSE em cada estado (ESTADOS.bat), juntos e
  // ordenados pelos votos nominais do proprio boletim.
  // filtro opcional (c -> true/false): ex. so as mulheres (tela "10 deputadas")
  function topDep(n, filtro) {
    var cm = (window.GCTSE_ESTADOS || {}).camara || {}, todos = [], ufs = 0;
    Object.keys(cm).forEach(function (u) { var l = comoLista((cm[u] || {}).lista); if (l.length) ufs++; l.forEach(function (c) { if (!filtro || filtro(c)) todos.push({ c: c, u: u }); }); });
    todos.sort(function (a, b) { return ((+b.c.votos || 0) - (+a.c.votos || 0)) || String(a.c.nome).localeCompare(String(b.c.nome), "pt-BR"); });
    return { lista: todos.slice(0, n), ufs: ufs, total: todos.length };
  }
  // M = tela das mulheres: so as eleitas cujo registro no arquivo
  // "Candidatos" do TSE (IMPORTAR-CANDIDATOS.bat) e FEMININO
  function telaTopDep(v, M) {
    var W = v ? 540 : 1280, H = v ? 960 : 720, fem = null;
    if (M) {
      var gen = window.GCTSE_GENERO, a26 = gen && gen.anos ? gen.anos["2026"] : null;
      if (!a26) return semDados(W, H, v, "AS 10 DEPUTADAS MAIS VOTADAS", "importe o arquivo de candidatos do TSE (IMPORTAR-CANDIDATOS.bat)");
      fem = {}; comoLista(a26.mulheres).forEach(function (q) { fem[q] = 1; });
    }
    var T = topDep(10, fem ? function (c) { return !!fem[c.sqcand]; } : null), o, l = T.lista, max = l.length ? +l[0].c.votos || 1 : 1;
    var sub = M ? "Câmara dos Deputados · " + T.total + (T.total === 1 ? " mulher eleita" : " mulheres eleitas") + " · votos nominais" + (T.ufs && T.ufs < 27 ? " · " + T.ufs + " de 27 estados lidos" : "")
      : "Câmara dos Deputados · votos nominais" + (T.ufs && T.ufs < 27 ? " · " + T.ufs + " de 27 estados lidos" : "");
    var sl = !T.ufs ? { texto: "AGUARDANDO", cor: C.trilho } : (T.ufs >= 27 ? { texto: "TOTALIZAÇÃO FINAL", cor: C.verde } : { texto: "PARCIAL", cor: C.vermelho });
    if (!v) {
      o = t(73, 57, M ? "AS 10 DEPUTADAS MAIS VOTADAS" : "OS 10 DEPUTADOS FEDERAIS MAIS VOTADOS", { s: 32, b: true, ls: 1, max: 667 }) + t(73, 85, sub, { s: 17, c: C.apagado, max: 660 }) + seloH(W, sl);
      if (!l.length) return svg(W, H, marcaVazio() + o + t(640, 380, "aguardando os deputados eleitos (ESTADOS.bat)", { s: 22, c: C.apagado, a: "middle" }));
      l.forEach(function (it, i) {
        var y = 106 + i * 58, c = it.c, cc = corPartidoCamara(c.partido, i);
        o += r(73, y, 1134, 52, i % 2 ? "rgba(8,14,32,0.70)" : "rgba(8,14,32,0.86)", 6);
        o += t(120, y + 36, (i + 1) + "º", { s: 24, b: true, a: "end", c: i < 3 ? "#ffd43b" : C.texto });
        o += fotoDep(it.u, c, 134, y + 4, 33, 44);
        o += r(178, y + 10, 5, 32, cc, 2);
        o += t(193, y + 25, c.nome, { s: 21, b: true, max: 450 }) + t(193, y + 44, (c.partido || "") + "  ·  " + (DEP_UF[it.u] || it.u.toUpperCase()), { s: 13, c: C.apagado, max: 450 });
        o += barraFina(680, y + 22, 330, (+c.votos || 0) / max, cc);
        o += t(1190, y + 33, inteiro(c.votos), { s: 24, b: true, a: "end" }) + t(1190, y + 48, "votos", { s: 10, c: C.apagado, a: "end" });
      });
      return svg(W, H, o + t(73, 704, M ? "Fonte: TSE — boletins de Deputado Federal (eleitas) e gênero do arquivo Candidatos 2026 (Dados Abertos)" : "Fonte: TSE — boletins de Deputado Federal dos 27 estados (entre os eleitos)", { s: 12, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, M ? COR_MULHER : C.destaque) + t(53, 80, M ? "10 DEPUTADAS" : "10 MAIS VOTADOS", { s: 30, b: true, ls: 1 }) + t(53, 106, M ? "as mulheres mais votadas · " + T.total + " eleitas" : "Deputados federais · Brasil", { s: 14, c: C.apagado }) + seloV(W, sl);
    if (!l.length) return svg(W, H, marcaVazio() + o + t(270, 480, "aguardando os deputados eleitos", { s: 18, c: C.apagado, a: "middle" }));
    l.forEach(function (it, i) {
      var y = 164 + i * 77, c = it.c, cc = corPartidoCamara(c.partido, i);
      o += r(35, y, 470, 71, i % 2 ? "rgba(8,14,32,0.70)" : "rgba(8,14,32,0.86)", 6);
      o += t(72, y + 44, (i + 1) + "º", { s: 22, b: true, a: "end", c: i < 3 ? "#ffd43b" : C.texto });
      o += fotoDep(it.u, c, 82, y + 8, 41, 55);
      o += r(131, y + 12, 4, 46, cc, 2);
      o += t(143, y + 30, c.nome, { s: 18, b: true, max: 350 }) + t(143, y + 50, (c.partido || "") + " · " + it.u.toUpperCase(), { s: 12, c: C.apagado, max: 200 });
      o += t(495, y + 52, inteiro(c.votos) + " votos", { s: 15, b: true, a: "end" });
    });
    return svg(W, H, o + t(35, 950, M ? "Fonte: TSE — eleitas + arquivo Candidatos 2026" : "Fonte: TSE — entre os deputados federais eleitos", { s: 11, c: C.apagado2 }));
  }
  G["topdep-h"] = function () { return telaTopDep(false); };
  G["topdep-v"] = function () { return telaTopDep(true); };
  G["topfem-h"] = function () { return telaTopDep(false, true); };
  G["topfem-v"] = function () { return telaTopDep(true, true); };

  // ---- JORNALISMO: AS 10 SENADORAS MAIS VOTADAS ------------------------------
  // Candidatas ao Senado (boletim de Senador do TSE, ESTADOS.bat) cujo
  // registro no arquivo "Candidatos" do TSE e FEMININO (IMPORTAR-CANDIDATOS).
  function telaTopSenFem(v) {
    var W = v ? 540 : 1280, H = v ? 960 : 720, tit = "SENADORAS ELEITAS";
    var gen = window.GCTSE_GENERO, a26 = gen && gen.anos ? gen.anos["2026"] : null;
    if (!a26) return semDados(W, H, v, tit, "importe o arquivo de candidatos do TSE (IMPORTAR-CANDIDATOS.bat)");
    if (!a26.mulheres_senado) return semDados(W, H, v, tit, "rode de novo o IMPORTAR-CANDIDATOS.bat (agora ele lê também o Senado)");
    var fem = {}; comoLista(a26.mulheres_senado).forEach(function (q) { fem[q] = 1; });
    // so as ELEITAS (marca do TSE no boletim de Senador), da mais votada para a menos
    var u = (window.GCTSE_ESTADOS || {}).ufs || {}, l = [], ufs = 0, nCand = 0;
    Object.keys(DEP_UF).forEach(function (k) {
      var s0 = u[k] && u[k].sen && u[k].sen.tem ? u[k].sen : null; if (!s0) return; ufs++;
      comoLista(s0.candidatos).forEach(function (c) { if (fem[c.sqcand]) { nCand++; if (c.eleito) l.push({ c: c, u: k }); } });
    });
    if (!ufs) return semDados(W, H, v, tit, "aguardando o boletim de Senador (ESTADOS.bat)");
    if (!l.length) return semDados(W, H, v, tit, "nenhuma senadora eleita ainda (TSE)");
    l.sort(function (a, b) { return ((+b.c.votos || 0) - (+a.c.votos || 0)) || String(a.c.nome).localeCompare(String(b.c.nome), "pt-BR"); });
    l = l.slice(0, 14);
    var max = +l[0].c.votos || 1, n = l.length, o;
    var sl = ufs >= 27 ? { texto: "1º TURNO · FINAL", cor: C.verde } : { texto: "PARCIAL", cor: C.vermelho };
    var sub = "Senado · " + n + (n === 1 ? " mulher eleita" : " mulheres eleitas") + " · " + nCand + " candidatas" + (ufs < 27 ? " · " + ufs + " de 27 estados" : "");
    if (!v) {
      var ph = Math.min(58, 584 / n), k = ph / 58;   // ate 10 linhas no tamanho cheio; mais que isso, encolhe
      o = t(73, 57, tit, { s: 32, b: true, ls: 1, max: 667 }) + t(73, 85, sub, { s: 17, c: C.apagado, max: 660 }) + seloH(W, sl);
      l.forEach(function (it, i) {
        var y = 106 + i * ph, c = it.c, cc = corPartidoCamara(c.partido, i), hh = ph - 6;
        o += r(73, y, 1134, hh, i % 2 ? "rgba(8,14,32,0.70)" : "rgba(8,14,32,0.86)", 6);
        o += t(120, y + hh * 0.69, (i + 1) + "º", { s: Math.round(24 * k), b: true, a: "end", c: i < 3 ? "#ffd43b" : C.texto });
        o += fotoDep(it.u, c, 134, y + 4 * k, 33 * k, 44 * k) + r(178, y + 10 * k, 5, hh - 20 * k, cc, 2);
        o += t(193, y + hh * 0.48, c.nome, { s: Math.round(21 * k), b: true, max: 470 }) + t(193, y + hh * 0.85, (c.partido || "") + "  ·  " + (DEP_UF[it.u] || it.u.toUpperCase()), { s: Math.round(13 * k), c: C.apagado, max: 470 });
        o += barraFina(690, y + hh * 0.42, 320, (+c.votos || 0) / max, cc);
        o += t(1190, y + hh * 0.63, inteiro(c.votos), { s: Math.round(24 * k), b: true, a: "end" }) + t(1190, y + hh * 0.92, "votos" + (c.pct != null ? " · " + pct1(+c.pct) + " no estado" : ""), { s: Math.round(10 * Math.max(k, 0.9)), c: C.apagado, a: "end" });
      });
      return svg(W, H, o + t(73, 704, "Fonte: TSE — boletins de Senador dos 27 estados (eleitas marcadas pelo TSE) e gênero do arquivo Candidatos 2026 (Dados Abertos)", { s: 12, c: C.apagado2, max: 1134 }));
    }
    var pv = Math.min(77, 766 / n), kv = pv / 77;
    o = r(35, 48, 6, 38, COR_MULHER) + t(53, 80, tit, { s: 30, b: true, ls: 1 }) + t(53, 106, n + (n === 1 ? " eleita" : " eleitas") + " · da mais votada", { s: 14, c: C.apagado }) + seloV(W, sl);
    l.forEach(function (it, i) {
      var y = 164 + i * pv, c = it.c, cc = corPartidoCamara(c.partido, i), hh = pv - 6;
      o += r(35, y, 470, hh, i % 2 ? "rgba(8,14,32,0.70)" : "rgba(8,14,32,0.86)", 6);
      o += t(72, y + hh * 0.62, (i + 1) + "º", { s: Math.round(22 * kv), b: true, a: "end", c: i < 3 ? "#ffd43b" : C.texto });
      o += fotoDep(it.u, c, 82, y + 8 * kv, 41 * kv, 55 * kv) + r(131, y + 12 * kv, 4, hh - 24 * kv, cc, 2);
      o += t(143, y + hh * 0.42, c.nome, { s: Math.round(18 * kv), b: true, max: 350 }) + t(143, y + hh * 0.70, (c.partido || "") + " · " + it.u.toUpperCase(), { s: Math.round(12 * Math.max(kv, 0.9)), c: C.apagado, max: 200 });
      o += t(495, y + hh * 0.79, inteiro(c.votos) + " votos", { s: Math.round(15 * kv), b: true, a: "end" });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — Senado (eleitas) + arquivo Candidatos 2026", { s: 11, c: C.apagado2 }));
  }
  G["topsenfem-h"] = function () { return telaTopSenFem(false); };
  G["topsenfem-v"] = function () { return telaTopSenFem(true); };

  // ---- JORNALISMO: PERFIL DO ELEITOR -----------------------------------------
  // web\perfil-eleitor.js, gravado pelo IMPORTAR-PERFIL-ELEITOR.bat a partir
  // dos arquivos do TSE (Dados Abertos): perfil do eleitorado (quem pode
  // votar) e comparecimento/abstencao por perfil (quem foi as urnas - o TSE
  // publica depois da eleicao). Classe social/renda: o TSE nao coleta.
  function semAcento(x) { return String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase(); }
  var GRUPOS_IDADE = [["16 e 17", 16, 17], ["18 a 24", 18, 24], ["25 a 34", 25, 34], ["35 a 44", 35, 44], ["45 a 59", 45, 59], ["60 a 69", 60, 69], ["70 ou mais", 70, 999]];
  var GRUPO_P = {
    idade: function (rot) { var m = /(\d+)/.exec(rot); if (!m) return null; var n = +m[1]; for (var i = 0; i < GRUPOS_IDADE.length; i++) if (n >= GRUPOS_IDADE[i][1] && n <= GRUPOS_IDADE[i][2]) return GRUPOS_IDADE[i][0]; return null; },
    escolaridade: function (rot) { var x = semAcento(rot); return /ANALFABETO|LE E ESCREVE/.test(x) ? "Sem ensino formal" : /FUNDAMENTAL/.test(x) ? "Fundamental" : /MEDIO/.test(x) ? "Ensino médio" : /SUPERIOR/.test(x) ? "Superior" : null; },
    genero: function (rot) { var x = semAcento(rot); return /^FEM/.test(x) ? "Mulheres" : /^MASC/.test(x) ? "Homens" : null; },
    raca: function (rot) { var x = semAcento(rot); return /^BRANC/.test(x) ? "Branca" : /^PARD/.test(x) ? "Parda" : /^PRET/.test(x) ? "Preta" : /^AMAREL/.test(x) ? "Amarela" : /^INDIGEN/.test(x) ? "Indígena" : null; }
  };
  var ORDEM_P = {
    idade: GRUPOS_IDADE.map(function (g) { return g[0]; }),
    escolaridade: ["Sem ensino formal", "Fundamental", "Ensino médio", "Superior"],
    genero: ["Mulheres", "Homens"], raca: ["Branca", "Parda", "Preta", "Amarela", "Indígena"]
  };
  // -> { itens: [{ rot, a, c }], inf: soma dos informados, tot: soma de tudo } ou null
  function agruparPerfil(dims, d) {
    var m = dims && dims[d]; if (!m) return null;
    var g = {}, inf = 0, tot = 0;
    Object.keys(m).forEach(function (rot) {
      var q = comoLista(m[rot]), a = +q[0] || 0, c = +q[1] || 0, k = GRUPO_P[d](rot); tot += a;
      if (!k) return; inf += a; if (!g[k]) g[k] = { rot: k, a: 0, c: 0 }; g[k].a += a; g[k].c += c;
    });
    return { itens: ORDEM_P[d].filter(function (k) { return g[k]; }).map(function (k) { return g[k]; }), inf: inf, tot: tot };
  }
  function perfilDe(tipo) {
    var P = window.GCTSE_PERFIL, x = P && P[tipo]; if (!x || !x.turnos) return null;
    var ks = Object.keys(x.turnos).sort(), tu = ks[ks.length - 1], b = x.turnos[tu];
    return { ano: x.ano, turno: +tu, total: comoLista(b.total), dims: b.dims || {} };
  }
  // cor na hora de desenhar (COR_MULHER e COR_PERFIL sao definidos mais abaixo)
  function corEleitor(rot) { return rot === "Mulheres" ? COR_MULHER : rot === "Homens" ? "#2b84ff" : COR_PERFIL; }
  // painel de barras: comp = mostra taxa de comparecimento (c/a), senao % do total informado
  function painelEleitor(x, y, w, h, titulo, G0, comp, ref, k, nota) {
    var o = r(x, y, w, h, "rgba(8,14,32,0.84)", 8) + t(x + 16 * k, y + 26 * k, titulo, { s: Math.round(14 * k), b: true, c: "#c9d6e6", ls: 2 });
    if (!G0 || !G0.itens.length) return o + t(x + 16 * k, y + 62 * k, nota || "o arquivo do TSE não traz este dado", { s: Math.round(14 * k), c: C.apagado, max: w - 32 * k });
    var n = G0.itens.length, topo = y + 44 * k, rodape = nota ? 26 * k : 8 * k, passo = Math.min(40 * k, (h - (topo - y) - rodape) / n);
    var vals = G0.itens.map(function (it) { return comp ? (it.a ? 100 * it.c / it.a : 0) : (G0.inf ? 100 * it.a / G0.inf : 0); });
    var max = comp ? 100 : Math.max.apply(null, vals.concat([1])), xb = x + 16 * k + 150 * k, wb = w - 32 * k - 150 * k - 70 * k;
    G0.itens.forEach(function (it, i) {
      var yy = topo + i * passo + passo / 2, cr = corEleitor(it.rot);
      o += t(x + 16 * k, yy + 6 * k, it.rot, { s: Math.round(15 * k), b: true, max: 145 * k });
      o += r(xb, yy - 8 * k, wb, 16 * k, "rgba(255,255,255,0.10)", 4) + r(xb, yy - 8 * k, Math.max(4, wb * vals[i] / max), 16 * k, cr, 4);
      o += t(x + w - 16 * k, yy + 6 * k, pct1(vals[i]), { s: Math.round(16 * k), b: true, a: "end" });
    });
    if (comp && ref > 0) { var xr = xb + wb * ref / 100; o += r(xr - 1, topo - 4 * k, 2, n * passo + 4 * k, "#ffd43b", 0); }
    if (nota) o += t(x + 16 * k, y + h - 10 * k, nota, { s: Math.round(11 * k), c: C.apagado, max: w - 32 * k });
    return o;
  }
  function telaPerfilEleitor(v, comp) {
    var W = v ? 540 : 1280, H = v ? 960 : 720, o;
    var tit = comp ? "QUEM FOI ÀS URNAS" : "PERFIL DO ELEITORADO";
    var Pf = perfilDe(comp ? "comparecimento" : "eleitorado");
    if (!Pf) return semDados(W, H, v, tit, comp ? "o TSE publica o comparecimento por perfil depois da eleição · rode o IMPORTAR-PERFIL-ELEITOR.bat" : "rode o IMPORTAR-PERFIL-ELEITOR.bat (perfil do eleitorado do TSE)");
    var gI = agruparPerfil(Pf.dims, "idade"), gS = agruparPerfil(Pf.dims, "genero"), gE = agruparPerfil(Pf.dims, "escolaridade"), gR = agruparPerfil(Pf.dims, "raca");
    var tot = +Pf.total[0] || 0, cmp = +Pf.total[1] || 0, ref = comp && tot ? 100 * cmp / tot : 0;
    var turnoTxt0 = Pf.turno ? Pf.turno + "º turno de " + Pf.ano : Pf.ano;
    var sub = comp ? "comparecimento por perfil · " + turnoTxt0 + " · " + pct1(ref) + " do eleitorado votou (" + inteiro(cmp) + " de " + inteiro(tot) + ")"
      : "quem pode votar · " + inteiro(tot) + " eleitores aptos · " + Pf.ano;
    var notaR = gR && gR.tot ? pct1(100 * gR.inf / gR.tot) + " dos eleitores declararam cor/raça ao TSE" : null;
    var nRaca = gR ? notaR : "o arquivo do TSE não traz cor/raça";
    var sl = { texto: "DADOS ABERTOS TSE", cor: C.trilho };
    var fonte = "Fonte: TSE — Dados Abertos, " + (comp ? "comparecimento e abstenção por perfil" : "perfil do eleitorado") + " " + Pf.ano + " · " + (comp ? "barras = % que compareceu em cada grupo; linha amarela = média" : "% dos eleitores com o dado informado") + " · renda/classe social: o TSE não coleta";
    if (!v) {
      o = t(73, 57, tit, { s: 34, b: true, ls: 1, max: 660 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 680 }) + seloH(W, sl);
      o += painelEleitor(73, 104, 560, 330, "IDADE", gI, comp, ref, 1);
      o += painelEleitor(73, 446, 560, 236, "ESCOLARIDADE", gE, comp, ref, 1);
      o += painelEleitor(647, 104, 560, 140, "SEXO", gS, comp, ref, 1);
      o += painelEleitor(647, 256, 560, 426, "COR / RAÇA" + (comp ? "" : " (entre quem declarou)"), gR, comp, ref, 1, nRaca);
      return svg(W, H, o + t(73, 704, fonte, { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 26, b: true, ls: 1, max: 450 }) + t(53, 106, comp ? turnoTxt0 + " · " + pct1(ref) + " votou" : inteiro(tot) + " eleitores aptos", { s: 14, c: C.apagado, max: 450 }) + seloV(W, sl);
    o += painelEleitor(35, 160, 470, 260, "IDADE", gI, comp, ref, 0.85);
    o += painelEleitor(35, 430, 470, 110, "SEXO", gS, comp, ref, 0.85);
    o += painelEleitor(35, 550, 470, 175, "ESCOLARIDADE", gE, comp, ref, 0.85);
    o += painelEleitor(35, 735, 470, 195, "COR / RAÇA", gR, comp, ref, 0.85, nRaca);
    return svg(W, H, o + t(35, 950, "Fonte: TSE — Dados Abertos · renda: o TSE não coleta", { s: 10, c: C.apagado2 }));
  }
  G["perfileleitor-h"] = function () { return telaPerfilEleitor(false, false); };
  G["perfileleitor-v"] = function () { return telaPerfilEleitor(true, false); };
  G["foiurnas-h"] = function () { return telaPerfilEleitor(false, true); };
  G["foiurnas-v"] = function () { return telaPerfilEleitor(true, true); };


  // ---- Comparativo 2018 x 2022 x 2026: abstencao, brancos e nulos -----------
  // 2026 ao vivo (dados.js); 2022 do arquivo do TSE (estados.js), senao do
  // comparativo-config.js; 2018 do comparativo-config.js.
  var CORES_ANO = ["#5b7db8", "#2b84ff", "#38d9e8"];
  function anosComparativo() {
    var cfg = (window.GCTSE_COMPARATIVO || {}).anos || [], porAno = {};
    cfg.forEach(function (a) { porAno[a.ano] = { ano: a.ano, abstencao: a.abstencao, brancos: a.brancos, nulos: a.nulos }; });
    var ref = (window.GCTSE_ESTADOS || {}).ref2022;
    if (ref && ref.pct_abstencao > 0) porAno[2022] = { ano: 2022, abstencao: ref.pct_abstencao, brancos: ref.pct_brancos, nulos: ref.pct_nulos };
    // a tela e do 1o TURNO: no 2o turno, o 1o turno guardado (nao o boletim do 2o)
    var b = temTurno1() ? D().turno1.br : br(), e = b && b.eleitorado, v = b && b.votos;
    porAno[2026] = { ano: 2026, abstencao: e && e.pct_abstencao > 0 ? e.pct_abstencao : null,
      brancos: v && v.pct_brancos != null && b.secoes && b.secoes.pct > 0 ? v.pct_brancos : null,
      nulos: v && v.pct_nulos != null && b.secoes && b.secoes.pct > 0 ? v.pct_nulos : null };
    return Object.keys(porAno).map(Number).sort().slice(-3).map(function (k) { return porAno[k]; });
  }
  function escalaComp(anos) {
    var m = 0;
    anos.forEach(function (a) { ["abstencao", "brancos", "nulos"].forEach(function (q) { if (a[q] > m) m = a[q]; }); });
    return Math.max(30, Math.ceil((m + 3) / 10) * 10);
  }
  var GRUPOS_COMP = [["abstencao", "ABSTENÇÃO"], ["brancos", "BRANCOS"], ["nulos", "NULOS"]];
  G["comparativo-h"] = function () {
    var W = 1280, H = 720, anos = anosComparativo(), max = escalaComp(anos);
    var o = cabecalhoH(W, "ABSTENÇÃO, BRANCOS E NULOS", "1º turno  ·  " + anos.map(function (a) { return a.ano; }).join(", "));
    var topo = 230, base = 610, alt = base - topo;
    for (var g = 0; g < 10 && g * 10 <= max; g++) {
      var yg = base - alt * (g * 10) / max;
      o += r(73, yg, 1134, 1, C.linha) + t(68, yg + 5, (g * 10) + "%", { s: 13, c: C.apagado2, a: "end" });
    }
    GRUPOS_COMP.forEach(function (gr, gi) {
      var x0 = 95 + gi * 378, cxp = x0 + 175;
      o += t(cxp, 168, gr[1], { s: 28, b: true, a: "middle", ls: 2 });
      anos.forEach(function (a, ai) {
        var x = x0 + 30 + ai * 110, w = 70, val = a[gr[0]];
        o += r(x, topo, w, alt, "rgba(255,255,255,0.08)", 12);
        if (val > 0) { var h = Math.max(6, alt * val / max); o += r(x, base - h, w, h, CORES_ANO[ai] || C.destaque, 12); }
        o += t(x + w / 2, topo - 14, val > 0 ? pct(val) : "—", { s: 21, b: true, a: "middle", c: ai === anos.length - 1 ? C.texto : "#c9d6e6" });
        o += t(x + w / 2, base + 34, String(a.ano), { s: 22, b: true, a: "middle", c: ai === anos.length - 1 ? C.texto : C.apagado });
      });
    });
    o += t(73, 698, "Fonte: TSE  ·  abstenção sobre o eleitorado; brancos e nulos sobre os votos  ·  " +
      (anos.length ? anos[anos.length - 1].ano : "") + " " + subtitulo(), { s: 13, c: C.apagado2, max: 1134 });
    return svg(W, H, o);
  };
  G["comparativo-v"] = function () {
    var W = 540, H = 960, anos = anosComparativo(), max = escalaComp(anos);
    var o = cabecalhoV(W, "ABSTENÇÃO, BRANCOS E NULOS", "1º turno · " + anos.map(function (a) { return a.ano; }).join(", "));
    GRUPOS_COMP.forEach(function (gr, gi) {
      var y0 = 200 + gi * 235;
      o += t(35, y0, gr[1], { s: 26, b: true, ls: 2 });
      anos.forEach(function (a, ai) {
        var y = y0 + 30 + ai * 58, x = 110, w = 280, val = a[gr[0]];
        o += t(35, y + 26, String(a.ano), { s: 20, b: true, c: ai === anos.length - 1 ? C.texto : C.apagado });
        o += r(x, y, w, 36, "rgba(255,255,255,0.08)", 8);
        if (val > 0) o += r(x, y, Math.max(8, w * val / max), 36, CORES_ANO[ai] || C.destaque, 8);
        o += t(505, y + 27, val > 0 ? pct(val) : "—", { s: 24, b: true, a: "end", c: ai === anos.length - 1 ? C.texto : "#c9d6e6" });
      });
    });
    return svg(W, H, o + t(35, 945, "Fonte: TSE · abstenção sobre o eleitorado; brancos e nulos sobre os votos", { s: 11, c: C.apagado2 }));
  };

  // ---- Evolucao minuto a minuto: os 2 primeiros do Brasil -------------------
  // Cada ponto e um boletim do TSE gravado pelo GRAFICOS.bat (hora do TSE,
  // % de urnas, % dos validos). Linha reta entre boletins; nada inventado.
  function evolucao() {
    var d = D(), ev = d.evolucao || {}, pts = comoLista(ev.pontos), cs = candidatos(br()).filter(function (c) { return c.votos > 0; }).slice(0, 2);
    var nomes = ev.nomes || {};
    var lista = pts.map(function (p) {
      var m = /^(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)/.exec(p.t || "");
      return m ? { ms: new Date(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime(), u: +p.u, c: p.c || {} } : null;
    }).filter(Boolean).sort(function (a, b) { return a.ms - b.ms; });
    // 3.28.3: na tela, um ponto a cada 10 minutos (o ultimo boletim de cada
    // faixa de 10 min), mais o primeiro e o mais recente. O arquivo continua
    // guardando todos os boletins.
    var bruta = lista;
    // 3.28.4: PAUSA = trecho de 20 min ou mais em que as urnas apuradas nao
    // andaram (menos de 0,15 p.p.) - ex.: 17h06 as 19h03 de 25/10, o TSE
    // parado. Na tela ele fica estreito (faixa "PAUSA") e o resto ganha espaco.
    var pausas = [];
    for (var ip = 0; ip < bruta.length;) {
      var jp = ip;
      while (jp + 1 < bruta.length && Math.abs(bruta[jp + 1].u - bruta[ip].u) < 0.15) jp++;
      if (bruta[jp].ms - bruta[ip].ms >= 20 * 60000 && bruta[ip].u < 99) pausas.push({ a: bruta[ip].ms, b: bruta[jp].ms });   // com ~100% e o fim, nao pausa
      ip = jp > ip ? jp : ip + 1;
    }
    // VIRADAS entre o 1o e o 2o, pelo boletim exato (sem os 10 minutos)
    var viradas = [];
    if (cs.length === 2) {
      var na = String(cs[0].numero), nb = String(cs[1].numero), sAnt = 0;
      bruta.forEach(function (p) {
        var va = p.c[na], vb = p.c[nb]; if (va == null || vb == null) return;
        var sn = +va > +vb ? 1 : (+va < +vb ? -1 : 0); if (!sn) return;
        if (sAnt && sn !== sAnt) { var lid = sn > 0 ? cs[0] : cs[1]; viradas.push({ ms: p.ms, u: p.u, va: +va, vb: +vb, lider: lid.nome || (nomes[lid.numero] || {}).nome || lid.numero, cor: cor(lid) }); }
        sAnt = sn;
      });
    }
    var DEZ = 600000, faixas = [], fxAnt = null;
    lista.forEach(function (p) { var fx = Math.floor(p.ms / DEZ); if (fx === fxAnt) faixas[faixas.length - 1] = p; else { faixas.push(p); fxAnt = fx; } });
    if (lista.length && faixas[0] !== lista[0]) faixas.unshift(lista[0]);
    lista = faixas;
    var series = cs.map(function (c) {
      return { c: c, cor: cor(c), nome: c.nome || (nomes[c.numero] || {}).nome || c.numero,
        pts: lista.filter(function (p) { return p.c[c.numero] != null; }).map(function (p) { return { ms: p.ms, v: +p.c[c.numero], u: p.u }; }) };
    });
    // Serie com 1 ponto so (log do exibidor guardou so o 1o colocado): avisa na legenda.
    var maxPts = Math.max.apply(null, series.map(function (s) { return s.pts.length; }).concat([0]));
    series.forEach(function (s) { s.soFinal = maxPts >= 2 && s.pts.length === 1; });
    var cem = bruta.filter(function (p) { return p.u >= 99.995; })[0] || null;
    return { series: series, pontos: lista, origem: ev.origem || "", pausas: pausas, viradas: viradas, primeiro: bruta[0] || null, cem: cem, ultimo: bruta[bruta.length - 1] || null, cs: cs };
  }
  function hhmm(ms) { var x = new Date(ms); return ("0" + x.getHours()).slice(-2) + ":" + ("0" + x.getMinutes()).slice(-2); }
  function pctCurto(v, casas) { return Number(v).toFixed(casas).replace(".", ",") + "%"; }
  var HALO = ' stroke="#0b1220" stroke-width="6" stroke-linejoin="round" paint-order="stroke"';
  // Area do grafico: x0..x1, y0..y1. k = escala das letras.
  function plotEvolucao(ev, x0, x1, y0, y1, k, maxTicks) {
    // 3.28.7: horas como na TV ("20h54")
    var hhmm = function (ms) { var x = new Date(ms); return x.getHours() + "h" + ("0" + x.getMinutes()).slice(-2); };
    var ss = ev.series.filter(function (s) { return s.pts.length; }), o = "";
    if (!ss.length) return marcaVazio() + t((x0 + x1) / 2, (y0 + y1) / 2, br() ? "nenhum boletim gravado ainda" : "aguardando o primeiro boletim do TSE", { s: Math.round(22 * k), c: C.apagado, a: "middle" }) +
      t((x0 + x1) / 2, (y0 + y1) / 2 + 30 * k, "o GRAFICOS.bat grava cada boletim novo do TSE", { s: Math.round(16 * k), c: C.apagado2, a: "middle" });
    var tA = Infinity, tB = -Infinity, vA = Infinity, vB = -Infinity;
    ss.forEach(function (s) { s.pts.forEach(function (p) { tA = Math.min(tA, p.ms); tB = Math.max(tB, p.ms); vA = Math.min(vA, p.v); vB = Math.max(vB, p.v); }); });
    var unico = tB - tA < 1000;
    if (unico) { tA -= 30000; tB += 30000; }
    var span = Math.max(4, vB - vA + 2), passo = span <= 6 ? 1 : span <= 14 ? 2 : span <= 30 ? 5 : 10;
    var lo = Math.floor((vA - 1) / passo) * passo, hi = Math.ceil((vB + 1) / passo) * passo;
    lo = Math.max(0, lo); hi = Math.min(100, hi); if (hi - lo < passo * 2) hi = lo + passo * 2;
    // pausas encolhidas: cada uma ocupa ~7% da largura (eixo do tempo
    // continua na ordem certa; so o trecho parado fica estreito)
    var pz = (ev.pausas || []).map(function (q) { return { a: Math.max(q.a, tA), b: Math.min(q.b, tB) }; }).filter(function (q) { return q.b - q.a > 0; });
    var durP = pz.reduce(function (s0, q) { return s0 + (q.b - q.a); }, 0), normal = Math.max(1, (tB - tA) - durP);
    var larP = pz.length ? Math.min(0.07 * normal / Math.max(0.3, 1 - 0.07 * pz.length), 1e15) : 0;
    function virt(ms) { var v0 = ms - tA; pz.forEach(function (q) { if (ms > q.a) { var dent = Math.min(ms, q.b) - q.a; v0 += -dent + larP * dent / (q.b - q.a); } }); return v0; }
    var vTot = Math.max(1, virt(tB));
    var X = function (ms) { return x0 + (x1 - x0) * virt(ms) / vTot; };
    var naPausa = function (ms) { return pz.some(function (q) { return ms > q.a && ms < q.b; }); };
    var Y = function (v) { return y1 - (y1 - y0) * (v - lo) / (hi - lo); };
    // grade horizontal + 50% em destaque (maioria no 2o turno)
    for (var g = lo; g <= hi + 1e-9; g += passo) {
      var gy = Y(g).toFixed(1), meio = Math.abs(g - 50) < 1e-9;
      o += '<line x1="' + x0 + '" x2="' + x1 + '" y1="' + gy + '" y2="' + gy + '" stroke="' + (meio ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.10)") +
        '" stroke-width="' + (meio ? 2 : 1) + '"' + (meio ? ' stroke-dasharray="8 6"' : "") + "/>";
      o += t(x0 - 12 * k, +gy + 6 * k, g + "%", { s: Math.round(16 * k), c: meio ? C.texto : C.apagado, a: "end", b: meio });
    }
    // eixo de horas: intervalo "redondo" que de ate maxTicks marcas
    var min = (pz.length ? normal : (tB - tA)) / 60000, opc = [1, 2, 5, 10, 15, 20, 30, 60, 120, 180, 240], iv = opc[opc.length - 1];
    for (var i = 0; i < opc.length; i++) if (min / opc[i] <= maxTicks - 1) { iv = opc[i]; break; }
    var ivMs = iv * 60000, primeiro = Math.ceil(tA / ivMs) * ivMs, ultimoX = -1e9;
    var tz = new Date(tA).getTimezoneOffset() * 60000;   // marcas na hora cheia LOCAL
    primeiro = Math.ceil((tA - tz) / ivMs) * ivMs + tz;
    var todos = ev.pontos, marcas = [tA];
    for (var mm = primeiro; mm <= tB; mm += ivMs) if (X(mm) - X(tA) >= 70 * k && !naPausa(mm)) marcas.push(mm);
    marcas.sort(function (p, q) { return p - q; });
    if (unico) { marcas = [(tA + tB) / 2]; o += t((x0 + x1) / 2, y1 - 24 * k, "1 boletim gravado: a linha começa no próximo boletim do TSE", { s: Math.round(16 * k), c: C.apagado, a: "middle" }); }
    // faixa da pausa
    pz.forEach(function (q) {
      var pa = X(q.a), pb = X(q.b), pm = (pa + pb) / 2;
      o += r(pa, y0, Math.max(2, pb - pa), y1 - y0, "rgba(255,255,255,0.06)", 0);
      o += '<line x1="' + pa.toFixed(1) + '" x2="' + pa.toFixed(1) + '" y1="' + y0 + '" y2="' + y1 + '" stroke="rgba(255,255,255,0.22)" stroke-dasharray="3 5"/>';
      o += '<line x1="' + pb.toFixed(1) + '" x2="' + pb.toFixed(1) + '" y1="' + y0 + '" y2="' + y1 + '" stroke="rgba(255,255,255,0.22)" stroke-dasharray="3 5"/>';
      o += t(pm, y1 + 10 * k, "//", { s: Math.round(16 * k), b: true, c: C.apagado, a: "middle" });
    });
    // explicacao da faixa embaixo do eixo (em cima ficam os % da 1a divulgacao)
    if (pz.length) o += r(x0, y1 + 58 * k, 14 * k, 12 * k, "rgba(255,255,255,0.18)", 2) +
      t(x0 + 22 * k, y1 + 69 * k, "PAUSA " + pz.map(function (q) { return hhmm(q.a) + " às " + hhmm(q.b) + " (" + Math.round((q.b - q.a) / 60000) + " min)"; }).join(", ") + ": urnas sem avanço, trecho encolhido no gráfico", { s: Math.round(13 * k), b: true, c: C.apagado, max: (x1 - x0) });
    // horario em que PAROU (a esquerda da faixa) e em que VOLTOU (a direita),
    // com as urnas de cada momento; as marcas comuns encostadas saem
    var livres = [];
    pz.forEach(function (q) {
      var pa = X(q.a), pb = X(q.b), ua = null, ub = null;
      todos.forEach(function (p) { if (p.ms <= q.a) ua = p; if (p.ms <= q.b) ub = p; });
      o += t(pa + 4 * k, y1 + 26 * k, hhmm(q.a), { s: Math.round(16 * k), b: true, c: C.texto, a: "end" }) +
        t(pa + 4 * k, y1 + 46 * k, "parou" + (ua ? " · " + pctCurto(ua.u, ua.u < 10 ? 1 : 0) : ""), { s: Math.round(13 * k), b: true, c: "#a5d8ff", a: "end" });
      o += t(pb + 2 * k, y1 + 26 * k, hhmm(q.b), { s: Math.round(16 * k), b: true, c: C.texto }) +
        t(pb + 2 * k, y1 + 46 * k, "voltou" + (ub ? " · " + pctCurto(ub.u, ub.u < 10 ? 1 : 0) : ""), { s: Math.round(13 * k), b: true, c: "#a5d8ff" });
      livres.push([pa - 110 * k, pb + 155 * k]);
    });
    marcas.forEach(function (m) {
      var mx = X(m); if (mx - ultimoX < 70 * k) return;
      if (livres.some(function (L) { return mx >= L[0] && mx <= L[1]; })) return;
      ultimoX = mx;
      o += '<line x1="' + mx.toFixed(1) + '" x2="' + mx.toFixed(1) + '" y1="' + y0 + '" y2="' + y1 + '" stroke="rgba(255,255,255,0.06)"/>';
      o += t(mx, y1 + 26 * k, hhmm(m), { s: Math.round(16 * k), b: true, c: C.apagado, a: "middle" });
      var ant = null; todos.forEach(function (p) { if (p.ms <= m) ant = p; });
      if (ant && ant.u >= 0) o += t(mx, y1 + 46 * k, "urnas " + pctCurto(ant.u, ant.u < 10 ? 1 : 0), { s: Math.round(13 * k), c: C.apagado2, a: "middle" });
    });
    o += '<line x1="' + x0 + '" x2="' + x1 + '" y1="' + y1 + '" y2="' + y1 + '" stroke="rgba(255,255,255,0.25)"/>';
    // 3.28.4: VIRADA entre o 1o e o 2o, pelo boletim exato do TSE. Cada
    // virada: linha amarela e o horario; a ultima ganha o selo grande com
    // quem passou a liderar.
    var vs = (ev.viradas || []).filter(function (q) { return q.ms >= tA && q.ms <= tB; }), caixaV = null;
    if (ss.length === 2 && vs.length) {
      vs.forEach(function (q, iq) {
        var vx = X(q.ms), vy = Y((q.va + q.vb) / 2), ult = iq === vs.length - 1;
        o += '<line x1="' + vx.toFixed(1) + '" x2="' + vx.toFixed(1) + '" y1="' + y0 + '" y2="' + y1 + '" stroke="#ffffff" stroke-width="1.5" stroke-dasharray="5 6" opacity="' + (ult ? 0.5 : 0.35) + '"/>';
        o += '<circle cx="' + vx.toFixed(1) + '" cy="' + vy.toFixed(1) + '" r="' + (ult ? 6 : 4.5) * k + '" fill="none" stroke="#ffffff" stroke-width="2" opacity="0.8"/>';
        // horario das viradas anteriores (longe do rotulo da 1a divulgacao)
        if (!ult && vx - x0 > 150 * k) o += t(vx, y0 + 16 * k, hhmm(q.ms), { s: Math.round(12 * k), b: true, c: "#a5d8ff", a: "middle", extra: HALO });
      });
      var qv = vs[vs.length - 1], bx = X(qv.ms), txt1 = "VIRADA ÀS " + hhmm(qv.ms), txt2 = qv.lider + " assume a liderança" + (vs.length > 1 ? " · " + vs.length + " viradas na noite" : "");
      // discreto: caixa azul-clara, letras escuras e pequenas
      var bw = Math.max(txt1.length * 8.6, txt2.length * 6.2) * k + 26 * k, bh = 40 * k, bxx = Math.min(Math.max(bx + 10 * k, x0), x1 - bw), byy = y0 + 8 * k;
      if (bxx < x0 + 150 * k) byy = y1 - bh - 10 * k;      // perto do inicio: embaixo, longe da 1a divulgacao
      caixaV = { x: bxx, y: byy, w: bw, h: bh };
      o += r(bxx, byy, bw, bh, "#a5d8ff", 5) +
        t(bxx + 10 * k, byy + 17 * k, txt1, { s: Math.round(13 * k), b: true, c: "#0b1220", ls: 1 }) +
        t(bxx + 10 * k, byy + 32 * k, txt2, { s: Math.round(10 * k), b: true, c: "#1b2a44", max: bw - 18 * k });
    }
    // 3.28.6: hora em que o presidente ficou ELEITO (TSE ou conta: o 1o com
    // mais votos que o 2o + todos os eleitores que faltam) - definicao-*.json,
    // da coleta ou do historico de totalizacao do TSE (IMPORTAR-EVOLUCAO)
    var df = D().definicao, mD = df && /^(\d\d)\/(\d\d)\/(\d{4})\s+(\d\d):(\d\d):?(\d\d)?/.exec(String(df.geracao || ""));
    if (mD) {
      var msD = new Date(+mD[3], mD[2] - 1, +mD[1], +mD[4], +mD[5], +(mD[6] || 0)).getTime();
      if (msD >= tA - 60000 && msD <= tB + 60000) {
        var ex = X(Math.min(Math.max(msD, tA), tB)), l1 = (df.tipo === "matematica" ? "MATEMATICAMENTE ELEITO ÀS " : "ELEITO (TSE) ÀS ") + String(df.hora || "").slice(0, 5).replace(":", "h"), l2 = (df.nome || "") + (df.urnas != null ? " · urnas " + pctCurto(+df.urnas, 2) : "") + (df.tipo === "matematica" ? " · não podia mais ser alcançado" : " · declarado pelo TSE");
        o += '<line x1="' + ex.toFixed(1) + '" x2="' + ex.toFixed(1) + '" y1="' + y0 + '" y2="' + y1 + '" stroke="#8ce99a" stroke-width="2" opacity="0.8"/>';
        var ew = Math.max(l1.length * 8.6, l2.length * 6.2) * k + 22 * k, eh = 40 * k, exx = ex + 10 * k + ew > x1 ? ex - 10 * k - ew : ex + 10 * k, ey = y1 - eh - 12 * k;
        // nao em cima do selo da virada: tenta embaixo, em cima, e logo abaixo dele
        // obstaculos: o selo da virada e o rotulo da 1a divulgacao (canto de cima, a esquerda)
        var obst = [{ x: x0, y: y0 - 30 * k, w: 170 * k, h: 80 * k }]; if (caixaV) obst.push(caixaV);
        var bate = function (yy) { return obst.some(function (b0) { return exx < b0.x + b0.w && exx + ew > b0.x && yy < b0.y + b0.h && yy + eh > b0.y; }); };
        var achou = [y1 - eh - 12 * k, y0 + 8 * k, caixaV ? caixaV.y - eh - 8 * k : 0, caixaV ? caixaV.y + caixaV.h + 8 * k : 0].some(function (yy) { if (yy >= y0 && yy + eh <= y1 && !bate(yy)) { ey = yy; return true; } return false; });
        // tela estreita (vertical) ou sem lugar livre: embaixo do eixo das horas
        if (!achou || k < 1) { exx = x0; ey = y1 + (pz.length ? 84 : 58) * k; }
        // selo "ELEITO" em cima da linha do vencedor, no ponto da hora
        var sV = ss.filter(function (s0) { return String(s0.c.numero) === String(df.numero); })[0];
        if (sV) {
          var pv = null; sV.pts.forEach(function (p0) { if (p0.ms <= msD || !pv) pv = p0; });
          var nxt = sV.pts.filter(function (p0) { return p0.ms > msD; })[0], vV = pv.v;
          if (nxt && nxt.ms > pv.ms && msD > pv.ms) vV = pv.v + (nxt.v - pv.v) * (msD - pv.ms) / (nxt.ms - pv.ms);   // so para posicionar o selo na linha
          var py = Y(vV), pw = 66 * k, ph = 22 * k;
          o += '<circle cx="' + ex.toFixed(1) + '" cy="' + py.toFixed(1) + '" r="' + (6 * k).toFixed(1) + '" fill="#2fb344" stroke="#ffffff" stroke-width="2"/>';
          o += r(ex - pw / 2, py - ph - 12 * k, pw, ph, "#2fb344", 11 * k) + t(ex, py - 12 * k - 6 * k, "ELEITO", { s: Math.round(12 * k), b: true, c: "#ffffff", a: "middle", ls: 1 });
        }
        o += r(exx, ey, ew, eh, "#b2f2bb", 5) + t(exx + 10 * k, ey + 17 * k, l1, { s: Math.round(13 * k), b: true, c: "#0b1220", ls: 1 }) +
          t(exx + 10 * k, ey + 32 * k, l2, { s: Math.round(10 * k), b: true, c: "#1b2a44", max: ew - 16 * k });
      }
    }
    // linhas, pontos inicial/final e rotulos
    var fins = [];
    ss.forEach(function (s) {
      var d = s.pts.map(function (p, j) { return (j ? "L" : "M") + X(p.ms).toFixed(1) + " " + Y(p.v).toFixed(1); }).join(" ");
      o += '<path d="' + d + '" fill="none" stroke="' + s.cor + '" stroke-width="' + (4 * k).toFixed(1) + '" stroke-linejoin="round" stroke-linecap="round"/>';
      var p0 = s.pts[0], pf = s.pts[s.pts.length - 1];
      o += '<circle cx="' + X(p0.ms).toFixed(1) + '" cy="' + Y(p0.v).toFixed(1) + '" r="' + (5 * k).toFixed(1) + '" fill="' + s.cor + '" stroke="#0b1220" stroke-width="2"/>';
      o += '<circle cx="' + X(pf.ms).toFixed(1) + '" cy="' + Y(pf.v).toFixed(1) + '" r="' + (8 * k).toFixed(1) + '" fill="' + s.cor + '" stroke="#ffffff" stroke-width="' + (2.5 * k).toFixed(1) + '"/>';
      fins.push({ s: s, y: Y(pf.v), y0: Y(p0.v), p0: p0, pf: pf });
    });
    // inicio: acima de quem comeca na frente, abaixo de quem comeca atras
    if (fins.length === 2 && fins[0].p0.ms === fins[1].p0.ms && (fins[0].p0.ms !== fins[0].pf.ms)) {
      var cima = fins[0].y0 <= fins[1].y0 ? fins[0] : fins[1], baixo = cima === fins[0] ? fins[1] : fins[0];
      o += t(x0 + 4 * k, cima.y0 - 38 * k, "1ª DIVULGAÇÃO · " + hhmm(cima.p0.ms), { s: Math.round(12 * k), b: true, c: C.apagado, ls: 1, extra: HALO });
      o += t(x0 + 4 * k, cima.y0 - 14 * k, pctCurto(cima.p0.v, 2), { s: Math.round(20 * k), b: true, c: cima.s.cor, extra: HALO });
      o += t(x0 + 4 * k, baixo.y0 + 30 * k, pctCurto(baixo.p0.v, 2), { s: Math.round(20 * k), b: true, c: baixo.s.cor, extra: HALO });
    } else {
      // so uma serie tem linha (a outra so o final): rotulo no inicio dela
      fins.forEach(function (f) {
        // linha que sobe: rotulo embaixo do inicio; que desce: em cima
        if (f.s.pts.length > 1) o += t(X(f.p0.ms) + 4 * k, f.pf.v > f.p0.v ? f.y0 + 30 * k : f.y0 - 14 * k, pctCurto(f.p0.v, 2), { s: Math.round(20 * k), b: true, c: f.s.cor, extra: HALO });
      });
    }
    // fim: valores a direita, afastados se ficarem colados
    fins.sort(function (p, q) { return p.y - q.y; });
    var dist = 40 * k;
    if (fins.length === 2 && fins[1].y - fins[0].y < dist) { var meioY = (fins[0].y + fins[1].y) / 2; fins[0].y = meioY - dist / 2; fins[1].y = meioY + dist / 2; }
    fins.forEach(function (f) { o += t(x1 + 16 * k, f.y + 10 * k, pctCurto(f.pf.v, 2), { s: Math.round(30 * k), b: true, c: C.texto }); });
    // 3.28.4: a ultima divulgacao (hora do TSE) em cima dos valores finais
    if (fins.length) o += t(x1 + 16 * k, fins[0].y - 26 * k, "ÚLTIMA · " + hhmm(fins[0].pf.ms), { s: Math.round(12 * k), b: true, c: C.apagado, ls: 1 });
    return o;
  }
  function legendaEvolucao(ev, x, y, k, maxW) {
    var o = "";
    ev.series.forEach(function (s, i) {
      var xx = x + i * maxW / 2, txt = s.nome + (s.c.partido ? " (" + s.c.partido + ")" : "") + (s.soFinal ? " · só o resultado final" : "");
      o += r(xx, y - 11 * k, 30 * k, 6 * k, s.cor, 3) + t(xx + 40 * k, y, txt, { s: Math.round(19 * k), b: true, max: maxW / 2 - 60 * k });
    });
    return o;
  }
  function rodapeEvolucao(ev) {
    var b = br(), n = ev.pontos.length, exib = ev.origem === "log do exibidor", log = !!ev.origem;
    return "Fonte: TSE · % dos votos válidos de 10 em 10 minutos (" + n + (n === 1 ? " ponto" : " pontos") +
      (ev.origem === "historico do TSE" ? ", histórico de totalização do TSE" : ev.origem === "log do exibidor 2t" ? ", refeitos do log do exibidor" : exib ? ", gravados pelo exibidor: só o 1º colocado a cada ciclo" : (log ? ", gravados pelo sistema de tarjas no ar" : ", horário do TSE")) + ")" +
      (b && b.secoes && b.secoes.pct != null ? " · urnas apuradas " + pct(b.secoes.pct) : "");
  }
  G["evolucao-h"] = function () {
    var W = 1280, H = 720, ev = evolucao();
    var nomes = ev.series.map(function (s) { return s.nome; }).join(" × ");
    var o = cabecalhoH(W, "EVOLUÇÃO DA APURAÇÃO", (nomes ? nomes + "  ·  " : "") + "presidente  ·  " + subtitulo());
    o += legendaEvolucao(ev, 73, 135, 1, 900);
    o += plotEvolucao(ev, 125, 1085, 175, 600, 1, 9);
    o += t(73, 700, rodapeEvolucao(ev), { s: 13, c: C.apagado2, max: 1134 });
    return svg(W, H, o);
  };
  G["evolucao-v"] = function () {
    var W = 540, H = 960, ev = evolucao();
    var o = cabecalhoV(W, "EVOLUÇÃO DA APURAÇÃO", "presidente · " + subtitulo());
    var yy = 200;
    ev.series.forEach(function (s, i) {
      o += r(35, yy + i * 34 - 11, 30, 6, s.cor, 3) + t(75, yy + i * 34, s.nome + (s.c.partido ? " (" + s.c.partido + ")" : "") + (s.soFinal ? " · só o final" : ""), { s: 19, b: true, max: 430 });
    });
    o += plotEvolucao(ev, 85, 410, 290, 820, 0.85, 5);
    return svg(W, H, o + t(35, 945, rodapeEvolucao(ev), { s: 11, c: C.apagado2, max: 470 }));
  };

  // ---- 3.28.8: A NOITE DA APURACAO - os marcos, em ordem, com a hora ------
  // Tudo do historico do minuto a minuto (boletins do TSE) e da hora do
  // eleito (definicao-*.json). Bom para o jornal do dia seguinte.
  function marcosNoite() {
    var ev = evolucao(), cs = ev.cs || [], df = D().definicao, L = [];
    if (cs.length < 2 || !ev.primeiro) return null;
    var A = cs[0], B = cs[1];
    function hm(ms) { var x = new Date(ms); return x.getHours() + "h" + ("0" + x.getMinutes()).slice(-2); }
    function par(p) { var a = p.c[String(A.numero)], b = p.c[String(B.numero)]; return (a != null ? nomeCurto(A) + " " + pctCurto(+a, 2) : "") + (b != null ? "  ×  " + nomeCurto(B) + " " + pctCurto(+b, 2) : ""); }
    function urn(u) { return "urnas " + pctCurto(+u, +u < 10 ? 2 : 1); }
    L.push({ ms: ev.primeiro.ms, tit: "1ª DIVULGAÇÃO", txt: par(ev.primeiro), u: urn(ev.primeiro.u), cor: "#c9d6e6" });
    (ev.pausas || []).forEach(function (q) { L.push({ ms: q.a, tit: "PAUSA DE " + Math.round((q.b - q.a) / 60000) + " MIN", txt: "urnas sem avanço até as " + hm(q.b), u: "", cor: "#8b9bb4" }); });
    (ev.viradas || []).forEach(function (q) { L.push({ ms: q.ms, tit: "VIRADA", txt: q.lider + " assume a liderança", u: q.u != null ? urn(q.u) : "", cor: "#a5d8ff" }); });
    var mD = df && /^(\d\d)\/(\d\d)\/(\d{4})\s+(\d\d):(\d\d):?(\d\d)?/.exec(String(df.geracao || ""));
    if (mD) L.push({ ms: new Date(+mD[3], mD[2] - 1, +mD[1], +mD[4], +mD[5], +(mD[6] || 0)).getTime(), tit: df.tipo === "matematica" ? "MATEMATICAMENTE ELEITO" : "ELEITO (DECLARADO PELO TSE)",
      txt: (df.nome || "") + " · às " + (+mD[4]) + "h" + mD[5] + (mD[6] ? "min" + mD[6] + "s" : ""), u: df.urnas != null ? urn(df.urnas) : "", cor: "#8ce99a" });
    if (ev.cem) L.push({ ms: ev.cem.ms, tit: "100% DAS URNAS", txt: par(ev.cem), u: "", cor: "#ffffff" });
    L.sort(function (p, q) { return p.ms - q.ms; });
    L.forEach(function (x) { x.h = hm(x.ms); });
    return { L: L, A: A, B: B };
  }
  function telaMarcos(v) {
    var W = v ? 540 : 1280, H = v ? 960 : 720, mk = marcosNoite(), tit = "A NOITE DA APURAÇÃO", sub = "Presidente · 2º turno · os momentos da apuração, no horário do TSE";
    var o = v ? cabecalhoV(W, tit, "Presidente · os momentos da noite") : cabecalhoH(W, tit, sub);
    if (!mk || !mk.L.length) return svg(W, H, marcaVazio() + o + t(W / 2, H / 2, "aguardando o minuto a minuto (GRAFICOS.bat ou IMPORTAR-EVOLUCAO)", { s: v ? 16 : 22, c: C.apagado, a: "middle", max: W - 60 }));
    var L = mk.L.slice(0, v ? 9 : 8), x0 = v ? 35 : 73, y0 = v ? 200 : 130, yF = v ? 900 : 670, passo = Math.min(v ? 140 : 112, (yF - y0 - 30) / Math.max(1, L.length - 1)), xl = x0 + (v ? 92 : 130);
    o += r(xl - 2, y0 + 10, 4, passo * (L.length - 1), "rgba(255,255,255,0.18)", 2);
    L.forEach(function (x, i) {
      var y = y0 + 10 + i * passo;
      o += t(xl - 22, y + 9, x.h, { s: v ? 22 : 28, b: true, a: "end" });
      o += '<circle cx="' + xl + '" cy="' + y + '" r="' + (v ? 9 : 11) + '" fill="' + x.cor + '" stroke="#0b1220" stroke-width="3"/>';
      o += t(xl + 26, y - 6, x.tit, { s: v ? 17 : 19, b: true, c: x.cor, ls: 1 });
      if (v) o += t(xl + 26, y + 18, x.txt, { s: 15, b: true, max: W - xl - 26 - 20 }) + (x.u ? t(xl + 26, y + 38, x.u, { s: 13, c: "#c9d6e6" }) : "");
      else o += t(xl + 26, y + 24, x.txt + (x.u ? "  ·  " + x.u : ""), { s: 23, b: true, max: W - xl - 26 - x0 });
    });
    return svg(W, H, o + (v ? t(35, 945, "Fonte: TSE — boletins da noite (minuto a minuto) e hora do eleito", { s: 10, c: C.apagado2, max: 470 }) : t(73, 708, "Fonte: TSE — boletins da noite gravados pelo sistema (ou histórico de totalização do TSE) · hora do eleito: marca do TSE ou conta com os eleitores que faltavam", { s: 12, c: C.apagado2, max: 1134 })));
  }
  G["marcos-h"] = function () { return telaMarcos(false); };
  G["marcos-v"] = function () { return telaMarcos(true); };

  // ---- 3.29: AS DUAS NOITES - 1o x 2o turno pelo % de urnas apuradas -------
  // % de cada finalista na SOMA dos votos dos dois (assim o 1o e o 2o turno
  // ficam na mesma base), em cada boletim, conforme as urnas eram apuradas.
  // 2o turno: evolucao; 1o turno: evolucao_1t (historico do 1o turno do TSE
  // ou o arquivo gravado na noite do 1o turno).
  function duasNoites() {
    var d = D(), cs = candidatos(br()).filter(function (c) { return c.votos > 0; }).slice(0, 2);
    if (cs.length < 2) return null;
    var A = String(cs[0].numero), B = String(cs[1].numero);
    function serie(ev) {
      var out = []; comoLista(ev && ev.pontos).forEach(function (p) {
        var c = p.c || {}, a = c[A], b = c[B]; if (a == null || b == null || !(+a + +b > 0)) return;
        out.push({ u: +p.u, a: 100 * a / (+a + +b), ra: +a, rb: +b, t: p.t });
      });
      out.sort(function (x, y) { return x.u - y.u || String(x.t).localeCompare(String(y.t)); });
      // um ponto por 0,5% de urnas (o ultimo de cada faixa) - linha limpa
      var f = [], fx = null; out.forEach(function (p) { var k = Math.floor(p.u * 2); if (k === fx) f[f.length - 1] = p; else { f.push(p); fx = k; } });
      return f;
    }
    var s2 = serie(d.evolucao), s1 = serie(d.evolucao_1t);
    if (s2.length < 2 && s1.length < 2) return null;
    return { A: cs[0], B: cs[1], s1: s1, s2: s2 };
  }
  function telaDuasNoites(v) {
    var W = v ? 540 : 1280, H = v ? 960 : 720, dn = duasNoites(), tit = "AS DUAS NOITES";
    var o = v ? cabecalhoV(W, tit, "Presidente · 1º × 2º turno") : cabecalhoH(W, tit, "Presidente · 1º × 2º turno · a disputa entre os dois finalistas conforme as urnas eram apuradas");
    if (!dn) return svg(W, H, marcaVazio() + o + t(W / 2, H / 2, "aguardando o minuto a minuto (2º turno e/ou 1º turno: IMPORTAR-EVOLUCAO)", { s: v ? 15 : 22, c: C.apagado, a: "middle", max: W - 60 }));
    var k = v ? 0.85 : 1, x0 = v ? 85 : 125, x1 = v ? 400 : 1015, y0 = v ? 300 : 190, y1 = v ? 760 : 590;
    var cA = cor(dn.A), cB = cor(dn.B), vals = [];
    [dn.s1, dn.s2].forEach(function (s0) { s0.forEach(function (p) { vals.push(p.a, 100 - p.a); }); });
    var lo = Math.max(0, Math.floor((Math.min.apply(null, vals) - 2) / 5) * 5), hi = Math.min(100, Math.ceil((Math.max.apply(null, vals) + 2) / 5) * 5);
    if (hi - lo < 10) { lo = Math.max(0, lo - 5); hi = Math.min(100, hi + 5); }
    var X = function (u) { return x0 + (x1 - x0) * Math.max(0, Math.min(100, u)) / 100; }, Y = function (v0) { return y1 - (y1 - y0) * (v0 - lo) / (hi - lo); };
    var passoY = hi - lo > 30 ? 10 : 5;
    for (var g = lo; g <= hi + 1e-9; g += passoY) {
      var gy = Y(g).toFixed(1), meio = Math.abs(g - 50) < 1e-9;
      o += '<line x1="' + x0 + '" x2="' + x1 + '" y1="' + gy + '" y2="' + gy + '" stroke="' + (meio ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.10)") + '" stroke-width="' + (meio ? 2 : 1) + '"' + (meio ? ' stroke-dasharray="8 6"' : "") + "/>";
      o += t(x0 - 12 * k, +gy + 6 * k, g + "%", { s: Math.round(16 * k), c: meio ? C.texto : C.apagado, a: "end", b: meio });
    }
    [0, 20, 40, 60, 80, 100].forEach(function (u) { o += t(X(u), y1 + 26 * k, u + "%", { s: Math.round(16 * k), b: true, c: C.apagado, a: "middle" }); });
    o += t((x0 + x1) / 2, y1 + 50 * k, "urnas apuradas", { s: Math.round(13 * k), c: C.apagado2, a: "middle" });
    function linha(s0, fA, corL, larg, tracejado, opac) {
      if (s0.length < 2) return "";
      var dd = s0.map(function (p, j) { return (j ? "L" : "M") + X(p.u).toFixed(1) + " " + Y(fA(p)).toFixed(1); }).join(" ");
      return '<path d="' + dd + '" fill="none" stroke="' + corL + '" stroke-width="' + (larg * k).toFixed(1) + '" stroke-linejoin="round" stroke-linecap="round"' + (tracejado ? ' stroke-dasharray="' + (7 * k) + ' ' + (6 * k) + '"' : "") + ' opacity="' + opac + '"/>';
    }
    var fa = function (p) { return p.a; }, fb = function (p) { return 100 - p.a; };
    o += linha(dn.s1, fa, cA, 3, true, 0.75) + linha(dn.s1, fb, cB, 3, true, 0.75) + linha(dn.s2, fa, cA, 4.5, false, 1) + linha(dn.s2, fb, cB, 4.5, false, 1);
    // finais: 2o turno grande a direita; 1o turno pequeno
    var f2 = dn.s2[dn.s2.length - 1], f1 = dn.s1[dn.s1.length - 1];
    function fim(p, fn, c0, big) { var y = Y(fn(p)); return '<circle cx="' + X(p.u).toFixed(1) + '" cy="' + y.toFixed(1) + '" r="' + ((big ? 7 : 5) * k).toFixed(1) + '" fill="' + c0 + '" stroke="#fff" stroke-width="2"/>'; }
    if (f1) o += fim(f1, fa, cA, false) + fim(f1, fb, cB, false);
    if (f2) {
      o += fim(f2, fa, cA, true) + fim(f2, fb, cB, true);
      var ya = Y(fa(f2)), yb = Y(fb(f2)); if (Math.abs(ya - yb) < 34 * k) { var mm = (ya + yb) / 2; ya = mm - (ya < yb ? 17 : -17) * k; yb = mm + (ya < mm ? 17 : -17) * k; }
      o += t(x1 + 14 * k, ya + 9 * k, pctCurto(fa(f2), 1), { s: Math.round(26 * k), b: true }) + t(x1 + 14 * k, yb + 9 * k, pctCurto(fb(f2), 1), { s: Math.round(26 * k), b: true });
    }
    // final do 1o turno (pequeno), se nao encostar nos do 2o
    if (f1) [[fa, cA], [fb, cB]].forEach(function (z) {
      var y = Y(z[0](f1)); if (f2 && (Math.abs(y - Y(fa(f2))) < 26 * k || Math.abs(y - Y(fb(f2))) < 26 * k)) return;
      o += t(x1 + 14 * k, y + 5 * k, "1º t. " + pctCurto(z[0](f1), 1), { s: Math.round(14 * k), b: true, c: "#c9d6e6" });
    });
    // legenda e resumo
    var ly = v ? 196 : 136;
    function leg(x, y, c0, nome, tr) { return '<line x1="' + x + '" x2="' + (x + 34 * k) + '" y1="' + (y - 6 * k) + '" y2="' + (y - 6 * k) + '" stroke="' + c0 + '" stroke-width="' + (tr ? 3 : 5) * k + '"' + (tr ? ' stroke-dasharray="' + 6 * k + ' ' + 4 * k + '" opacity="0.8"' : "") + '/>' + t(x + 44 * k, y, nome, { s: Math.round((v ? 15 : 17) * k / (v ? 0.85 : 1)), b: true, max: v ? 200 : 260 }); }
    if (!v) {
      o += leg(73, ly, cA, nomeCurto(dn.A) + " · 2º turno", false) + leg(380, ly, cA, "1º turno", true) + leg(600, ly, cB, nomeCurto(dn.B) + " · 2º turno", false) + leg(907, ly, cB, "1º turno", true);
      var res = [];
      if (f1) res.push("1º turno (final): " + nomeCurto(dn.A) + " " + pctCurto(f1.ra, 2) + " × " + nomeCurto(dn.B) + " " + pctCurto(f1.rb, 2) + " dos válidos");
      if (f2) res.push("2º turno" + (f2.u >= 99.995 ? " (final)" : " (urnas " + pctCurto(f2.u, 1) + ")") + ": " + pctCurto(f2.ra, 2) + " × " + pctCurto(f2.rb, 2));
      o += t(73, 680, res.join("   ·   "), { s: 15, b: true, c: "#c9d6e6", max: 1134 });
      if (!dn.s1.length) o += t(73, 166, "1º turno: importe o histórico do 1º turno do TSE (IMPORTAR-EVOLUCAO) para a linha tracejada", { s: 13, c: "#ffd8a8" });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — % de cada finalista na soma dos votos dos dois, a cada boletim · linha cheia = 2º turno, tracejada = 1º turno", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o += leg(35, ly, cA, nomeCurto(dn.A) + " 2º t.", false) + leg(280, ly, cA, "1º t.", true) + leg(35, ly + 30, cB, nomeCurto(dn.B) + " 2º t.", false) + leg(280, ly + 30, cB, "1º t.", true);
    if (f1) o += t(35, 860, "1º turno: " + pctCurto(f1.ra, 2) + " × " + pctCurto(f1.rb, 2) + " dos válidos", { s: 14, b: true, c: "#c9d6e6", max: 470 });
    if (f2) o += t(35, 884, "2º turno: " + pctCurto(f2.ra, 2) + " × " + pctCurto(f2.rb, 2), { s: 14, b: true, c: "#c9d6e6", max: 470 });
    if (!dn.s1.length) o += t(35, 908, "1º turno: importe o histórico do 1º turno (IMPORTAR-EVOLUCAO)", { s: 12, c: "#ffd8a8", max: 470 });
    return svg(W, H, o + t(35, 945, "Fonte: TSE · % na soma dos dois · cheia = 2º turno, tracejada = 1º", { s: 10, c: C.apagado2, max: 470 }));
  }
  G["duasnoites-h"] = function () { return telaDuasNoites(false); };
  G["duasnoites-v"] = function () { return telaDuasNoites(true); };

  // ---- Deputados federais eleitos: N por tela, trocando sozinha -------------
  // Lista do TSE (cargo 6, so quem o TSE marcou eleito), lida pelo
  // ESTADOS.bat. Estados e tempo em web\deputados-config.js. Ordem: regiao
  // (N, NE, CO, SE, S), nome do estado, e no estado do mais votado ao menos.
  var DEP_UF = { ac: "ACRE", al: "ALAGOAS", ap: "AMAPÁ", am: "AMAZONAS", ba: "BAHIA", ce: "CEARÁ", df: "DISTRITO FEDERAL",
    es: "ESPÍRITO SANTO", go: "GOIÁS", ma: "MARANHÃO", mt: "MATO GROSSO", ms: "MATO GROSSO DO SUL", mg: "MINAS GERAIS",
    pa: "PARÁ", pb: "PARAÍBA", pr: "PARANÁ", pe: "PERNAMBUCO", pi: "PIAUÍ", rj: "RIO DE JANEIRO", rn: "RIO GRANDE DO NORTE",
    rs: "RIO GRANDE DO SUL", ro: "RONDÔNIA", rr: "RORAIMA", sc: "SANTA CATARINA", sp: "SÃO PAULO", se: "SERGIPE", to: "TOCANTINS" };
  var DEP_REGIOES = [["Norte", ["ac", "am", "ap", "pa", "ro", "rr", "to"]], ["Nordeste", ["al", "ba", "ce", "ma", "pb", "pe", "pi", "rn", "se"]],
    ["Centro-Oeste", ["df", "go", "ms", "mt"]], ["Sudeste", ["es", "mg", "rj", "sp"]], ["Sul", ["pr", "rs", "sc"]]];
  var T0_DEP = Date.now();   // a troca comeca na 1a tela quando a pagina abre
  // todos = navegacao manual (gerenciador): os 27 estados, mesma ordem.
  function paginasDeputados(todos) {
    var cfg = window.GCTSE_DEPUTADOS || {}, porTela = Math.max(1, Math.min(5, +cfg.por_tela || 5));
    var pedidos = todos ? Object.keys(DEP_UF) : (cfg.estados || []).map(function (u) { return String(u).toLowerCase().trim(); });
    var cm = (window.GCTSE_ESTADOS || {}).camara || {}, pags = [];
    DEP_REGIOES.forEach(function (rg) {
      rg[1].filter(function (u) { return pedidos.indexOf(u) >= 0; })
        .sort(function (a, b) { return DEP_UF[a].localeCompare(DEP_UF[b], "pt-BR"); })
        .forEach(function (u) {
          var x = cm[u], lista = x ? comoLista(x.lista).slice() : [];
          if (!lista.length) return;   // estado ainda sem eleito do TSE: fica fora
          lista.sort(function (a, b) { return ((+b.votos || 0) - (+a.votos || 0)) || String(a.nome).localeCompare(String(b.nome), "pt-BR"); });
          // so os N mais votados de cada estado (deputados-config.js)
          var n = cfg.apenas_mais_votados === false ? Math.ceil(lista.length / porTela) : 1;
          for (var k = 0; k < n; k++) {
            pags.push({ uf: u, regiao: rg[0], x: x, cs: lista.slice(k * porTela, (k + 1) * porTela), ini: k * porTela, k: k, n: n,
              total: lista.length, vagas: +x.vagas || 0 });
          }
        });
    });
    return pags;
  }
  // Navegacao manual: "sp:2" = Sao Paulo, 3a tela do estado (vem do
  // gerenciador pela URL ?dep= ou por comando na saida).
  //   "sp:0" = estado fixo   |   "r-norte" = estados da regiao, trocando sozinho
  function depManual() {
    var v = String(window.__gctseDep || "");
    if (!v) { try { v = new URLSearchParams(location.search).get("dep") || ""; } catch (e) { v = ""; } }
    return /^([a-z]{2}:\d+|r-[a-z-]+)$/.test(v) ? v : "";
  }
  var REG_DEP = { "r-norte": "Norte", "r-nordeste": "Nordeste", "r-centro-oeste": "Centro-Oeste", "r-sudeste": "Sudeste", "r-sul": "Sul" };
  // Telas e tela da vez conforme o modo (automatico, estado fixo, regiao).
  function selecaoDep() {
    var man = depManual(), reg = REG_DEP[man];
    if (reg) {
      var ufsR = ufsDaRegiao(reg), pr = paginasDeputados(true).filter(function (p) { return ufsR.indexOf(p.uf) >= 0; });
      return { pags: pr, ip: indiceDeputados(pr), regiao: reg };
    }
    var ps = paginasDeputados(!!man);
    if (man) {   // estado escolhido sem eleitos ainda: avisa DELE (nunca mostra outro estado)
      var ufM = man.split(":")[0];
      if (!ps.some(function (p) { return p.uf === ufM; })) return { pags: [], ip: 0, regiao: "", faltaUf: ufM };
    }
    return { pags: ps, ip: man ? indiceManual(ps, man) : indiceDeputados(ps), regiao: "" };
  }
  function indiceManual(pags, v) {
    var uf = v.split(":")[0], k = +v.split(":")[1], ult = -1;
    for (var i = 0; i < pags.length; i++) if (pags[i].uf === uf) { ult = i; if (pags[i].k === k) return i; }
    return ult >= 0 ? ult : 0;
  }
  function indiceDeputados(pags) {
    var seg = Math.max(3, +(window.GCTSE_DEPUTADOS || {}).segundos || 8);
    return pags.length ? Math.floor((Date.now() - T0_DEP) / (seg * 1000)) % pags.length : 0;
  }
  function seloDep(x) {
    if (!x) return { texto: "AGUARDANDO APURAÇÃO", cor: C.trilho };
    if (x.andamento === "f") return { texto: "TOTALIZAÇÃO FINAL", cor: C.verde };
    if (x.urnas_pct >= 100) return { texto: "100% DAS URNAS", cor: C.verde };
    return { texto: "PARCIAL", cor: C.vermelho };
  }
  // Foto oficial do TSE: {base}/{ciclo}/{eleicao da Camara}/fotos/{uf}/{sqcand}.jpeg.
  // Embaixo ficam as iniciais: se a foto nao vier, elas aparecem.
  var FOTO_DEP = { falhou: {} };
  window.__gctseFotoD = function (img, ok) {
    if (ok) return;
    FOTO_DEP.falhou[img.getAttribute("href")] = true;
    if (img.parentNode) img.parentNode.removeChild(img);
  };
  function fotoDep(u, c, x, y, w, h) {
    var ini = String(c.nome || "").split(" ").filter(function (p) { return p.length > 2; }).slice(0, 2).map(function (p) { return p.charAt(0); }).join("");
    var o = r(x, y, w, h, "#1c2a40", 4) + t(x + w / 2, y + h / 2 + w * 0.12, ini, { s: Math.round(w * 0.34), b: true, c: C.apagado2, a: "middle" });
    var tse = (window.GCTSE_ESTADOS || {}).tse;
    if (window.GCTSE_FOTOS_DO_TSE !== true || window.__gctseSemFotos || !tse || !tse.base || !c.sqcand) return o;
    var url = tse.base + "/" + tse.ciclo + "/" + (tse.eleicao_camara || tse.eleicao) + "/fotos/" + u + "/" + c.sqcand + ".jpeg"; url = viaLocal(url);
    if (FOTO_DEP.falhou[url]) return o;
    return o + '<image href="' + esc(url) + '" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h +
      '" preserveAspectRatio="xMidYMin slice" onload="__gctseFotoD(this,true)" onerror="__gctseFotoD(this,false)"/>';
  }
  // Nome em ate 2 linhas, quebrando no espaco que deixa as partes parecidas.
  function linhasNome(nome, n) {
    nome = String(nome || "");
    if (nome.length <= n) return [nome];
    var ps = nome.split(" "), melhor = null;
    for (var i = 1; i < ps.length; i++) {
      var l1 = ps.slice(0, i).join(" "), l2 = ps.slice(i).join(" "), d = Math.max(l1.length, l2.length);
      if (!melhor || d < melhor.d) melhor = { d: d, l: [l1, l2] };
    }
    return melhor ? melhor.l : [nome];
  }
  function situacaoDep(c) {
    var st = String(c.situacao || "").toUpperCase();
    if (/M[ÉE]DIA/.test(st)) return "ELEITO POR MÉDIA";
    if (/QP/.test(st)) return "ELEITO POR QP";
    return st ? "ELEITO" : "";
  }
  function subDep(pg) {
    if (pg.n === 1 && pg.total > pg.cs.length) return "DEPUTADOS FEDERAIS ELEITOS  ·  OS " + pg.cs.length + " MAIS VOTADOS  ·  " + pg.total + " eleitos no estado";
    return "DEPUTADOS FEDERAIS ELEITOS  ·  " + (pg.ini + 1) + "º" + (pg.cs.length > 1 ? " a " + (pg.ini + pg.cs.length) + "º" : "") +
      " mais votados  ·  " + pg.total + (pg.vagas && pg.vagas !== pg.total ? " de " + pg.vagas + " vagas" : " eleitos");
  }
  function semDeputados(W, H, v, uf) {
    var tit = uf ? (DEP_UF[uf] || uf.toUpperCase()) : "DEPUTADOS FEDERAIS ELEITOS";
    var o = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, uf ? tit : "DEPUTADOS FEDERAIS", { s: 32, b: true, ls: 1, max: 450 }) :
      t(73, 57, tit, { s: 36, b: true, ls: 1 }) + (uf ? t(73, 85, "DEPUTADOS FEDERAIS ELEITOS", { s: 18, b: true, c: "#c9d6e6" }) : "");
    return svg(W, H, marcaVazio() + o + t(W / 2, H / 2, "aguardando os eleitos do TSE" + (uf ? "" : " (ESTADOS.bat)"), { s: v ? 18 : 24, c: C.apagado, a: "middle" }));
  }
  G["deputados-h"] = function () {
    var W = 1280, H = 720, sel = selecaoDep(), pags = sel.pags;
    if (!pags.length) return semDeputados(W, H, false, sel.faltaUf);
    var ip = sel.ip, pg = pags[ip];
    var o = t(73, 57, DEP_UF[pg.uf], { s: 36, b: true, ls: 1, max: W - 73 - 540 }) +
      t(73, 85, subDep(pg), { s: 18, b: true, c: "#c9d6e6", max: W - 146 }) + seloH(W, seloDep(pg.x));
    var gap = 18, w = (1134 - gap * 4) / 5, y = 118, h = 530;
    var x0 = 73 + (5 - pg.cs.length) * (w + gap) / 2;   // ultima tela do estado com menos: centraliza
    pg.cs.forEach(function (c, i) {
      var x = x0 + i * (w + gap), cor = corPartidoCamara(c.partido, 0);
      o += r(x, y, w, h, "rgba(8,14,32,0.80)", 10) + r(x, y, w, 6, cor, 3);
      o += t(x + 16, y + 38, (pg.ini + i + 1) + "º", { s: 20, b: true, c: C.apagado });
      var pw = 174, ph = 232;
      o += fotoDep(pg.uf, c, x + (w - pw) / 2, y + 50, pw, ph);
      var ln = linhasNome(c.nome, 14), yn = y + 318;
      ln.forEach(function (l, j) { o += t(x + w / 2, yn + j * 26, l, { s: 22, b: true, a: "middle", max: w - 20 }); });
      var yp = yn + ln.length * 26 + 2;
      o += t(x + w / 2, yp, c.partido + (c.numero ? "  ·  " + c.numero : ""), { s: 16, c: C.apagado, a: "middle", max: w - 20 });
      o += t(x + w / 2, y + h - 74, inteiro(c.votos), { s: 32, b: true, a: "middle", max: w - 16 });
      o += t(x + w / 2, y + h - 52, "votos", { s: 15, c: C.apagado, a: "middle" });
      var sit = situacaoDep(c);
      if (sit) o += t(x + w / 2, y + h - 20, sit, { s: 13, b: true, c: "#69db7c", a: "middle", ls: 1, max: w - 16 });
    });
    o += t(73, 700, "Fonte: TSE — deputados federais eleitos (situação e votos do TSE)  ·  " + pg.regiao, { s: 13, c: C.apagado2, max: 760 });
    o += t(1207, 700, (sel.regiao ? REG_NOME[sel.regiao] + " · estado " + (ip + 1) + " de " + pags.length : DEP_UF[pg.uf] + (pg.n > 1 ? " " + (pg.k + 1) + "/" + pg.n : "") + "   ·   " + (pg.n > 1 ? "tela " : "estado ") + (ip + 1) + " de " + pags.length), { s: 13, c: C.apagado2, a: "end" });
    return svg(W, H, o);
  };
  G["deputados-v"] = function () {
    var W = 540, H = 960, sel = selecaoDep(), pags = sel.pags;
    if (!pags.length) return semDeputados(W, H, true, sel.faltaUf);
    var ip = sel.ip, pg = pags[ip];
    var o = r(35, 48, 6, 38, C.destaque) + t(53, 80, DEP_UF[pg.uf], { s: 32, b: true, ls: 1, max: W - 53 - 35 }) +
      t(53, 106, "DEPUTADOS FEDERAIS ELEITOS · " + (pg.ini + 1) + "º a " + (pg.ini + pg.cs.length) + "º de " + pg.total,
        { s: 15, b: true, c: "#c9d6e6", max: W - 53 - 35 }) + seloV(W, seloDep(pg.x));
    var y0 = 168, hh = 142, gap = 7;
    pg.cs.forEach(function (c, i) {
      var y = y0 + i * (hh + gap), cor = corPartidoCamara(c.partido, 0);
      o += r(35, y, 470, hh, "rgba(8,14,32,0.80)", 8) + r(35, y, 6, hh, cor, 3);
      o += fotoDep(pg.uf, c, 51, y + 9, 93, 124);
      o += t(160, y + 30, (pg.ini + i + 1) + "º", { s: 16, b: true, c: C.apagado });
      var ln = linhasNome(c.nome, 20);
      ln.forEach(function (l, j) { o += t(160, y + 58 + j * 25, l, { s: 22, b: true, max: 330 }); });
      o += t(160, y + 124, c.partido + (c.numero ? " · " + c.numero : ""), { s: 15, c: C.apagado, max: 170 });
      o += t(493, y + 124, inteiro(c.votos) + " votos", { s: 22, b: true, a: "end", max: 200 });
      var sit = situacaoDep(c);
      if (sit) o += t(493, y + 30, sit, { s: 11, b: true, c: "#69db7c", a: "end", ls: 1 });
    });
    o += t(35, 945, "Fonte: TSE · " + (sel.regiao ? REG_NOME[sel.regiao] + " · estado " + (ip + 1) + " de " + pags.length : DEP_UF[pg.uf] + (pg.n > 1 ? " " + (pg.k + 1) + "/" + pg.n : "") + " · " + (pg.n > 1 ? "tela " : "estado ") + (ip + 1) + " de " + pags.length), { s: 11, c: C.apagado2, max: 470 });
    return svg(W, H, o);
  };

  // =====================================================================
  // 2o TURNO / ESTILO TELAO: apuracao por regiao, presidente com mapa, por
  // regiao e por estado, governadores, 1o x 2o turno. Tudo do TSE: dados.js
  // (presidente; no 2o turno tambem "turno1", o 1o turno guardado) e
  // estados.js (governador, senador).
  // =====================================================================
  var REG_NOME = { "Norte": "NORTE", "Nordeste": "NORDESTE", "Centro-Oeste": "CENTRO-OESTE", "Sudeste": "SUDESTE", "Sul": "SUL" };
  function E() { return window.GCTSE_ESTADOS || {}; }
  // Fonte do presidente: o boletim atual, ou o 1o turno guardado (t1).
  function fontePres(t1) {
    var d = D(), x = d.turno1;
    if (t1 && x && x.br && x.br.tem) {
      var nb = x.br; nb.candidatos = comoLista(nb.candidatos);
      return { br: nb, eleicao: x.eleicao, turno: 1, guardado: true,
        uf: function (k) { var y = (x.ufs || {})[k]; if (!y || !y.tem) return null; y.candidatos = comoLista(y.candidatos); return y; } };
    }
    var b = br();
    return { br: b, eleicao: (d.tse || {}).eleicao, turno: b && candidatos(b).length === 2 ? 2 : 1, guardado: false, uf: uf };
  }
  function temTurno1() { var x = D().turno1; return !!(x && x.br && x.br.tem); }
  function eleitoDe(f, numero) {
    var cs = f.br ? candidatos(f.br) : [];
    for (var i = 0; i < cs.length; i++) if (String(cs[i].numero) === String(numero)) return !!cs[i].eleito;
    return false;
  }
  function urlFotoPres(c, ele) {
    if (!ele || ele === (D().tse || {}).eleicao) return urlFoto(c);
    var tse = D().tse;
    if (window.GCTSE_FOTOS_DO_TSE !== true || window.__gctseSemFotos || !tse || !tse.base || !c || !c.sqcand) return "";
    var url = tse.base + "/" + tse.ciclo + "/" + ele + "/fotos/br/" + c.sqcand + ".jpeg"; url = viaLocal(url);
    return FOTO.falhou[url] ? "" : url;
  }
  // Silhueta (sem foto) - desenho, nao imagem.
  function silhueta(x, y, w, h, cf) {
    return r(x, y, w, h, cf || "#22324a", 4) +
      '<circle cx="' + (x + w / 2).toFixed(1) + '" cy="' + (y + h * 0.36).toFixed(1) + '" r="' + (w * 0.2).toFixed(1) + '" fill="#5b6c86"/>' +
      '<path d="M' + (x + w * 0.16).toFixed(1) + " " + (y + h).toFixed(1) + " Q" + (x + w * 0.16).toFixed(1) + " " + (y + h * 0.62).toFixed(1) + " " +
      (x + w / 2).toFixed(1) + " " + (y + h * 0.62).toFixed(1) + " Q" + (x + w * 0.84).toFixed(1) + " " + (y + h * 0.62).toFixed(1) + " " +
      (x + w * 0.84).toFixed(1) + " " + (y + h).toFixed(1) + ' Z" fill="#5b6c86"/>';
  }
  // Foto com a silhueta por baixo (se a foto do TSE nao vier, fica a silhueta).
  function fotoOuSilhueta(url, x, y, w, h) {
    var o = silhueta(x, y, w, h);
    if (!url) return o;
    return o + '<image href="' + esc(url) + '" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h +
      '" preserveAspectRatio="xMidYMin slice" onerror="__gctseFotoD(this,false)"/>';
  }
  function etiquetaEleito(x, y, k) {
    k = k || 1;
    return r(x, y, 78 * k, 22 * k, C.verde, 3) + t(x + 39 * k, y + 16 * k, "ELEITO", { s: Math.round(14 * k), b: true, a: "middle", ls: 1 });
  }
  // Mapa com cor por estado (fn devolve a cor, ou null = apagado).
  function mapaCor(x, y, escala, fn, opc) {
    opc = opc || {};
    var M = window.MAPA_BRASIL, out = '<g transform="translate(' + x + " " + y + ") scale(" + escala + ')">', k, e, cc;
    for (k in M.estados) {
      e = M.estados[k]; cc = fn(k);
      out += '<path d="' + e.path + '" fill="' + (cc || opc.apagado || "#1a2840") + '" stroke="' + (opc.borda || C.fundo) +
        '" stroke-width="' + ((opc.esp || 1.2) / escala).toFixed(2) + '" stroke-linejoin="round"/>';
      if (opc.hachura && opc.hachura(k)) out += '<path d="' + e.path + '" fill="url(#hach)" stroke="none"/>';
    }
    if (opc.rotulos) {
      var contorno = ' stroke="' + C.fundo + '" stroke-width="' + (3 / escala).toFixed(2) + '" paint-order="stroke" stroke-linejoin="round"';
      for (k in M.estados) {
        if (opc.rotulos !== "todos" && PEQUENOS.indexOf(k) >= 0) continue;
        if (opc.soRotulo && !opc.soRotulo(k)) continue;
        e = M.estados[k];
        out += '<text x="' + e.cx + '" y="' + (e.cy + 5) + '" font-size="' + ((opc.fonte || 13) / escala).toFixed(1) +
          '" font-weight="700" fill="#fff" text-anchor="middle"' + contorno + ">" + k.toUpperCase() + "</text>";
      }
    }
    return out + "</g>";
  }
  var HACH = '<defs><pattern id="hach" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">' +
    '<rect width="3" height="7" fill="rgba(255,255,255,0.45)"/></pattern></defs>';
  // Soma de varios estados (regiao): votos por candidato e secoes.
  function agregar(f, lista) {
    var soma = {}, ref = {}, tot = 0, sec = 0, secT = 0, n = 0, fim = true;
    lista.forEach(function (k) {
      var x = f.uf(k);
      if (!x) { fim = false; return; }
      n++;
      if (x.secoes) { sec += +x.secoes.totalizadas || 0; secT += +x.secoes.total || 0; }
      if (x.andamento !== "f") fim = false;
      candidatos(x).forEach(function (c) {
        soma[c.numero] = (soma[c.numero] || 0) + (+c.votos || 0); if (!ref[c.numero]) ref[c.numero] = c; tot += +c.votos || 0;
      });
    });
    var cs = Object.keys(soma).map(function (k) {
      var c = ref[k];
      return { numero: k, nome: c.nome, partido: c.partido, sqcand: c.sqcand, votos: soma[k], pct: tot ? 100 * soma[k] / tot : 0 };
    }).sort(function (a, b) { return b.votos - a.votos; });
    return { cs: cs, pctUrnas: secT ? 100 * sec / secT : null, n: n, fim: fim && n === lista.length };
  }
  function ufsDaRegiao(nome) { for (var i = 0; i < DEP_REGIOES.length; i++) if (DEP_REGIOES[i][0] === nome) return DEP_REGIOES[i][1]; return []; }
  function regiaoDaUf(k) { for (var i = 0; i < DEP_REGIOES.length; i++) if (DEP_REGIOES[i][1].indexOf(k) >= 0) return DEP_REGIOES[i][0]; return ""; }
  function barraFina(x, y, w, frac, c) { return r(x, y, w, 8, "rgba(255,255,255,0.14)", 4) + (frac > 0 ? r(x, y, Math.max(6, w * Math.min(1, frac)), 8, c, 4) : ""); }
  function corApuracao(p) {
    if (p == null || !(p > 0)) return null;
    if (p >= 100) return "#16b216";
    if (p >= 75) return "#2f9e5c";
    if (p >= 50) return "#3a8a63";
    if (p >= 25) return "#3d7562";
    return "#3b5f5c";
  }
  function seloDe(f) {
    var b = f.br;
    if (ensaioAtivo()) return { texto: (window.GCTSE_DADOS || {}).reprise ? "REPRISE — NÃO VAI AO AR" : "ENSAIO — NÃO VAI AO AR", cor: C.vermelho };
    if (D().modo === "SIMULADO") return { texto: "SIMULADO — NÃO OFICIAL", cor: C.vermelho };
    if (b && b.andamento === "f") return { texto: "TOTALIZAÇÃO FINAL", cor: C.verde };
    var p = b && b.secoes ? b.secoes.pct : null;
    if (!b || !(p > 0)) return { texto: "AGUARDANDO APURAÇÃO", cor: C.trilho };
    if (p >= 100) return { texto: "100% DAS URNAS", cor: C.verde };
    return { texto: "PARCIAL", cor: C.vermelho };
  }
  function turnoTxt(f) { return f.turno === 2 ? "2º TURNO" : "1º TURNO"; }

  // ---- APURACAO por regiao e estado (% de secoes totalizadas) -------------
  // abstencao de um conjunto de estados (regiao): soma do TSE, sobre o
  // eleitorado ja apurado (abstencao / (abstencao + comparecimento))
  function abstDe(f, ufs) {
    var a = 0, c = 0;
    ufs.forEach(function (k) { var x = f.uf(k), e = x && x.eleitorado; if (e) { a += +e.abstencao || 0; c += +e.comparecimento || 0; } });
    return a + c > 0 ? 100 * a / (a + c) : null;
  }
  var COR_COMP = "#3a8a63", COR_ABST = "#5b7fbf";
  function pct1v(v) { return v == null || isNaN(v) ? "—" : Number(v).toFixed(1).replace(".", ",") + "%"; }
  // barra dupla comparecimento (verde) x abstencao (azul), como no app do TSE
  function barraComp(x, y, w, h, ab, fs) {
    if (ab == null) return r(x, y, w, h, "rgba(255,255,255,0.08)", 4) + t(x + w / 2, y + h / 2 + fs * 0.36, "aguardando", { s: fs, c: C.apagado, a: "middle" });
    var wc = w * (100 - ab) / 100, o = r(x, y, w, h, COR_ABST, 4) + r(x, y, Math.max(4, wc), h, COR_COMP, 4);
    o += t(x + 10, y + h / 2 + fs * 0.36, pct(100 - ab), { s: fs, b: true });
    o += t(x + w - 10, y + h / 2 + fs * 0.36, pct(ab), { s: fs, b: true, a: "end" });
    return o;
  }
  function blocoRegiao(f, nome, x, y, w, passo) {
    var ufs = ufsDaRegiao(nome), ag = agregar(f, ufs), p = ag.pctUrnas, ab = abstDe(f, ufs), o = "";
    o += r(x, y, w, 40, "rgba(255,255,255,0.06)", 6);
    o += rosca(x + 22, y + 20, 13, 6, [{ v: p || 0, c: "#2fd17a" }, { v: 100 - (p || 0), c: "rgba(255,255,255,0.10)" }]);
    o += t(x + 44, y + 26, REG_NOME[nome], { s: 15, b: true, max: w - 168 }) + t(x + w - 66, y + 26, p == null ? "—" : pct1v(p), { s: 14, b: true, a: "end" }) +
      t(x + w - 10, y + 26, pct1v(ab), { s: 14, b: true, a: "end", c: "#9fbaf0" });
    ufs.slice().sort(function (a, b) { return DEP_UF[a].localeCompare(DEP_UF[b], "pt-BR"); }).forEach(function (k, i) {
      var x2 = f.uf(k), pu = x2 && x2.secoes ? x2.secoes.pct : null, au = x2 && x2.eleitorado ? x2.eleitorado.pct_abstencao : null, yy = y + 40 + passo * (i + 1) - 6;
      o += t(x + 12, yy, DEP_UF[k], { s: 13, b: true, c: "#c9d6e6", max: w * 0.47 });
      o += barraFina(x + w * 0.5, yy - 8, w * 0.16, (pu || 0) / 100, pu >= 100 ? C.verde : "#2fd17a");
      o += t(x + w - 66, yy, pu == null ? "—" : Math.floor(pu) + "%", { s: 13, b: true, a: "end" });
      o += t(x + w - 10, yy, au == null || !(pu > 0) ? "—" : pct1v(au), { s: 13, b: true, a: "end", c: "#9fbaf0" });
    });
    return o;
  }
  G["apuracao-h"] = function () {
    var W = 1280, H = 720, f = fontePres(false), b = f.br, s = b ? b.secoes : null, e = b ? b.eleitorado : null;
    var o = t(73, 57, "APURAÇÃO", { s: 36, b: true, ls: 1 }) + t(73, 85, "seções totalizadas e abstenção por região e estado  ·  " + turnoTxt(f) + "  ·  " + subtitulo(), { s: 18, c: C.apagado, max: 640 }) + seloH(W, seloDe(f));
    // cabecalho das colunas (urnas | abstencao)
    var BW = 285;
    [30, 327].forEach(function (x0) { o += t(x0 + BW - 66, 106, "URNAS", { s: 10, b: true, c: C.apagado, a: "end", ls: 1 }) + t(x0 + BW - 10, 106, "ABST.", { s: 10, b: true, c: "#9fbaf0", a: "end", ls: 1 }); });
    o += blocoRegiao(f, "Norte", 30, 112, BW, 22) + blocoRegiao(f, "Centro-Oeste", 30, 330, BW, 22) + blocoRegiao(f, "Sul", 30, 480, BW, 22);
    o += blocoRegiao(f, "Nordeste", 327, 112, BW, 22) + blocoRegiao(f, "Sudeste", 327, 380, BW, 22);
    o += mapaCor(628, 150, 0.6, function (k) { var x = f.uf(k); return corApuracao(x && x.secoes ? x.secoes.pct : null); }, { rotulos: true, fonte: 12, apagado: "#22324a" });
    var p = s ? s.pct : null, ab = e && (+e.comparecimento || +e.abstencao) ? e.pct_abstencao : null;
    o += rosca(1100, 270, 76, 17, [{ v: p || 0, c: "#2fd17a" }, { v: 100 - (p || 0), c: "rgba(255,255,255,0.10)" }]);
    o += t(1100, 275, p == null ? "—" : pct(p), { s: 28, b: true, a: "middle" }) + t(1100, 298, "URNAS APURADAS", { s: 11, b: true, c: C.apagado, a: "middle", ls: 1 });
    o += t(1100, 380, "BRASIL", { s: 22, b: true, a: "middle", ls: 2 });
    if (s && s.total) o += t(1100, 404, inteiro(s.totalizadas) + " de " + inteiro(s.total) + " seções", { s: 14, c: C.apagado, a: "middle" });
    o += t(990, 444, "COMPARECIMENTO", { s: 10, b: true, c: "#7fd1a3", ls: 1 }) + t(1210, 444, "ABSTENÇÃO", { s: 10, b: true, c: "#9fbaf0", a: "end", ls: 1 });
    o += barraComp(990, 452, 220, 30, ab, 14);
    [["até 25%", "#3b5f5c"], ["25 a 50%", "#3d7562"], ["50 a 75%", "#3a8a63"], ["75 a 99%", "#2f9e5c"], ["100%", "#16b216"]].forEach(function (lg, i) {
      o += r(1010, 530 + i * 24, 14, 14, lg[1], 2) + t(1032, 542 + i * 24, lg[0], { s: 13, c: C.apagado });
    });
    o += t(73, 700, "Fonte: TSE — seções totalizadas e abstenção do boletim de Presidente de cada estado (abstenção sobre o eleitorado já apurado; regiões sem o exterior)", { s: 13, c: C.apagado2, max: 1134 });
    return svg(W, H, o);
  };
  G["apuracao-v"] = function () {
    var W = 540, H = 960, f = fontePres(false), b = f.br, s = b ? b.secoes : null, p = s ? s.pct : null;
    var o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "APURAÇÃO", { s: 32, b: true, ls: 1 }) + t(53, 106, turnoTxt(f) + " · " + subtitulo(), { s: 15, c: C.apagado, max: 450 }) + seloV(W, seloDe(f));
    o += mapaCor(40, 172, 0.5, function (k) { var x = f.uf(k); return corApuracao(x && x.secoes ? x.secoes.pct : null); }, { rotulos: true, fonte: 10, apagado: "#22324a" });
    o += rosca(430, 260, 62, 14, [{ v: p || 0, c: "#2fd17a" }, { v: 100 - (p || 0), c: "rgba(255,255,255,0.10)" }]);
    o += t(430, 266, p == null ? "—" : pct(p), { s: 22, b: true, a: "middle" }) + t(430, 350, "BRASIL", { s: 16, b: true, a: "middle", ls: 2 });
    var eb = b ? b.eleitorado : null, abB = eb && (+eb.comparecimento || +eb.abstencao) ? eb.pct_abstencao : null;
    o += t(330, 392, "COMPARECIMENTO", { s: 9, b: true, c: "#7fd1a3", ls: 1 }) + t(505, 392, "ABST.", { s: 9, b: true, c: "#9fbaf0", a: "end", ls: 1 }) + barraComp(330, 398, 175, 26, abB, 12);
    ["Norte", "Nordeste", "Centro-Oeste", "Sudeste", "Sul"].forEach(function (nome, i) {
      var ufs = ufsDaRegiao(nome), ag = agregar(f, ufs), pp = ag.pctUrnas, ab = abstDe(f, ufs), y = 470 + i * 92;
      o += r(35, y, 470, 82, "rgba(8,14,32,0.78)", 8) + t(55, y + 28, REG_NOME[nome], { s: 20, b: true, ls: 1 });
      o += t(485, y + 29, pp == null ? "—" : pct(pp), { s: 20, b: true, a: "end" }) + t(370, y + 29, "urnas", { s: 11, c: C.apagado, a: "end" }) + barraFina(55, y + 40, 430, (pp || 0) / 100, "#2fd17a");
      o += t(55, y + 70, "abstenção", { s: 12, c: "#9fbaf0" }) + t(485, y + 70, pct1v(ab), { s: 16, b: true, a: "end", c: "#9fbaf0" });
    });
    return svg(W, H, o + t(35, 945, "Fonte: TSE — seções totalizadas e abstenção de Presidente", { s: 11, c: C.apagado2 }));
  };

  // ---- PRESIDENTE com MAPA (quem lidera cada estado) ----------------------
  function liderF(f, k) { var x = f.uf(k), cs = x ? candidatos(x) : []; return cs.length && cs[0].votos > 0 ? cs[0] : null; }
  function placarF(f) { var n = {}; Object.keys(DEP_UF).forEach(function (k) { var l = liderF(f, k); if (l) n[l.numero] = (n[l.numero] || 0) + 1; }); return n; }
  function cartaoMapa(f, c, x, y, w, h, nEst, k) {
    var cc = cor(c), o = r(x, y, w, h, "rgba(8,14,32,0.82)", 8) + r(x, y, 8, h, cc, 4);
    var url = urlFotoPres(c, f.eleicao), fw = (h - 20) * 0.75;
    o += fotoOuSilhueta(url, x + 20, y + 10, fw, h - 20);
    var tx = x + 36 + fw;
    o += t(tx, y + 32 * k, c.nome, { s: Math.round(22 * k), b: true, max: w - (tx - x) - (eleitoDe(f, c.numero) ? 112 * k : 20) });
    o += t(tx, y + 54 * k, c.partido, { s: Math.round(15 * k), c: C.apagado });
    o += t(tx, y + h - 18 * k, pct(c.pct), { s: Math.round(38 * k), b: true });
    o += t(x + w - 16, y + h - 34 * k, "NA FRENTE EM", { s: Math.round(12 * k), b: true, c: C.apagado, a: "end", ls: 1 });
    o += t(x + w - 16, y + h - 14 * k, (nEst || 0) + (nEst === 1 ? " ESTADO" : " ESTADOS"), { s: Math.round(17 * k), b: true, a: "end" });
    if (eleitoDe(f, c.numero)) o += etiquetaEleito(x + w - 16 - 78 * k, y + 14 * k, k);
    return o;
  }
  function telaPresMapa(t1, v) {
    var f = fontePres(t1), cs = f.br ? candidatos(f.br).filter(function (c) { return c.votos > 0 || f.turno === 2; }) : [];
    var nCards = f.turno === 2 ? 2 : 3, pl = placarF(f), o;
    var tit = "PRESIDENTE — " + turnoTxt(f), sub = (f.guardado ? "resultado final do 1º turno" : subtitulo()) + "  ·  cor = quem lidera no estado";
    if (!v) {
      var W = 1280, H = 720;
      o = t(73, 57, tit, { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, sub, { s: 18, c: C.apagado, max: 640 }) + seloH(W, seloDe(f));
      var hc = nCards === 2 ? 190 : 150, gap = 18;
      for (var i = 0; i < nCards; i++) o += cs[i] ? cartaoMapa(f, cs[i], 73, 130 + i * (hc + gap), 560, hc, pl[cs[i].numero], nCards === 2 ? 1.15 : 1) : "";
      o += mapaCor(690, 112, 0.86, function (k) { var l = liderF(f, k); return l ? cor(l) : null; }, { rotulos: true, fonte: 13 });
      var b = f.br, s = b ? b.secoes : null;
      o += t(73, 700, "Fonte: TSE" + (s ? "  ·  urnas apuradas " + pct(s.pct) : ""), { s: 13, c: C.apagado2 });
      return svg(W, H, o);
    }
    var W2 = 540, H2 = 960;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 30, b: true, ls: 1, max: 450 }) + t(53, 106, sub, { s: 13, c: C.apagado, max: 450 }) + seloV(W2, seloDe(f));
    var hv = nCards === 2 ? 150 : 118;
    for (var j = 0; j < nCards; j++) o += cs[j] ? cartaoMapa(f, cs[j], 35, 170 + j * (hv + 12), 470, hv, pl[cs[j].numero], 0.82) : "";
    o += mapaCor(85, 170 + nCards * (hv + 12) + 10, 0.6, function (k) { var l = liderF(f, k); return l ? cor(l) : null; }, { rotulos: true, fonte: 10 });
    return svg(W2, H2, o + t(35, 945, "Fonte: TSE", { s: 11, c: C.apagado2 }));
  }
  G["presmapa-h"] = function () { return telaPresMapa(false, false); };
  G["presmapa-v"] = function () { return telaPresMapa(false, true); };
  G["presmapa1t-h"] = function () { return telaPresMapa(true, false); };
  G["presmapa1t-v"] = function () { return telaPresMapa(true, true); };

  // ---- PRESIDENTE 1o TURNO: resultado final, TODOS os candidatos ----------
  // So com o 1o turno guardado (dados.turno1, lido pelo coletor no 2o turno).
  function etiqueta2T(x, y) { return r(x, y, 92, 22, C.destaque, 3) + t(x + 46, y + 16, "2º TURNO", { s: 14, b: true, a: "middle", ls: 1 }); }
  function rodape1T(b) {
    var vv = b.votos || {}, el = b.eleitorado || {}, p = [];
    if (vv.validos != null) p.push("Válidos " + inteiro(vv.validos));
    if (vv.pct_brancos != null) p.push("Brancos " + pct(vv.pct_brancos));
    if (vv.pct_nulos != null) p.push("Nulos " + pct(vv.pct_nulos));
    if (el.pct_abstencao != null) p.push("Abstenção " + pct(el.pct_abstencao));
    return p;
  }
  function telaPres1T(v) {
    var W = v ? 540 : 1280, H = v ? 960 : 720;
    if (!temTurno1()) return marcaVazio() + svg(W, H, t(W / 2, H / 2, "1º turno ainda não guardado", { s: v ? 20 : 26, c: C.apagado, a: "middle" }));
    var f = fontePres(true), b = f.br, cs = candidatos(b).filter(function (c) { return c.votos > 0; });
    if (!cs.length) return marcaVazio() + svg(W, H, t(W / 2, H / 2, "1º turno sem candidatos", { s: 22, c: C.apagado, a: "middle" }));
    var tit = "PRESIDENTE — 1º TURNO", sub = "resultado final  ·  % dos votos válidos", rod = rodape1T(b), o, i, c, y, cc;
    var max = cs[0].pct || 1;
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, sub, { s: 18, c: C.apagado, max: 640 }) + seloH(W, seloDe(f));
      var n = cs.length, hr = Math.min(58, Math.floor(500 / n)), k = Math.min(1, hr / 50), x0 = 73, w = 1134;
      for (i = 0; i < n; i++) {
        c = cs[i]; y = 118 + i * hr; cc = cor(c);
        o += r(x0, y, w, hr - 6, "rgba(8,14,32,0.82)", 6) + r(x0, y, 7, hr - 6, cc, 3);
        var ym = y + (hr - 6) / 2;
        o += t(x0 + 22, ym + 7 * k, (i + 1) + "º", { s: Math.round(18 * k), b: true, c: C.apagado });
        o += t(x0 + 64, ym + 7 * k, c.nome + "  |  " + c.partido, { s: Math.round(20 * k), b: true, max: 430 });
        o += barraFina(x0 + 510, ym - 4, 360, (c.pct || 0) / max, cc);
        o += t(x0 + 1000, ym + 6 * k, inteiro(c.votos), { s: Math.round(16 * k), c: C.apagado, a: "end" });
        o += t(x0 + w - 16, ym + 9 * k, pct(c.pct), { s: Math.round(26 * k), b: true, a: "end" });
        if (c.eleito) o += etiquetaEleito(x0 + 400, ym - 11, 1);
        else if (c.segundo_turno) o += etiqueta2T(x0 + 400, ym - 11);
      }
      o += t(73, 662, rod.join("   ·   "), { s: 17, c: C.texto, max: 1134 });
      return svg(W, H, o + t(73, 700, "Fonte: TSE — boletim final do 1º turno (eleição " + (f.eleicao || "") + ")", { s: 13, c: C.apagado2 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 28, b: true, ls: 1, max: 450 }) + t(53, 106, sub, { s: 13, c: C.apagado, max: 450 }) + seloV(W, seloDe(f));
    var nv = cs.length, hv = Math.min(66, Math.floor(660 / nv)), kv = Math.min(1, hv / 60);
    for (i = 0; i < nv; i++) {
      c = cs[i]; y = 170 + i * hv; cc = cor(c);
      o += r(35, y, 470, hv - 6, "rgba(8,14,32,0.82)", 6) + r(35, y, 6, hv - 6, cc, 3);
      o += t(52, y + 24 * kv, (i + 1) + "º  " + c.nome, { s: Math.round(17 * kv), b: true, max: 300 }) + t(493, y + 26 * kv, pct(c.pct), { s: Math.round(24 * kv), b: true, a: "end" });
      o += t(52, y + 44 * kv, c.partido + "  ·  " + inteiro(c.votos) + " votos", { s: Math.round(12 * kv), c: C.apagado, max: 300 });
      if (hv >= 56) o += barraFina(52, y + hv - 18, 300, (c.pct || 0) / max, cc);
      if (c.eleito) o += etiquetaEleito(493 - 78, y + 34 * kv, 0.8);
      else if (c.segundo_turno) o += r(493 - 74, y + 34 * kv, 74, 18, C.destaque, 3) + t(493 - 37, y + 34 * kv + 13, "2º TURNO", { s: 11, b: true, a: "middle" });
    }
    var yr = 170 + nv * hv + 18;
    o += t(35, yr, rod.slice(0, 2).join("  ·  "), { s: 14, max: 470 }) + t(35, yr + 22, rod.slice(2).join("  ·  "), { s: 14, max: 470 });
    return svg(W, H, o + t(35, 945, "Fonte: TSE — 1º turno", { s: 11, c: C.apagado2 }));
  }
  G["pres1t-h"] = function () { return telaPres1T(false); };
  G["pres1t-v"] = function () { return telaPres1T(true); };

  // ---- PRESIDENTE | REGIOES (5 colunas com mini-mapa) ----------------------
  function cartaoMini(f, c, x, y, w, h) {
    var cc = cor(c), o = r(x, y, w, h, "rgba(8,14,32,0.82)", 6) + r(x, y, 5, h, cc, 2);
    o += fotoOuSilhueta(urlFotoPres(c, f.eleicao), x + 10, y + 7, (h - 14) * 0.75, h - 14);
    var tx = x + 18 + (h - 14) * 0.75;
    o += t(tx, y + 20, c.nome, { s: 13, b: true, max: w - (tx - x) - 8 });
    o += t(tx, y + 35, c.partido + " · " + inteiro(c.votos) + " votos", { s: 10, c: C.apagado, max: w - (tx - x) - 8 });
    o += t(x + w - 8, y + h - 9, pct(c.pct), { s: 24, b: true, a: "end", max: w - (tx - x) - 8 });
    if (eleitoDe(f, c.numero)) o += r(x + w - 58, y + 6, 50, 15, C.verde, 2) + t(x + w - 33, y + 17, "ELEITO", { s: 10, b: true, a: "middle" });
    return o;
  }
  function telaRegioes(t1, v) {
    var f = fontePres(t1), nomes = ["Norte", "Nordeste", "Centro-Oeste", "Sudeste", "Sul"], nC = f.turno === 2 ? 2 : 3, o;
    var tit = "PRESIDENTE  |  REGIÕES", sub = turnoTxt(f) + "  ·  " + (f.guardado ? "resultado final do 1º turno" : subtitulo()) + "  ·  soma dos estados (sem o exterior)";
    if (!v) {
      var W = 1280, H = 720, w = (1134 - 4 * 14) / 5;
      o = t(73, 57, tit, { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
      nomes.forEach(function (nome, i) {
        var x = 73 + i * (w + 14), ufs = ufsDaRegiao(nome), ag = agregar(f, ufs);
        o += t(x, 134, REG_NOME[nome], { s: 22, b: true, ls: 1, max: w });
        o += barraFina(x, 146, w - 86, (ag.pctUrnas || 0) / 100, "#2fd17a") + t(x + w, 155, ag.pctUrnas == null ? "—" : pct(ag.pctUrnas), { s: 15, b: true, a: "end" });
        o += mapaCor(x + 12, 170, 0.3, function (k) { if (ufs.indexOf(k) < 0) return null; var l = liderF(f, k); return l ? cor(l) : "#3a4c66"; }, { apagado: "#1f2d45", esp: 0.8 });
        var hC = nC === 2 ? 120 : 88;
        for (var j = 0; j < nC; j++) if (ag.cs[j]) o += cartaoMini(f, ag.cs[j], x, 380 + j * (hC + 8), w, hC);
      });
      return svg(W, H, o + t(73, 700, "Fonte: TSE — boletins de Presidente dos estados", { s: 13, c: C.apagado2 }));
    }
    var W2 = 540, H2 = 960;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "PRESIDENTE | REGIÕES", { s: 28, b: true, ls: 1, max: 450 }) + t(53, 106, turnoTxt(f) + " · soma dos estados", { s: 14, c: C.apagado }) + seloV(W2, seloDe(f));
    nomes.forEach(function (nome, i) {
      var y = 168 + i * 154, ufs = ufsDaRegiao(nome), ag = agregar(f, ufs);
      o += r(35, y, 470, 144, "rgba(8,14,32,0.82)", 8);
      o += mapaCor(42, y + 10, 0.2, function (k) { if (ufs.indexOf(k) < 0) return null; var l = liderF(f, k); return l ? cor(l) : "#3a4c66"; }, { apagado: "#1f2d45", esp: 0.6 });
      o += t(175, y + 30, REG_NOME[nome], { s: 20, b: true, ls: 1 }) + t(493, y + 30, ag.pctUrnas == null ? "—" : "urnas " + pct(ag.pctUrnas), { s: 13, c: C.apagado, a: "end" });
      for (var j = 0; j < 2; j++) {
        var c = ag.cs[j]; if (!c) continue;
        var yy = y + 66 + j * 40;
        o += r(175, yy - 15, 6, 22, cor(c), 2) + t(189, yy, c.nome, { s: 16, b: true, max: 200 }) + t(493, yy, pct(c.pct), { s: 22, b: true, a: "end" });
        o += barraFina(189, yy + 9, 300, c.pct / 100, cor(c));
      }
    });
    return svg(W2, H2, o + t(35, 945, "Fonte: TSE", { s: 11, c: C.apagado2 }));
  }
  G["regioes-h"] = function () { return telaRegioes(false, false); };
  G["regioes-v"] = function () { return telaRegioes(false, true); };
  G["regioes1t-h"] = function () { if (!temTurno1()) return svg(1280, 720, marcaVazio() + t(640, 360, "1º turno ainda não guardado", { s: 24, c: C.apagado, a: "middle" })); return telaRegioes(true, false); };
  G["regioes1t-v"] = function () { if (!temTurno1()) return svg(540, 960, marcaVazio() + t(270, 480, "1º turno ainda não guardado", { s: 20, c: C.apagado, a: "middle" })); return telaRegioes(true, true); };

  // ---- PRESIDENTE | ESTADO ou REGIAO (escolhido no gerenciador) ------------
  // alvo: sigla do estado ("sp") ou regiao ("norte"); vem da URL (?a=) ou do
  // rodizio ("presloc:sp").
  var ALVOS_REG = { norte: "Norte", nordeste: "Nordeste", "centro-oeste": "Centro-Oeste", centrooeste: "Centro-Oeste", sudeste: "Sudeste", sul: "Sul" };
  function alvoAtual() {
    var a = String(window.__gctseAlvo || "").toLowerCase();
    if (!a) { try { a = (new URLSearchParams(location.search).get("a") || "").toLowerCase(); } catch (e) { a = ""; } }
    return a || "sp";
  }
  function telaPresLoc(v, t1) {
    if (t1 && !temTurno1()) return marcaVazio() + svg(v ? 540 : 1280, v ? 960 : 720, t(v ? 270 : 640, v ? 480 : 360, "1º turno ainda não guardado", { s: 24, c: C.apagado, a: "middle" }));
    var f = fontePres(!!t1), a = alvoAtual(), reg = ALVOS_REG[a], ufs, nomeA, cs, pu, fim;
    if (reg) { ufs = ufsDaRegiao(reg); nomeA = REG_NOME[reg]; var ag = agregar(f, ufs); cs = ag.cs; pu = ag.pctUrnas; fim = ag.fim; }
    else { ufs = [a]; nomeA = DEP_UF[a] || a.toUpperCase(); var x = f.uf(a); cs = x ? candidatos(x) : []; pu = x && x.secoes ? x.secoes.pct : null; fim = x && x.andamento === "f"; }
    cs = cs.filter(function (c) { return c.votos > 0 || f.turno === 2; });
    var corMapa = function (k) { if (ufs.indexOf(k) < 0) return null; var l = liderF(f, k); return l ? cor(l) : "#3a4c66"; };
    var o, n = f.turno === 2 ? 2 : 6, tit = "PRESIDENTE  |  " + nomeA;
    var sl = fim ? { texto: "TOTALIZAÇÃO FINAL", cor: C.verde } : (pu >= 100 ? { texto: "100% DAS URNAS", cor: C.verde } : (pu > 0 ? { texto: "PARCIAL", cor: C.vermelho } : { texto: "AGUARDANDO APURAÇÃO", cor: C.trilho }));
    if (!v) {
      var W = 1280, H = 720;
      o = t(73, 57, tit, { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, turnoTxt(f) + "  ·  " + (f.guardado ? "resultado final do 1º turno" : "urnas apuradas " + (pu == null ? "—" : pct(pu)) + "  ·  " + subtitulo()), { s: 18, c: C.apagado, max: 640 }) + seloH(W, sl);
      o += barraFina(73, 112, 360, (pu || 0) / 100, "#2fd17a");
      o += mapaCor(60, 150, 0.68, corMapa, { rotulos: true, fonte: 12, soRotulo: function (k) { return ufs.indexOf(k) >= 0; }, apagado: "#1c2a40" });
      var hr = n === 2 ? 150 : 86, gap = n === 2 ? 24 : 8;
      for (var i = 0; i < n; i++) {
        var c = cs[i]; if (!c) continue;
        var y = 130 + i * (hr + gap), x0 = 520, w = 687, cc = cor(c);
        o += r(x0, y, w, hr, "rgba(8,14,32,0.82)", 8) + r(x0, y, 8, hr, cc, 4);
        var fh = hr - 14, fw = fh * 0.75;
        o += fotoOuSilhueta(urlFotoPres(c, f.eleicao), x0 + 18, y + 7, fw, fh);
        var tx = x0 + 32 + fw, k = n === 2 ? 1.3 : 1;
        o += t(tx, y + 26 * k, c.nome + "  |  " + c.partido, { s: Math.round(19 * k), b: true, max: w - (tx - x0) - 200 });
        o += barraFina(tx, y + hr / 2 + 2, w - (tx - x0) - (n === 2 ? 290 : 210), c.pct / 100, cc);
        o += t(tx, y + hr - 14, inteiro(c.votos) + " votos", { s: Math.round(15 * k), c: C.apagado });
        o += t(x0 + w - 20, y + hr / 2 + 16 * k, pct(c.pct), { s: Math.round(36 * k), b: true, a: "end" });
        if (eleitoDe(f, c.numero)) o += etiquetaEleito(x0 + w - 20 - 78, y + 8, 1);
      }
      if (!cs.length) o += marcaVazio() + t(860, 360, "aguardando o boletim do TSE", { s: 22, c: C.apagado, a: "middle" });
      return svg(W, H, o + t(73, 700, "Fonte: TSE" + (reg ? " — soma dos estados da região" : ""), { s: 13, c: C.apagado2 }));
    }
    var W2 = 540, H2 = 960;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 28, b: true, ls: 1, max: 450 }) + t(53, 106, turnoTxt(f) + " · urnas " + (pu == null ? "—" : pct(pu)), { s: 15, c: C.apagado }) + seloV(W2, sl);
    o += mapaCor(140, 168, 0.42, corMapa, { apagado: "#1c2a40", esp: 0.8 });
    var nv = Math.min(n, 4), hv = nv === 2 ? 170 : 108;
    for (var j = 0; j < nv; j++) {
      var cv = cs[j]; if (!cv) continue;
      var yv = 452 + j * (hv + 10), ccv = cor(cv);
      o += r(35, yv, 470, hv, "rgba(8,14,32,0.82)", 8) + r(35, yv, 7, hv, ccv, 3);
      o += fotoOuSilhueta(urlFotoPres(cv, f.eleicao), 50, yv + 8, (hv - 16) * 0.75, hv - 16);
      var txv = 62 + (hv - 16) * 0.75;
      o += t(txv, yv + 30, cv.nome, { s: 19, b: true, max: 493 - txv }) + t(txv, yv + 50, cv.partido, { s: 13, c: C.apagado });
      o += t(493, yv + hv - 16, pct(cv.pct), { s: nv === 2 ? 40 : 30, b: true, a: "end" }) + t(txv, yv + hv - 16, inteiro(cv.votos) + " votos", { s: 13, c: C.apagado });
      if (eleitoDe(f, cv.numero)) o += etiquetaEleito(493 - 78, yv + 8, 1);
    }
    return svg(W2, H2, o + t(35, 945, "Fonte: TSE", { s: 11, c: C.apagado2 }));
  }
  G["presloc-h"] = function () { return telaPresLoc(false); };
  G["presloc-v"] = function () { return telaPresLoc(true); };
  G["presloc1t-h"] = function () { return telaPresLoc(false, true); };
  G["presloc1t-v"] = function () { return telaPresLoc(true, true); };

  // ---- GOVERNADORES: foto por estado + mapa --------------------------------
  // Situacao de cada estado (estados.js; no 2o turno o coletor junta 1o e 2o).
  //  eleito1 (verde): eleito no 1o turno - foto com borda verde
  //  eleito2 (azul): eleito no 2o turno - foto com borda azul
  //  segundo (azul, hachurado): aguardando o 2o turno - sem foto
  //  apurando / vazio (cinza)
  var COR_T1 = "#16b216", COR_T2 = "#2b84ff";
  function govEstado(k) {
    var u = (E().ufs || {})[k], g = u && u.gov && u.gov.tem ? u.gov : null;
    if (!g) return { tipo: "vazio" };
    var cs = comoLista(g.candidatos), el = cs.filter(function (c) { return c.eleito; })[0];
    var turno = +g.turno || (E().turno === 2 ? 2 : 1);
    if (el) return { tipo: turno === 2 ? "eleito2" : "eleito1", c: el, g: g };
    if (turno === 2 || cs.some(function (c) { return c.segundo_turno; })) return { tipo: "segundo", g: g, cs: cs.slice(0, 2) };
    return { tipo: (g.urnas_pct > 0 ? "apurando" : "vazio"), g: g, c: cs[0] };
  }
  function urlFotoGov(k, st) {
    var tse = E().tse;
    if (window.GCTSE_FOTOS_DO_TSE !== true || window.__gctseSemFotos || !tse || !tse.base || !st.c || !st.c.sqcand) return "";
    var url = tse.base + "/" + tse.ciclo + "/" + (st.g.eleicao || tse.eleicao) + "/fotos/" + k + "/" + st.c.sqcand + ".jpeg"; url = viaLocal(url);
    return FOTO_DEP.falhou[url] ? "" : url;
  }
  function corGov(k, modoPartido) {
    var st = govEstado(k);
    if (modoPartido) return (st.tipo === "eleito1" || st.tipo === "eleito2") ? corPartidoCamara(st.c.partido, 0) : (st.tipo === "segundo" ? "#3a4c66" : null);
    return st.tipo === "eleito1" ? COR_T1 : (st.tipo === "eleito2" || st.tipo === "segundo") ? COR_T2 : null;
  }
  // Cartao: sigla em cima, foto, e a barrinha com o nome do eleito embaixo
  // (aguardando: "2º TURNO"). fn = tamanho da letra do nome.
  function cartaoGov(k, x, y, w, h, modoPartido, fn) {
    var st = govEstado(k), borda = corGov(k, modoPartido) || "#3a4c66", o = "", eleito = st.tipo === "eleito1" || st.tipo === "eleito2";
    fn = fn || 10;
    var hl = Math.round(fn * 1.6), hb = Math.round(fn * 2.6);   // sigla e barra do nome
    var asterisco = govAnulados().some(function (z) { return z.k === k; }) ? "*" : "";
    o += r(x, y, w, hl, borda, 3) + t(x + w / 2, y + hl * 0.74, k.toUpperCase() + asterisco, { s: Math.round(fn * 1.15), b: true, a: "middle", ls: 1 });
    var fy = y + hl + 2, fh = h - hl - 2 - hb;
    o += r(x - 2, fy - 2, w + 4, fh + hb + 4, borda, 4);
    if (eleito) o += fotoOuSilhueta(urlFotoGov(k, st), x, fy, w, fh);
    else o += silhueta(x, fy, w, fh);
    if (st.tipo === "segundo") o += '<rect x="' + x + '" y="' + fy + '" width="' + w + '" height="' + fh + '" fill="url(#hach)" opacity="0.35"/>';
    o += r(x, fy + fh, w, hb, "#0b1220", 0);
    if (eleito && st.c) {
      var ln = linhasNome(st.c.nome, Math.max(8, Math.round(w / (fn * 0.62))));
      if (ln.length === 1) o += t(x + w / 2, fy + fh + hb * 0.62, ln[0], { s: fn, b: true, a: "middle", max: w - 4 });
      else ln.forEach(function (l, j) { o += t(x + w / 2, fy + fh + hb * (j ? 0.86 : 0.43), l, { s: Math.round(fn * 0.92), b: true, a: "middle", max: w - 4 }); });
    } else {
      var tx = st.tipo === "segundo" ? "2º TURNO" : (st.tipo === "apurando" ? "APURANDO" : "—");
      o += t(x + w / 2, fy + fh + hb * 0.62, tx, { s: Math.round(fn * 0.9), b: true, c: st.tipo === "segundo" ? "#7fb8ff" : C.apagado, a: "middle", max: w - 4 });
    }
    return o;
  }
  // estados com votos ANULADOS pelo TSE no governador (ex.: RJ, Garotinho)
  function govAnulados() {
    return Object.keys(DEP_UF).map(function (k) {
      var u = (E().ufs || {})[k], an = [];
      [u && u.gov, u && u.gov1t].forEach(function (g) { if (g) comoLista(g.anulados).forEach(function (x) { if (+x.votos > 0 && !an.some(function (y) { return y.nome === x.nome; })) an.push(x); }); });
      return an.length ? { k: k, an: an } : null;
    }).filter(Boolean);
  }
  function notaGovAnulados(curto) {
    var ls = govAnulados(); if (!ls.length) return "";
    return "  ·  * " + ls.map(function (x) { return x.k.toUpperCase() + (curto ? "" : ": votos de " + x.an.map(function (a) { return a.nome; }).join(", ")) + " anulados pelo TSE"; }).join("; ");
  }
  function contaGov() {
    var n = { eleito1: 0, eleito2: 0, segundo: 0, apurando: 0, vazio: 0 };
    Object.keys(DEP_UF).forEach(function (k) { n[govEstado(k).tipo]++; });
    return n;
  }
  function legendaGov(x, y, modoPartido, vertical) {
    var o = "", n = contaGov();
    if (!modoPartido) {
      var itens = [[COR_T1, "ELEITOS NO 1º TURNO", n.eleito1, false], [COR_T2, "ELEITOS NO 2º TURNO", n.eleito2, false], [COR_T2, "AGUARDANDO 2º TURNO", n.segundo, true]];
      if (n.apurando + n.vazio > 0) itens.push(["#3a4c66", "EM APURAÇÃO / SEM DADO", n.apurando + n.vazio, false]);
      itens.forEach(function (it, i) {
        var cw = vertical ? 235 : 255, xx = x + (i % 2) * cw, yy = y + Math.floor(i / 2) * 32;
        o += r(xx, yy - 14, 18, 18, it[0], 3) + (it[3] ? '<rect x="' + xx + '" y="' + (yy - 14) + '" width="18" height="18" fill="url(#hach)"/>' : "");
        o += t(xx + 26, yy, it[1], { s: 12, b: true, c: "#c9d6e6", ls: 1, max: cw - 70 }) + t(xx + cw - 14, yy, String(it[2]), { s: 18, b: true, a: "end" });
      });
      return o;
    }
    var pp = {};
    Object.keys(DEP_UF).forEach(function (k) { var st = govEstado(k); if (st.c && (st.tipo === "eleito1" || st.tipo === "eleito2")) pp[st.c.partido] = (pp[st.c.partido] || 0) + 1; });
    var ls = Object.keys(pp).sort(function (a, b) { return pp[b] - pp[a] || a.localeCompare(b); });
    // partidos + "2o turno" na mesma grade (4 por linha)
    var itensP = ls.map(function (sg, i) { return [corPartidoCamara(sg, i), sg + " " + pp[sg], false]; });
    if (n.segundo) itensP.push(["#3a4c66", "2º TURNO " + n.segundo, true]);
    var porLinha = 4, cwp = vertical ? 117 : 128;
    itensP.forEach(function (it, i) {
      var xx = x + (i % porLinha) * cwp, yy = y + Math.floor(i / porLinha) * 28;
      o += r(xx, yy - 13, 16, 16, it[0], 3) + (it[2] ? '<rect x="' + xx + '" y="' + (yy - 13) + '" width="16" height="16" fill="url(#hach)"/>' : "");
      o += t(xx + 22, yy, it[1], { s: 13, b: true, max: cwp - 28 });
    });
    return o;
  }
  var GRADE_GOV = [["ac", "al", "am", "ap", "ba", "ce", "df"], ["es", "go", "ma", "mg", "ms", "mt", "pa"], ["pb", "pe", "pi", "pr", "rj", "rn", "ro"], ["rr", "rs", "sc", "se", "sp", "to"]];
  function telaGov(v, modoPartido) {
    var n = contaGov(), o;
    var ne = n.eleito1 + n.eleito2, sub = ne + (ne === 1 ? " eleito" : " eleitos") + "  ·  " + (modoPartido ? "cor = partido do eleito; hachurado = 2º turno" : "verde = 1º turno · azul = 2º turno");
    var hachTem = function (k) { return govEstado(k).tipo === "segundo"; };
    var sl = n.segundo + n.apurando + n.vazio === 0 ? { texto: "TODOS DEFINIDOS", cor: C.verde } : { texto: n.segundo ? n.segundo + " NO 2º TURNO" : "PARCIAL", cor: n.segundo ? C.destaque : C.vermelho };
    if (!v) {
      var W = 1280, H = 720;
      o = HACH + t(73, 57, "GOVERNADORES", { s: 36, b: true, ls: 1 }) + t(73, 85, sub, { s: 18, c: C.apagado, max: 640 }) + seloH(W, sl);
      var cw = 74, ch = 126, gx = 10, gy = 8;
      GRADE_GOV.forEach(function (lin, li) {
        var x0 = 70 + (li === 3 ? (cw + gx) / 2 : 0);
        lin.forEach(function (k, ci) { o += cartaoGov(k, x0 + ci * (cw + gx), 110 + li * (ch + gy), cw, ch, modoPartido, 10); });
      });
      o += mapaCor(700, 112, 0.74, function (k) { return corGov(k, modoPartido); }, { rotulos: true, fonte: 12, apagado: "#22324a", hachura: hachTem });
      o += legendaGov(700, 626, modoPartido, false);
      return svg(W, H, o + t(73, 700, "Fonte: TSE — situação de cada candidato a Governador" + (E().turno === 2 ? " (1º e 2º turno)" : "") + notaGovAnulados(false), { s: 13, c: C.apagado2, max: 1134 }));
    }
    var W2 = 540, H2 = 960;
    o = HACH + r(35, 48, 6, 38, C.destaque) + t(53, 80, "GOVERNADORES", { s: 32, b: true, ls: 1 }) + t(53, 106, sub, { s: 13, c: C.apagado, max: 450 }) + seloV(W2, sl);
    o += mapaCor(126, 158, 0.47, function (k) { return corGov(k, modoPartido); }, { rotulos: true, fonte: 9, apagado: "#22324a", hachura: hachTem });
    var cw2 = 60, ch2 = 92, gx2 = 7, todos = [].concat.apply([], GRADE_GOV);
    todos.forEach(function (k, i) {
      var li = Math.floor(i / 7), ci = i % 7, x0 = 36 + (li === 3 ? (cw2 + gx2) / 2 : 0);
      o += cartaoGov(k, x0 + ci * (cw2 + gx2), 470 + li * (ch2 + 6), cw2, ch2, modoPartido, 8);
    });
    return svg(W2, H2, o + legendaGov(36, 888, modoPartido, true) + (govAnulados().length ? t(36, 950, "Fonte: TSE" + notaGovAnulados(true), { s: 10, c: C.apagado2, max: 470 }) : ""));
  }
  G["governadores-h"] = function () { return telaGov(false, false); };
  G["governadores-v"] = function () { return telaGov(true, false); };
  G["govpartido-h"] = function () { return telaGov(false, true); };
  G["govpartido-v"] = function () { return telaGov(true, true); };

  // ---- 1o x 2o TURNO: abstencao, brancos, nulos, comparecimento ------------
  function numsTurno(b) {
    if (!b || !b.tem) return null;
    var e = b.eleitorado || {}, v = b.votos || {};
    return { abst: e.pct_abstencao, comp: e.pct_comparec, brancos: v.pct_brancos, nulos: v.pct_nulos,
      nAbst: e.abstencao, nComp: e.comparecimento, nBr: v.brancos, nNu: v.nulos, urnas: b.secoes ? b.secoes.pct : null };
  }
  function telaTurnos(v) {
    var d = D(), t1 = d.turno1 && d.turno1.br && d.turno1.br.tem ? numsTurno(d.turno1.br) : null, f = fontePres(false);
    var t2 = f.turno === 2 ? numsTurno(f.br) : null, o;
    var itens = [["COMPARECIMENTO", "comp", "nComp", "eleitores votaram"], ["ABSTENÇÃO", "abst", "nAbst", "eleitores não votaram"],
      ["BRANCOS", "brancos", "nBr", "votos em branco"], ["NULOS", "nulos", "nNu", "votos nulos"]];
    var tit = "1º × 2º TURNO", sub = "Presidente · Brasil · " + (t2 ? "2º turno: " + (t2.urnas != null ? "urnas " + pct(t2.urnas) : "aguardando") : "o 2º turno ainda não começou");
    var cor1 = "#7398cf", cor2 = "#2fd17a";
    function dif(a, b) { if (a == null || b == null) return ""; var dd = b - a; return (dd > 0 ? "+" : dd < 0 ? "−" : "") + Math.abs(dd).toFixed(2).replace(".", ",") + " p.p."; }
    if (!t1) {
      var Wx = v ? 540 : 1280, Hx = v ? 960 : 720;
      return svg(Wx, Hx, marcaVazio() + t(v ? 53 : 73, v ? 80 : 57, tit, { s: v ? 32 : 36, b: true, ls: 1 }) +
        t(Wx / 2, Hx / 2, "disponível no 2º turno (o 1º turno é guardado pelo GRAFICOS.bat)", { s: v ? 15 : 22, c: C.apagado, a: "middle", max: Wx - 60 }));
    }
    if (!v) {
      var W = 1280, H = 720;
      o = t(73, 57, tit, { s: 36, b: true, ls: 1 }) + t(73, 85, sub, { s: 18, c: C.apagado, max: 640 }) + seloH(W, seloDe(f));
      o += r(760, 108, 14, 14, cor1, 2) + t(780, 120, "1º TURNO (final)", { s: 14, b: true, c: "#c9d6e6" }) + r(960, 108, 14, 14, cor2, 2) + t(980, 120, "2º TURNO", { s: 14, b: true, c: "#c9d6e6" });
      itens.forEach(function (it, i) {
        var y = 150 + i * 132, a = t1[it[1]], b2 = t2 ? t2[it[1]] : null, max = it[1] === "comp" ? 100 : Math.max(10, (a || 0) * 1.3, (b2 || 0) * 1.3);
        o += r(73, y, 1134, 116, "rgba(8,14,32,0.78)", 10) + t(100, y + 40, it[0], { s: 24, b: true, ls: 1 });
        var dd = dif(a, b2); if (dd) o += t(100, y + 76, dd, { s: 22, b: true, c: "#ffd43b" }) + t(100, y + 98, "do 1º para o 2º turno", { s: 12, c: C.apagado });
        [[a, cor1, "1º", t1[it[2]]], [b2, cor2, "2º", t2 ? t2[it[2]] : null]].forEach(function (z, j) {
          var yy = y + 26 + j * 46;
          o += t(400, yy + 20, z[2], { s: 16, b: true, c: C.apagado });
          o += r(430, yy, 560, 28, "rgba(255,255,255,0.08)", 6) + (z[0] > 0 ? r(430, yy, Math.max(8, 560 * z[0] / max), 28, z[1], 6) : "");
          o += t(1180, yy + 22, z[0] == null ? "—" : pct(z[0]), { s: 24, b: true, a: "end" });
          if (z[3] != null) o += t(1180, yy + 40, inteiro(z[3]) + " " + it[3], { s: 11, c: C.apagado, a: "end" });
        });
      });
      return svg(W, H, o + t(73, 700, "Fonte: TSE · comparecimento e abstenção sobre o eleitorado; brancos e nulos sobre os votos · 2º turno parcial até o fim", { s: 13, c: C.apagado2, max: 1134 }));
    }
    var W2 = 540, H2 = 960;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 32, b: true, ls: 1 }) + t(53, 106, sub, { s: 13, c: C.apagado, max: 450 }) + seloV(W2, seloDe(f));
    itens.forEach(function (it, i) {
      var y = 172 + i * 190, a = t1[it[1]], b2 = t2 ? t2[it[1]] : null, max = it[1] === "comp" ? 100 : Math.max(10, (a || 0) * 1.3, (b2 || 0) * 1.3);
      o += r(35, y, 470, 176, "rgba(8,14,32,0.78)", 10) + t(55, y + 36, it[0], { s: 22, b: true, ls: 1 });
      var dd = dif(a, b2); if (dd) o += t(485, y + 36, dd, { s: 18, b: true, c: "#ffd43b", a: "end" });
      [[a, cor1, "1º TURNO"], [b2, cor2, "2º TURNO"]].forEach(function (z, j) {
        var yy = y + 62 + j * 56;
        o += t(55, yy + 14, z[2], { s: 12, b: true, c: C.apagado, ls: 1 });
        o += r(55, yy + 22, 300, 22, "rgba(255,255,255,0.08)", 5) + (z[0] > 0 ? r(55, yy + 22, Math.max(6, 300 * z[0] / max), 22, z[1], 5) : "");
        o += t(485, yy + 40, z[0] == null ? "—" : pct(z[0]), { s: 24, b: true, a: "end" });
      });
    });
    return svg(W2, H2, o + t(35, 945, "Fonte: TSE · Presidente, Brasil", { s: 11, c: C.apagado2 }));
  }
  G["turnos-h"] = function () { return telaTurnos(false); };
  G["turnos-v"] = function () { return telaTurnos(true); };

  // ---- CAMARA: BANCADA FEMININA ---------------------------------------------
  // Genero: arquivo "Candidatos" do TSE (Dados Abertos), importado pelo
  // IMPORTAR-CANDIDATOS.bat (web\candidatos-genero.js). Eleitas de 2026 =
  // eleitos do boletim do TSE (estados.js) cujo sqcand e de mulher; sem o
  // boletim, a situacao do proprio arquivo de candidatos.
  var COR_MULHER = "#a678f0";
  function bancadaFem() {
    var gen = window.GCTSE_GENERO, cm = (E().camara || {});
    if (!gen || !gen.anos) return null;
    var a26 = gen.anos["2026"], a22 = gen.anos["2022"], r = { a22: a22, a26: a26, fonte: gen.fonte, quando: gen.gerado_em };
    if (!a26) return r;
    var fem = {}; comoLista(a26.mulheres).forEach(function (q) { fem[q] = 1; });
    var tot = 0, el = 0, pp = {}, ufs = 0;
    Object.keys(cm).forEach(function (u) {
      var l = comoLista(cm[u].lista); if (!l.length) return; ufs++;
      l.forEach(function (c) { tot++; if (fem[c.sqcand]) { el++; pp[c.partido] = (pp[c.partido] || 0) + 1; } });
    });
    if (tot > 0) { r.eleitas = el; r.eleitos = tot; r.partidos = pp; r.aoVivo = true; r.ufs = ufs; }
    else { r.eleitas = +a26.eleitas || 0; r.eleitos = +a26.eleitos || 513; r.partidos = a26.eleitas_por_partido || {}; r.aoVivo = false; }
    return r;
  }
  function meiaLua(cx, cy, raio, esp, frac, cor) {
    var L = Math.PI * raio, d = "M" + (cx - raio) + " " + cy + " A" + raio + " " + raio + " 0 0 1 " + (cx + raio) + " " + cy;
    return '<path d="' + d + '" fill="none" stroke="rgba(255,255,255,0.12)" stroke-width="' + esp + '"/>' +
      (frac > 0 ? '<path d="' + d + '" fill="none" stroke="' + cor + '" stroke-width="' + esp + '" stroke-dasharray="' + (L * Math.min(1, frac)).toFixed(1) + " " + L.toFixed(1) + '"/>' : "");
  }
  function pct1(v) { return Number(v).toFixed(1).replace(".", ",") + "%"; }
  function sinal(v, txt) { return (v > 0 ? "▲ +" : v < 0 ? "▼ −" : "") + txt; }
  function blocoAno(x, y, ano, n, total, destaque, k) {
    var o = t(x, y, ano, { s: Math.round(20 * k), b: true, c: destaque ? C.texto : C.apagado, a: "middle", ls: 2 });
    o += meiaLua(x, y + 150 * k, 96 * k, 26 * k, total ? n / total : 0, destaque ? COR_MULHER : "#7f6aa8");
    o += t(x, y + 128 * k, String(n), { s: Math.round(54 * k), b: true, a: "middle" });
    o += t(x, y + 152 * k, "deputadas", { s: Math.round(15 * k), c: C.apagado, a: "middle" });
    o += t(x, y + 196 * k, total ? pct1(100 * n / total) : "—", { s: Math.round(30 * k), b: true, c: destaque ? COR_MULHER : "#b9a8d8", a: "middle" });
    o += t(x, y + 218 * k, "das " + total + " cadeiras", { s: Math.round(13 * k), c: C.apagado, a: "middle" });
    return o;
  }
  function barrasPartidosFem(x, y, w, passo, pp, n, k) {
    var ls = Object.keys(pp || {}).sort(function (a, b) { return pp[b] - pp[a] || a.localeCompare(b); }).slice(0, n), o = "";
    if (!ls.length) return t(x, y + 20, "sem eleitas ainda", { s: 16, c: C.apagado });
    var max = pp[ls[0]];
    ls.forEach(function (sg, i) {
      var yy = y + i * passo;
      o += t(x, yy + 20 * k, sg, { s: Math.round(18 * k), b: true, max: 140 * k });
      o += r(x + 150 * k, yy + 2 * k, w - 150 * k - 50 * k, 24 * k, "rgba(255,255,255,0.10)", 4) +
        r(x + 150 * k, yy + 2 * k, Math.max(6, (w - 200 * k) * pp[sg] / max), 24 * k, corPartidoCamara(sg, i), 4);
      o += t(x + w, yy + 21 * k, String(pp[sg]), { s: Math.round(20 * k), b: true, a: "end" });
    });
    return o;
  }
  function telaFem(v) {
    var bf = bancadaFem(), W = v ? 540 : 1280, H = v ? 960 : 720, o;
    var semDado = !bf || !bf.a26;
    var tit = "CÂMARA: BANCADA FEMININA";
    if (semDado) {
      o = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 26, b: true, ls: 1, max: 450 }) : t(73, 57, tit, { s: 36, b: true, ls: 1 });
      return svg(W, H, marcaVazio() + o + t(W / 2, H / 2 - 10, "falta o arquivo de candidatos do TSE", { s: v ? 18 : 24, c: C.apagado, a: "middle" }) +
        t(W / 2, H / 2 + 22, "rode o IMPORTAR-CANDIDATOS.bat (consulta_cand_2026.zip, Dados Abertos)", { s: v ? 12 : 16, c: C.apagado2, a: "middle", max: W - 60 }));
    }
    var a22 = bf.a22, n26 = bf.eleitas, tot = bf.eleitos || 513, n22 = a22 ? +a22.eleitas : null;
    var sub = n26 + " deputadas eleitas  ·  " + pct1(100 * n26 / tot) + " das " + tot + " cadeiras" + (n22 != null ? "  ·  em 2022 foram " + n22 : "");
    var cand26 = +bf.a26.aptas_mulheres || +bf.a26.candidaturas_mulheres, tot26 = +bf.a26.aptas || +bf.a26.candidaturas;
    var cand22 = a22 ? (+a22.aptas_mulheres || +a22.candidaturas_mulheres) : null;
    var rod = "Fonte: TSE — gênero: Dados Abertos (Candidatos); eleitas: " + (bf.aoVivo ? "boletim de resultados" + (bf.ufs < 27 ? " (" + bf.ufs + " de 27 estados)" : "") : "arquivo de candidatos") + "; candidaturas aptas a Deputado Federal";
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, sub, { s: 18, c: C.apagado, max: 640 });
      o += r(73, 110, 560, 410, "rgba(8,14,32,0.80)", 10) + t(93, 142, "BANCADA FEMININA NA CÂMARA", { s: 16, b: true, c: "#c9d6e6", ls: 1 });
      if (n22 != null) o += blocoAno(213, 186, "2022", n22, 513, false, 1);
      o += blocoAno(n22 != null ? 493 : 353, 186, "2026", n26, tot, true, 1);
      if (n22 != null) {
        var dC = n26 - n22, dP = n22 ? 100 * (n26 - n22) / n22 : 0;
        o += r(93, 440, 250, 60, "rgba(255,255,255,0.06)", 8) + r(363, 440, 250, 60, "rgba(255,255,255,0.06)", 8);
        o += t(218, 470, sinal(dC, Math.abs(dC) + (Math.abs(dC) === 1 ? " cadeira" : " cadeiras")), { s: 20, b: true, c: dC >= 0 ? "#69db7c" : "#ff8787", a: "middle" }) + t(218, 490, "em relação a 2022", { s: 12, c: C.apagado, a: "middle" });
        o += t(488, 470, sinal(dP, pct1(Math.abs(dP))), { s: 20, b: true, c: dP >= 0 ? "#69db7c" : "#ff8787", a: "middle" }) + t(488, 490, "de deputadas a mais que em 2022".replace("a mais", dP >= 0 ? "a mais" : "a menos"), { s: 12, c: C.apagado, a: "middle" });
      }
      o += r(653, 110, 554, 410, "rgba(8,14,32,0.80)", 10) + t(673, 142, "PARTIDOS COM MAIS MULHERES ELEITAS", { s: 16, b: true, c: "#c9d6e6", ls: 1 });
      o += barrasPartidosFem(673, 170, 514, 56, bf.partidos, 6, 1);
      o += r(73, 536, 1134, 136, "rgba(8,14,32,0.80)", 10);
      o += t(100, 600, inteiro(cand26), { s: 48, b: true }) + t(100, 630, "mulheres candidatas a Deputado Federal em 2026", { s: 15, c: C.apagado }) + t(100, 650, "(candidaturas aptas)", { s: 12, c: C.apagado2 });
      if (cand22) {
        var dCand = 100 * (cand26 - cand22) / cand22;
        o += t(560, 600, sinal(dCand, pct1(Math.abs(dCand))), { s: 36, b: true, c: dCand >= 0 ? "#69db7c" : "#ff8787" }) + t(560, 630, "em relação a 2022 (" + inteiro(cand22) + " candidatas)", { s: 15, c: C.apagado });
      }
      var fc = tot26 ? cand26 / tot26 : 0;
      o += rosca(1125, 604, 46, 14, [{ v: fc, c: COR_MULHER }, { v: 1 - fc, c: "rgba(255,255,255,0.12)" }]) + t(1125, 611, pct1(100 * fc).replace(",0%", "%"), { s: 18, b: true, a: "middle" });
      o += t(1060, 600, "das candidaturas", { s: 14, c: C.apagado, a: "end" }) + t(1060, 620, "a deputado federal", { s: 14, c: C.apagado, a: "end" }) + t(1060, 640, "eram de mulheres", { s: 14, c: C.apagado, a: "end" });
      return svg(W, H, o + t(73, 700, rod, { s: 12, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "BANCADA FEMININA", { s: 30, b: true, ls: 1, max: 450 }) + t(53, 106, "Câmara dos Deputados · " + n26 + " eleitas", { s: 15, c: C.apagado, max: 450 });
    o += r(35, 130, 470, 300, "rgba(8,14,32,0.80)", 10);
    if (n22 != null) o += blocoAno(150, 160, "2022", n22, 513, false, 0.95);
    o += blocoAno(n22 != null ? 390 : 270, 160, "2026", n26, tot, true, 0.95);
    if (n22 != null) {
      var dC2 = n26 - n22, dP2 = n22 ? 100 * (n26 - n22) / n22 : 0;
      o += t(150, 412, sinal(dC2, Math.abs(dC2) + " cadeiras"), { s: 18, b: true, c: dC2 >= 0 ? "#69db7c" : "#ff8787", a: "middle" });
      o += t(390, 412, sinal(dP2, pct1(Math.abs(dP2))) + " vs 2022", { s: 18, b: true, c: dP2 >= 0 ? "#69db7c" : "#ff8787", a: "middle" });
    }
    o += r(35, 446, 470, 330, "rgba(8,14,32,0.80)", 10) + t(55, 476, "PARTIDOS COM MAIS ELEITAS", { s: 15, b: true, c: "#c9d6e6", ls: 1 });
    o += barrasPartidosFem(55, 494, 430, 46, bf.partidos, 6, 0.9);
    o += r(35, 792, 470, 132, "rgba(8,14,32,0.80)", 10);
    o += t(55, 842, inteiro(cand26), { s: 38, b: true }) + t(55, 866, "candidatas a Dep. Federal em 2026", { s: 13, c: C.apagado });
    var fc2 = tot26 ? cand26 / tot26 : 0;
    if (cand22) { var dc2 = 100 * (cand26 - cand22) / cand22; o += t(55, 900, sinal(dc2, pct1(Math.abs(dc2))) + " vs 2022 (" + inteiro(cand22) + ")", { s: 15, b: true, c: dc2 >= 0 ? "#69db7c" : "#ff8787" }); }
    o += rosca(440, 852, 40, 12, [{ v: fc2, c: COR_MULHER }, { v: 1 - fc2, c: "rgba(255,255,255,0.12)" }]) + t(440, 859, pct1(100 * fc2).replace(",0%", "%"), { s: 15, b: true, a: "middle" });
    o += t(440, 910, "das candidaturas", { s: 11, c: C.apagado, a: "middle" });
    return svg(W, H, o + t(35, 948, "Fonte: TSE — Dados Abertos (Candidatos) e boletim de resultados", { s: 11, c: C.apagado2, max: 470 }));
  }
  G["mulheres-h"] = function () { return telaFem(false); };
  G["mulheres-v"] = function () { return telaFem(true); };

  // ---- PERFIL DA NOVA CAMARA: renovacao, idade, escolaridade, cor/raca ------
  // Atributos de cada candidato: arquivo "Candidatos" do TSE (Dados Abertos),
  // importado pelo IMPORTAR-CANDIDATOS.bat (web\candidatos-genero.js, campo
  // perfil = [idade na posse, instrucao, cor/raca, disputava reeleicao]).
  // Eleitos de 2026 = boletim do TSE ao vivo (estados.js), cruzados pelo
  // sqcand. Ano anterior = eleitos daquele arquivo.
  var FAIXAS_IDADE = [[0, 34, "até 34"], [35, 44, "35–44"], [45, 54, "45–54"], [55, 64, "55–64"], [65, 200, "65 ou mais"]];
  var COR_PERFIL = "#2b84ff";
  function somaPerfil(lista) {
    var a = { n: 0, idN: 0, idS: 0, faixa: [0, 0, 0, 0, 0], grau: {}, grauN: 0, cor: {}, corN: 0, re: 0, novo: 0, reN: 0 };
    lista.forEach(function (p) {
      p = comoLista(p); if (p.length < 4) return;
      a.n++;
      var id = +p[0];
      if (id >= 18) { a.idN++; a.idS += id; for (var i = 0; i < FAIXAS_IDADE.length; i++) if (id >= FAIXAS_IDADE[i][0] && id <= FAIXAS_IDADE[i][1]) { a.faixa[i]++; break; } }
      if (+p[1] >= 0) { a.grau[p[1]] = (a.grau[p[1]] || 0) + 1; a.grauN++; }
      if (+p[2] >= 0) { a.cor[p[2]] = (a.cor[p[2]] || 0) + 1; a.corN++; }
      if (+p[3] === 1) { a.re++; a.reN++; } else if (+p[3] === 0) { a.novo++; a.reN++; }
    });
    return a;
  }
  function perfilCamara() {
    var gen = window.GCTSE_GENERO;
    if (!gen || !gen.anos) return null;
    var anos = Object.keys(gen.anos).sort(), aN = anos[anos.length - 1], aA = anos.length > 1 ? anos[anos.length - 2] : null;
    var pN = gen.anos[aN].perfil;
    if (!pN) return { semPerfil: true };
    var cm = E().camara || {}, ps = [], tot = 0, ufs = 0;
    Object.keys(cm).forEach(function (u) {
      var l = comoLista(cm[u].lista); if (!l.length) return; ufs++;
      l.forEach(function (c) { tot++; var p = pN[String(c.sqcand)]; if (p) ps.push(p); });
    });
    var pA = aA && gen.anos[aA].perfil ? gen.anos[aA].perfil : null;
    return { ano: aN, anoA: pA ? aA : null, eleitos: tot, ufs: ufs, achados: ps.length, n: somaPerfil(ps),
      a: pA ? somaPerfil(Object.keys(pA).map(function (k) { return pA[k]; })) : null,
      rg: comoLista(gen.rotulos_grau), rc: comoLista(gen.rotulos_cor) };
  }
  function rotuloPerfil(s) {
    s = String(s || "").toLowerCase().replace(/^ensino /, "").replace("não divulgável", "não divulgada");
    return s.charAt(0).toUpperCase() + s.slice(1);
  }
  // barra 2026 + traco branco na posicao do ano anterior
  function barraPerfil(x, y, w, h, f, fA) {
    var o = r(x, y, w, h, "rgba(255,255,255,0.10)", 3) + (f > 0 ? r(x, y, Math.max(4, w * Math.min(1, f)), h, COR_PERFIL, 3) : "");
    if (fA != null) o += r(x + w * Math.min(1, fA) - 1.5, y - 4, 3, h + 8, "#ffffff", 0);
    return o;
  }
  function pctDe(n, d) { return d ? 100 * n / d : 0; }
  function categorias(cont, tot, contA, totA, rot, max) {
    var ks = Object.keys(cont).sort(function (a, b) { return cont[b] - cont[a]; });
    if (contA) Object.keys(contA).forEach(function (k) { if (ks.indexOf(k) < 0) ks.push(k); });
    return ks.slice(0, max).map(function (k) { return { nome: rotuloPerfil(rot[+k]), f: tot ? (cont[k] || 0) / tot : 0, fA: contA && totA ? (contA[k] || 0) / totA : null }; });
  }
  function painelPerfil(x, y, w, h, titulo) { return r(x, y, w, h, "rgba(8,14,32,0.84)", 10) + t(x + 18, y + 28, titulo, { s: 14, b: true, c: "#c9d6e6", ls: 1 }); }
  function linhasPerfil(x, y, w, passo, itens, fs) {
    var o = "";
    itens.forEach(function (it, i) {
      var yy = y + i * passo;
      o += t(x, yy, it.nome, { s: fs, b: true, max: w * 0.42 }) + t(x + w, yy, pct1(100 * it.f), { s: fs + 2, b: true, a: "end" });
      o += barraPerfil(x + w * 0.44, yy - fs * 0.75, w * 0.40, fs * 0.8, it.f, it.fA);
    });
    return o;
  }
  function telaPerfil(v) {
    var P = perfilCamara(), W = v ? 540 : 1280, H = v ? 960 : 720, o, tit = "PERFIL DA NOVA CÂMARA";
    var cab = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 26, b: true, ls: 1, max: 450 }) : t(73, 57, tit, { s: 36, b: true, ls: 1, max: 660 });
    if (!P || P.semPerfil) return svg(W, H, marcaVazio() + cab + t(W / 2, H / 2 - 10, "falta o arquivo de candidatos do TSE", { s: v ? 18 : 24, c: C.apagado, a: "middle" }) +
      t(W / 2, H / 2 + 22, "rode o IMPORTAR-CANDIDATOS.bat (consulta_cand_" + (P ? "" : "2026") + "…, Dados Abertos)", { s: v ? 12 : 16, c: C.apagado2, a: "middle", max: W - 60 }));
    if (!P.achados) return svg(W, H, marcaVazio() + cab + t(W / 2, H / 2, P.eleitos ? "os eleitos do boletim não estão no arquivo de candidatos importado" : "aguardando os deputados eleitos (ESTADOS.bat)", { s: v ? 16 : 22, c: C.apagado, a: "middle", max: W - 60 }));
    var n = P.n, a = P.a, sub = P.eleitos + " deputados federais eleitos" + (P.ufs < 27 ? " (" + P.ufs + " de 27 estados)" : "") + (P.anoA ? " · traço branco = eleitos de " + P.anoA : "");
    var media = n.idN ? n.idS / n.idN : null, mediaA = a && a.idN ? a.idS / a.idN : null;
    var fRe = pctDe(n.re, n.reN), fReA = a && a.reN ? pctDe(a.re, a.reN) : null, temRe = n.reN > 0;
    // criterio de "reeleito": do arquivo do TSE ou, sem ele, "eleito em 2022 pelo mesmo estado"
    var critRe = String((window.GCTSE_GENERO || {}).reeleicao_criterio || ""), anoCrit = (/eleito_em_(\d{4})/.exec(critRe) || [])[1];
    var txtRe = anoCrit ? "reeleito = eleito deputado federal em " + anoCrit + " pelo mesmo estado · novo = não eleito em " + anoCrit : "reeleito = disputava a reeleição · novo = sem mandato atual";
    var sup = 0, supA = 0;
    P.rg.forEach(function (rot, i) { if (/^SUPERIOR COMPLETO/.test(rot)) { sup += n.grau[i] || 0; if (a) supA += a.grau[i] || 0; } });
    var graus = categorias(n.grau, n.grauN, a ? a.grau : null, a ? a.grauN : 0, P.rg, 4);
    var cores = categorias(n.cor, n.corN, a ? a.cor : null, a ? a.corN : 0, P.rc, 6);
    var faixas = FAIXAS_IDADE.map(function (fx, i) { return { nome: fx[2], f: n.idN ? n.faixa[i] / n.idN : 0, fA: a && a.idN ? a.faixa[i] / a.idN : null }; });
    var rod = "Fonte: TSE — Dados Abertos (Candidatos: idade na posse, grau de instrução, cor/raça, reeleição) e boletim de resultados. Perfil de " + P.achados + " de " + P.eleitos + " eleitos.";
    function comp(atual, ant, suf) { if (ant == null) return ""; var d = atual - ant; return P.anoA + ": " + pct1(ant).replace("%", suf || "%") + (Math.abs(d) >= 0.05 ? "  (" + (d > 0 ? "+" : "−") + Number(Math.abs(d)).toFixed(1).replace(".", ",") + " p.p.)" : ""); }
    if (!v) {
      o = cab + t(73, 85, sub, { s: 16, c: C.apagado, max: 660 }) + seloH(W, { texto: P.ufs >= 27 ? "513 CADEIRAS" : "PARCIAL", cor: P.ufs >= 27 ? C.verde : C.vermelho });
      // renovacao
      o += painelPerfil(73, 106, 556, 262, "RENOVAÇÃO");
      if (!temRe) o += t(351, 230, "o arquivo do TSE não informa reeleição", { s: 18, c: C.apagado, a: "middle", max: 516 });
      else {
        o += t(93, 190, String(n.re), { s: 54, b: true }) + t(93, 216, "reeleitos · " + pct1(fRe), { s: 16, c: "#c9d6e6" });
        o += t(609, 190, String(n.novo), { s: 54, b: true, a: "end", c: COR_PERFIL }) + t(609, 216, "novos · " + pct1(100 - fRe), { s: 16, c: "#c9d6e6", a: "end" });
        o += r(93, 238, 516, 26, COR_PERFIL, 4) + r(93, 238, 516 * fRe / 100, 26, "#c9d6e6", 4);
        if (fReA != null) o += r(93 + 516 * fReA / 100 - 1.5, 232, 3, 38, "#ffffff", 0);
        o += t(93, 300, comp(fRe, fReA) ? "reeleitos em " + comp(fRe, fReA) : "", { s: 14, c: C.apagado, max: 516 });
        o += t(93, 346, anoCrit ? "reeleito = eleito deputado federal em " + anoCrit + " pelo mesmo estado" : txtRe, { s: 12, c: C.apagado2, max: 516 });
      }
      // idade
      o += painelPerfil(651, 106, 556, 262, "IDADE NA POSSE");
      o += t(671, 180, media ? Number(media).toFixed(1).replace(".", ",") : "—", { s: 44, b: true }) + t(671, 202, "anos, em média" + (mediaA ? " · " + P.anoA + ": " + Number(mediaA).toFixed(1).replace(".", ",") : ""), { s: 13, c: C.apagado });
      o += linhasPerfil(671, 238, 516, 27, faixas, 14);
      // escolaridade
      o += painelPerfil(73, 384, 556, 288, "ESCOLARIDADE");
      o += t(93, 460, pct1(pctDe(sup, n.grauN)), { s: 44, b: true }) + t(93, 482, "com superior completo" + (a ? " · " + P.anoA + ": " + pct1(pctDe(supA, a.grauN)) : ""), { s: 13, c: C.apagado });
      o += linhasPerfil(93, 524, 516, 38, graus, 15);
      // cor/raca
      o += painelPerfil(651, 384, 556, 288, "COR / RAÇA (autodeclarada)");
      o += linhasPerfil(671, 450, 516, 36, cores, 15);
      return svg(W, H, o + t(73, 696, rod, { s: 10, c: C.apagado2, max: 1134 }) + t(73, 710, "▮ " + P.ano + "  ·  traço branco = " + (P.anoA || "—"), { s: 10, c: C.apagado2 }));
    }
    o = cab + t(53, 106, P.eleitos + " eleitos" + (P.anoA ? " · traço = " + P.anoA : ""), { s: 13, c: C.apagado, max: 450 }) + seloV(W, { texto: P.ufs >= 27 ? "513 CADEIRAS" : "PARCIAL", cor: P.ufs >= 27 ? C.verde : C.vermelho });
    o += painelPerfil(35, 160, 470, 170, "RENOVAÇÃO");
    if (!temRe) o += t(270, 250, "o arquivo do TSE não informa reeleição", { s: 14, c: C.apagado, a: "middle", max: 430 });
    else {
      o += t(55, 232, String(n.re), { s: 40, b: true }) + t(55, 254, "reeleitos · " + pct1(fRe), { s: 13, c: "#c9d6e6" });
      o += t(485, 232, String(n.novo), { s: 40, b: true, a: "end", c: COR_PERFIL }) + t(485, 254, "novos · " + pct1(100 - fRe), { s: 13, c: "#c9d6e6", a: "end" });
      o += r(55, 272, 430, 20, COR_PERFIL, 4) + r(55, 272, 430 * fRe / 100, 20, "#c9d6e6", 4);
      if (fReA != null) o += r(55 + 430 * fReA / 100 - 1.5, 267, 3, 30, "#ffffff", 0);
      o += t(55, 318, comp(fRe, fReA) ? "reeleitos em " + comp(fRe, fReA) : (anoCrit ? "reeleito = eleito em " + anoCrit + " pelo mesmo estado" : ""), { s: 12, c: C.apagado, max: 430 });
    }
    o += painelPerfil(35, 342, 470, 210, "IDADE NA POSSE");
    o += t(55, 406, media ? Number(media).toFixed(1).replace(".", ",") + " anos" : "—", { s: 30, b: true }) + t(485, 406, mediaA ? P.anoA + ": " + Number(mediaA).toFixed(1).replace(".", ",") : "", { s: 13, c: C.apagado, a: "end" });
    o += linhasPerfil(55, 440, 430, 24, faixas, 13);
    o += painelPerfil(35, 564, 470, 180, "ESCOLARIDADE");
    o += t(55, 628, pct1(pctDe(sup, n.grauN)), { s: 30, b: true }) + t(175, 628, "com superior completo", { s: 13, c: C.apagado });
    o += linhasPerfil(55, 660, 430, 22, graus, 13);
    o += painelPerfil(35, 756, 470, 180, "COR / RAÇA");
    o += linhasPerfil(55, 810, 430, 23, cores, 12);
    return svg(W, H, o + t(35, 950, "Fonte: TSE — Dados Abertos (Candidatos) e boletim", { s: 10, c: C.apagado2 }));
  }
  G["perfilcamara-h"] = function () { return telaPerfil(false); };
  G["perfilcamara-v"] = function () { return telaPerfil(true); };

  // ---- SENADORES ELEITOS: 2 por estado, foto + nome + partido, mapa em blocos
  // Boletim de Senador do TSE (estados.js, cargo 5; no 2o turno, o do 1o).
  // Eleito = situacao do TSE (ou a conta matematica do coletor).
  function senEstado(k) {
    var u = (E().ufs || {})[k], sg = u && u.sen && u.sen.tem ? u.sen : null;
    if (!sg) return { tem: false, el: [] };
    var cs = comoLista(sg.candidatos), el = cs.filter(function (c) { return c.eleito; })
      .sort(function (a, b) { return (+b.votos || 0) - (+a.votos || 0); });
    return { tem: true, el: el, vagas: Math.max(+sg.vagas || 0, 2), urnas: sg.urnas_pct };
  }
  function urlFotoSen(k, c) {
    var tse = E().tse;
    if (window.GCTSE_FOTOS_DO_TSE !== true || window.__gctseSemFotos || !tse || !tse.base || !c || !c.sqcand) return "";
    var url = tse.base + "/" + tse.ciclo + "/" + (tse.eleicao_1turno || tse.eleicao) + "/fotos/" + k + "/" + c.sqcand + ".jpeg"; url = viaLocal(url);
    return FOTO_DEP.falhou[url] ? "" : url;
  }
  // Mapa em blocos (cada estado um quadrado na posicao aproximada).
  var BLOCOS_UF = { rr: [1, 0], ap: [2, 0], am: [1, 1], pa: [2, 1], ma: [3, 1], ce: [4, 1], rn: [5, 1],
    ac: [0, 2], ro: [1, 2], mt: [2, 2], to: [3, 2], pi: [4, 2], pb: [5, 2], ms: [2, 3], go: [3, 3], ba: [4, 3], pe: [5, 3],
    sp: [2, 4], df: [3, 4], mg: [4, 4], al: [5, 4], pr: [2, 5], rj: [3, 5], es: [4, 5], se: [5, 5], sc: [2, 6], rs: [2, 7] };
  var COR_VAZIO_SEN = "#2a3a55";
  function coresSen(k) {
    var st = senEstado(k), c = st.el.map(function (x, i) { return corPartidoCamara(x.partido, i); });
    if (!c.length) return [COR_VAZIO_SEN, COR_VAZIO_SEN];
    if (c.length === 1 && (st.vagas || 2) > 1) return [c[0], COR_VAZIO_SEN];   // vaga ainda em aberto
    return [c[0], c[1] || c[0]];
  }
  function blocoUF(k, x, y, l) {
    var cc = coresSen(k), o;
    if (cc[0] === cc[1]) o = r(x, y, l, l, cc[0], 3);
    else o = '<polygon points="' + x + "," + y + " " + (x + l) + "," + y + " " + x + "," + (y + l) + '" fill="' + cc[0] + '"/>' +
      '<polygon points="' + (x + l) + "," + y + " " + (x + l) + "," + (y + l) + " " + x + "," + (y + l) + '" fill="' + cc[1] + '"/>';
    return o + r(x + l / 2 - l * 0.22, y + l / 2 - l * 0.15, l * 0.44, l * 0.3, "#0b1220", 2) +
      t(x + l / 2, y + l / 2 + l * 0.09, k.toUpperCase(), { s: Math.round(l * 0.22), b: true, a: "middle" });
  }
  function mapaBlocos(x, y, l, gap) {
    var o = "";
    Object.keys(BLOCOS_UF).forEach(function (k) { var p = BLOCOS_UF[k]; o += blocoUF(k, x + p[0] * (l + gap), y + p[1] * (l + gap), l); });
    return o;
  }
  // Cartao do estado: sigla em faixa (cor dos 2 partidos), 2 fotos com nome e partido.
  function cartaoSen(k, x, y, w, h, fn) {
    var st = senEstado(k), cc = coresSen(k), o = "", n = Math.max(2, Math.min(3, st.vagas || 2));
    o += r(x, y, w, h, "rgba(8,14,32,0.82)", 5);
    var hf = Math.round(fn * 2);
    o += r(x, y, w / 2, hf, cc[0], 0) + r(x + w / 2, y, w / 2, hf, cc[1], 0);
    // nome do estado por extenso na faixa (encolhe se nao couber)
    var nomeUf = DEP_UF[k] || k.toUpperCase(), fsU = Math.round(fn * 1.2), wChip = Math.min(w - 8, nomeUf.length * fsU * 0.66 + 14);
    o += r(x + (w - wChip) / 2, y + 2, wChip, hf - 4, "#0b1220", 2) + t(x + w / 2, y + hf * 0.72, nomeUf, { s: fsU, b: true, a: "middle", max: wChip - 8 });
    var pad = 4, gw = (w - pad * (n + 1)) / n, top = y + hf + pad, hb = Math.round(fn * 2.3), hp = Math.round(fn * 1.5);
    var fh = h - hf - pad * 2 - hb - hp;
    for (var i = 0; i < n; i++) {
      var c = st.el[i], gx = x + pad + i * (gw + pad), cor = c ? corPartidoCamara(c.partido, i) : COR_VAZIO_SEN;
      o += r(gx - 1, top - 1, gw + 2, fh + hb + hp + 2, cor, 3);
      o += c ? fotoOuSilhueta(urlFotoSen(k, c), gx, top, gw, fh) : silhueta(gx, top, gw, fh);
      o += r(gx, top + fh, gw, hb, "#0b1220", 0);
      if (c) {
        var ln = linhasNome(c.nome, Math.max(8, Math.round(gw / (fn * 0.62))));
        if (ln.length === 1) o += t(gx + gw / 2, top + fh + hb * 0.62, ln[0], { s: fn, b: true, a: "middle", max: gw - 3 });
        else ln.forEach(function (l, j) { o += t(gx + gw / 2, top + fh + hb * (j ? 0.86 : 0.43), l, { s: Math.round(fn * 0.9), b: true, a: "middle", max: gw - 3 }); });
        o += r(gx, top + fh + hb, gw, hp, cor, 0) + t(gx + gw / 2, top + fh + hb + hp * 0.76, c.partido, { s: Math.round(fn * 0.95), b: true, c: "#0b1220", a: "middle", max: gw - 4 });
      } else {
        o += t(gx + gw / 2, top + fh + hb * 0.62, st.tem && st.urnas > 0 ? "APURANDO" : "AGUARDANDO", { s: Math.round(fn * 0.85), b: true, c: C.apagado, a: "middle", max: gw - 3 });
        o += r(gx, top + fh + hb, gw, hp, COR_VAZIO_SEN, 0);
      }
    }
    return o;
  }
  function contaSen() {
    var pp = {}, n = 0, vagas = 0;
    Object.keys(DEP_UF).forEach(function (k) {
      var st = senEstado(k); vagas += st.tem ? (st.vagas || 2) : 2;
      st.el.forEach(function (c) { pp[c.partido] = (pp[c.partido] || 0) + 1; n++; });
    });
    return { pp: pp, n: n, vagas: vagas };
  }
  function legendaSen(x, y, cols, cw, passo, fs) {
    var cs = contaSen(), ls = Object.keys(cs.pp).sort(function (a, b) { return cs.pp[b] - cs.pp[a] || a.localeCompare(b); }), o = "";
    ls.forEach(function (sg, i) {
      var xx = x + (i % cols) * cw, yy = y + Math.floor(i / cols) * passo;
      o += r(xx, yy - fs + 1, fs, fs, corPartidoCamara(sg, i), 3) + t(xx + fs + 8, yy, sg + " " + cs.pp[sg], { s: fs, b: true, max: cw - fs - 12 });
    });
    var i2 = ls.length, xx2 = x + (i2 % cols) * cw, yy2 = y + Math.floor(i2 / cols) * passo;
    o += '<polygon points="' + xx2 + "," + (yy2 - fs + 1) + " " + (xx2 + fs) + "," + (yy2 - fs + 1) + " " + xx2 + "," + (yy2 + 1) + '" fill="#2f6bff"/>' +
      '<polygon points="' + (xx2 + fs) + "," + (yy2 - fs + 1) + " " + (xx2 + fs) + "," + (yy2 + 1) + " " + xx2 + "," + (yy2 + 1) + '" fill="#e5132d"/>' +
      t(xx2 + fs + 8, yy2, "2 partidos na UF", { s: Math.round(fs * 0.9), c: "#c9d6e6", max: cw - fs - 12 });
    return o;
  }
  var GRADE_SEN = [["ac", "al", "am", "ap", "ba", "ce", "df"], ["es", "go", "ma", "mg", "ms", "mt", "pa"], ["pb", "pe", "pi", "pr", "rj", "rn", "ro"], ["rr", "rs", "sc", "se", "sp", "to"]];
  function seloSen() {
    var cs = contaSen();
    if (cs.n >= cs.vagas && cs.n > 0) return { texto: cs.vagas + " VAGAS", cor: C.destaque };
    return { texto: cs.n + " DE " + cs.vagas + " DEFINIDOS", cor: cs.n ? C.vermelho : C.trilho };
  }
  function telaSen(v) {
    var cs = contaSen(), o, sub = cs.n + (cs.n === 1 ? " eleito" : " eleitos") + " · 2 por estado · cor = partido do eleito";
    if (!v) {
      var W = 1280, H = 720;
      o = t(73, 57, "SENADORES", { s: 36, b: true, ls: 1 }) + t(73, 85, sub, { s: 18, c: C.apagado, max: 640 }) + seloH(W, seloSen());
      var cw = 116, ch = 136, gx = 8, gy = 6;
      GRADE_SEN.forEach(function (lin, li) {
        var x0 = 60 + (li === 3 ? (cw + gx) / 2 : 0);
        lin.forEach(function (k, ci) { o += cartaoSen(k, x0 + ci * (cw + gx), 110 + li * (ch + gy), cw, ch, 7.5); });
      });
      o += mapaBlocos(944, 110, 42, 4);
      o += legendaSen(924, 520, 3, 100, 22, 12);
      return svg(W, H, o + t(60, 700, "Fonte: TSE — senadores eleitos" + (E().turno === 2 ? " no 1º turno" : "") + " · mandato 2027–2035", { s: 13, c: C.apagado2 }));
    }
    var W2 = 540, H2 = 960;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "SENADORES", { s: 32, b: true, ls: 1 }) + t(53, 106, sub, { s: 13, c: C.apagado, max: 450 }) + seloV(W2, seloSen());
    var cw2 = 90, ch2 = 110, g2 = 5, todos = [].concat.apply([], GRADE_SEN), nUlt = todos.length % 5 || 5;
    todos.forEach(function (k, i) {
      var li = Math.floor(i / 5), ci = i % 5, ult = li === Math.floor((todos.length - 1) / 5);
      var x0 = 38 + (ult ? (5 - nUlt) * (cw2 + g2) / 2 : 0);
      o += cartaoSen(k, x0 + ci * (cw2 + g2), 162 + li * (ch2 + g2), cw2, ch2, 6.5);
    });
    o += legendaSen(40, 868, 4, 116, 17, 10);
    return svg(W2, H2, o + t(35, 952, "Fonte: TSE — senadores eleitos · mandato 2027–2035", { s: 10, c: C.apagado2 }));
  }
  G["senadores-h"] = function () { return telaSen(false); };
  G["senadores-v"] = function () { return telaSen(true); };

  // Senadores em DUAS telas (cartoes maiores): parte 1 = AC..PA, parte 2 = PB..TO.
  var SEN_PARTES = [["ac", "al", "am", "ap", "ba", "ce", "df", "es", "go", "ma", "mg", "ms", "mt", "pa"],
                    ["pb", "pe", "pi", "pr", "rj", "rn", "ro", "rr", "rs", "sc", "se", "sp", "to"]];
  function gradeSen(ufs, x0, y0, cols, cw, ch, gx, gy, fn, larguraTotal) {
    var o = "", linhas = Math.ceil(ufs.length / cols);
    ufs.forEach(function (k, i) {
      var li = Math.floor(i / cols), ci = i % cols, nLin = li === linhas - 1 ? ufs.length - li * cols : cols;
      var xi = x0 + (larguraTotal - (nLin * cw + (nLin - 1) * gx)) / 2;
      o += cartaoSen(k, xi + ci * (cw + gx), y0 + li * (ch + gy), cw, ch, fn);
    });
    return o;
  }
  function telaSenParte(v, parte) {
    var ufs = SEN_PARTES[parte], cs = contaSen(), o;
    var de = DEP_UF[ufs[0]], ate = DEP_UF[ufs[ufs.length - 1]];
    var sub = cs.n + (cs.n === 1 ? " eleito" : " eleitos") + " no Brasil · 2 por estado · cor = partido do eleito";
    var tit = "SENADORES";
    if (!v) {
      var W = 1280, H = 720;
      o = t(73, 57, tit, { s: 36, b: true, ls: 1 }) + t(73, 85, sub, { s: 18, c: C.apagado, max: 640 }) + seloH(W, seloSen());
      o += gradeSen(ufs, 73, 104, 5, 214, 168, 16, 8, 10, 1134);
      o += r(73, 632, 1134, 1, C.linha) + legendaSen(73, 656, 8, 142, 22, 12);
      return svg(W, H, o + t(73, 708, "Fonte: TSE — senadores eleitos" + (E().turno === 2 ? " no 1º turno" : "") + " · mandato 2027–2035 · contagem por partido = Brasil", { s: 11, c: C.apagado2 }));
    }
    var W2 = 540, H2 = 960;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 32, b: true, ls: 1 }) + t(53, 106, sub, { s: 13, c: C.apagado, max: 450 }) + seloV(W2, seloSen());
    o += gradeSen(ufs, 35, 162, 3, 152, 132, 7, 6, 8, 470);
    o += legendaSen(40, 880, 4, 116, 17, 10);
    return svg(W2, H2, o + t(35, 952, "Fonte: TSE — senadores eleitos · contagem por partido = Brasil", { s: 10, c: C.apagado2 }));
  }
  G["senadores1-h"] = function () { return telaSenParte(false, 0); };
  G["senadores2-h"] = function () { return telaSenParte(false, 1); };
  G["senadores1-v"] = function () { return telaSenParte(true, 0); };
  G["senadores2-v"] = function () { return telaSenParte(true, 1); };

  // =====================================================================
  // ANALISE DO 2o TURNO: ainda da para virar, placar dos governadores,
  // mapa das viradas, margem mais apertada, ganho de votos e abstencao
  // por estado. So numeros do TSE (dados.js / estados.js); a unica conta e
  // a de "faltam": eleitores em secoes ainda nao totalizadas (TSE: esnt).
  // =====================================================================
  function misturar(hex, fundo, t0) {
    var a = String(hex).replace("#", ""), b = String(fundo).replace("#", "");
    if (a.length !== 6 || b.length !== 6) return hex;
    var o = "#";
    for (var i = 0; i < 3; i++) {
      var x = parseInt(a.substr(i * 2, 2), 16), y = parseInt(b.substr(i * 2, 2), 16);
      o += ("0" + Math.round(x * t0 + y * (1 - t0)).toString(16)).slice(-2);
    }
    return o;
  }
  function faltamDe(x) {
    if (!x) return null;
    var e = x.eleitorado || {}, s0 = x.secoes || {};
    if (e.faltam != null) return +e.faltam;
    if (e.aptos != null && e.em_totalizadas != null) return Math.max(0, e.aptos - e.em_totalizadas);
    if (s0.pct >= 100) return 0;
    return null;
  }
  function nomeCurto(c) { var n = String(c && c.nome || ""); return n.length > 18 ? n.split(" ")[0] : n; }
  // Situacao "ainda da para virar?" de um boletim (Brasil ou estado).
  function contaVirada(x) {
    var cs = x ? candidatos(x).filter(function (c) { return c.votos > 0; }) : [];
    if (cs.length < 2) return null;
    var c1 = cs[0], c2 = cs[1], lead = c1.votos - c2.votos, F = faltamDe(x);
    var r = { c1: c1, c2: c2, lead: lead, faltam: F, urnas: x.secoes ? x.secoes.pct : null, eleito: !!c1.eleito };
    if (F == null) r.tipo = "?";
    else if (lead > F) r.tipo = "decidido";
    else { r.tipo = "aberto"; r.precisa = Math.min(100, 100 * (lead + F) / (2 * F)); }
    if (r.eleito) r.tipo = "decidido";
    return r;
  }
  function chipVirada(rv, x, y, k) {
    k = k || 1;
    if (!rv) return t(x, y, "—", { s: Math.round(14 * k), c: C.apagado, a: "end" });
    if (rv.tipo === "decidido") return r(x - 104 * k, y - 15 * k, 104 * k, 21 * k, C.verde, 3) + t(x - 52 * k, y, rv.eleito ? "ELEITO" : "DECIDIDO", { s: Math.round(13 * k), b: true, a: "middle", ls: 1 });
    if (rv.tipo === "?") return t(x, y, "sem o dado de faltam", { s: Math.round(12 * k), c: C.apagado, a: "end" });
    return t(x, y, "precisa " + pct1(rv.precisa), { s: Math.round(15 * k), b: true, c: rv.precisa >= 60 ? "#ffd43b" : "#ff8787", a: "end" });
  }
  G["virar-h"] = function () {
    var W = 1280, H = 720, f = fontePres(false), rb = contaVirada(f.br), o;
    o = t(73, 57, "AINDA DÁ PARA VIRAR?", { s: 36, b: true, ls: 1 }) + t(73, 85, "Presidente · " + turnoTxt(f) + " · " + subtitulo(), { s: 18, c: C.apagado, max: 640 }) + seloH(W, seloDe(f));
    o += r(73, 106, 1134, 150, "rgba(8,14,32,0.84)", 10);
    if (rb) {
      o += r(73, 106, 8, 150, cor(rb.c1), 4) + t(100, 140, "BRASIL", { s: 16, b: true, c: C.apagado, ls: 2 });
      o += t(100, 182, rb.c1.nome + " à frente por " + inteiro(rb.lead) + " votos", { s: 30, b: true, max: 640 });
      o += t(100, 214, "faltam apurar no máximo " + (rb.faltam == null ? "—" : inteiro(rb.faltam)) + " eleitores (seções não totalizadas)", { s: 16, c: C.apagado, max: 640 });
      o += t(100, 240, "urnas apuradas " + pct(rb.urnas), { s: 14, c: C.apagado2 });
      if (rb.tipo === "decidido") o += r(800, 140, 380, 80, C.verde, 8) + t(990, 176, rb.eleito ? "ELEITO" : "DECIDIDO", { s: 34, b: true, a: "middle", ls: 2 }) + t(990, 204, rb.eleito ? "segundo o TSE" : "pela conta: a vantagem é maior que tudo o que falta", { s: 13, a: "middle" });
      else if (rb.tipo === "aberto") o += t(1180, 166, nomeCurto(rb.c2) + " precisaria de", { s: 18, c: "#c9d6e6", a: "end" }) + t(1180, 212, pct1(rb.precisa), { s: 48, b: true, c: rb.precisa >= 60 ? "#ffd43b" : "#ff8787", a: "end" }) + t(1180, 238, "dos votos que faltam (se todos votarem)", { s: 13, c: C.apagado, a: "end" });
    } else o += t(640, 190, "aguardando o boletim do TSE", { s: 22, c: C.apagado, a: "middle" });
    var lin = Object.keys(DEP_UF).map(function (k) { return { k: k, r: contaVirada(f.uf(k)) }; })
      .sort(function (a, b) {
        var ra = a.r, rb2 = b.r, va = !ra ? 3 : ra.tipo === "aberto" ? 0 : ra.tipo === "?" ? 1 : 2, vb = !rb2 ? 3 : rb2.tipo === "aberto" ? 0 : rb2.tipo === "?" ? 1 : 2;
        return va - vb || (ra && rb2 && ra.tipo === "aberto" ? ra.precisa - rb2.precisa : 0) || DEP_UF[a.k].localeCompare(DEP_UF[b.k], "pt-BR");
      });
    var aberto = lin.filter(function (l) { return l.r && l.r.tipo === "aberto"; }).length;
    o += t(73, 290, "ESTADOS — " + aberto + " em aberto", { s: 15, b: true, c: "#c9d6e6", ls: 1 }) + t(1207, 290, "% que o 2º colocado precisaria dos votos que faltam", { s: 12, c: C.apagado, a: "end" });
    lin.forEach(function (l, i) {
      var col = i < 14 ? 0 : 1, li = i < 14 ? i : i - 14, x = 73 + col * 580, y = 318 + li * 26.5;
      o += r(x, y - 15, 556, 23, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 3);
      o += t(x + 8, y + 2, DEP_UF[l.k], { s: 13, b: true, max: 170 });
      if (l.r) {
        o += r(x + 190, y - 9, 10, 12, cor(l.r.c1), 2) + t(x + 206, y + 2, nomeCurto(l.r.c1) + " +" + inteiro(l.r.lead), { s: 13, c: "#c9d6e6", max: 220 });
        o += chipVirada(l.r, x + 550, y + 2, 0.85);
      } else o += t(x + 550, y + 2, "aguardando", { s: 12, c: C.apagado, a: "end" });
    });
    return svg(W, H, o + t(73, 708, "Fonte: TSE · conta: vantagem × eleitores em seções ainda não totalizadas (TSE: esnt). \"Decidido\" = nem todos os que faltam virariam.", { s: 11, c: C.apagado2, max: 1134 }));
  };
  G["virar-v"] = function () {
    var W = 540, H = 960, f = fontePres(false), rb = contaVirada(f.br), o;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "DÁ PARA VIRAR?", { s: 30, b: true, ls: 1 }) + t(53, 106, "Presidente · " + turnoTxt(f), { s: 14, c: C.apagado }) + seloV(W, seloDe(f));
    o += r(35, 166, 470, 210, "rgba(8,14,32,0.84)", 10);
    if (rb) {
      o += r(35, 166, 7, 210, cor(rb.c1), 3) + t(55, 196, "BRASIL", { s: 14, b: true, c: C.apagado, ls: 2 });
      o += t(55, 230, rb.c1.nome, { s: 24, b: true, max: 430 }) + t(55, 256, "à frente por " + inteiro(rb.lead) + " votos", { s: 18, c: "#c9d6e6" });
      o += t(55, 282, "faltam até " + (rb.faltam == null ? "—" : inteiro(rb.faltam)) + " eleitores", { s: 14, c: C.apagado });
      if (rb.tipo === "decidido") o += r(55, 300, 430, 56, C.verde, 6) + t(270, 338, rb.eleito ? "ELEITO" : "DECIDIDO", { s: 28, b: true, a: "middle", ls: 2 });
      else if (rb.tipo === "aberto") o += t(55, 316, nomeCurto(rb.c2) + " precisaria de", { s: 14, c: "#c9d6e6" }) + t(485, 356, pct1(rb.precisa), { s: 40, b: true, c: rb.precisa >= 60 ? "#ffd43b" : "#ff8787", a: "end" });
    }
    var lin = Object.keys(DEP_UF).map(function (k) { return { k: k, r: contaVirada(f.uf(k)) }; }).filter(function (l) { return l.r && l.r.tipo === "aberto"; })
      .sort(function (a, b) { return a.r.precisa - b.r.precisa; }).slice(0, 14);
    o += t(35, 410, "ESTADOS EM ABERTO (" + lin.length + ")", { s: 14, b: true, c: "#c9d6e6", ls: 1 });
    lin.forEach(function (l, i) {
      var y = 440 + i * 34;
      o += r(35, y - 18, 470, 28, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 3);
      o += r(45, y - 10, 8, 14, cor(l.r.c1), 2) + t(60, y + 2, DEP_UF[l.k], { s: 14, b: true, max: 200 }) + chipVirada(l.r, 495, y + 2, 0.9);
    });
    if (!lin.length) o += t(270, 470, "nenhum estado em aberto", { s: 16, c: C.apagado, a: "middle" });
    return svg(W, H, o + t(35, 948, "Fonte: TSE · vantagem × eleitores em seções não totalizadas", { s: 10, c: C.apagado2 }));
  };

  // ---- PLACAR DOS GOVERNADORES NO 2o TURNO ----------------------------------
  function estadosGov2t() {
    return Object.keys(DEP_UF).filter(function (k) {
      var u = (E().ufs || {})[k], g = u && u.gov && u.gov.tem ? u.gov : null;
      if (!g) return false;
      return +g.turno === 2 || comoLista(g.candidatos).some(function (c) { return c.segundo_turno; });
    }).sort(function (a, b) { return DEP_UF[a].localeCompare(DEP_UF[b], "pt-BR"); });
  }
  function cartaoGov2t(k, x, y, w, h, k2) {
    var g = ((E().ufs || {})[k] || {}).gov, cs = comoLista(g.candidatos), do2 = +g.turno === 2;
    var dois = do2 ? cs.slice(0, 2) : cs.filter(function (c) { return c.segundo_turno; }).slice(0, 2);
    if (dois.length < 2) dois = cs.slice(0, 2);
    var o = r(x, y, w, h, "rgba(8,14,32,0.84)", 8);
    o += t(x + 14, y + 22 * k2, DEP_UF[k], { s: Math.round(16 * k2), b: true, ls: 1 });
    var lh = (h - 30 * k2) / 2, compacto = lh < 60, temEl = dois.some(function (c) { return c.eleito; });
    // cartao baixo (vertical com muitos estados): ELEITO vai na linha do estado
    if (compacto && temEl) o += r(x + w - 74, y + 8 * k2, 62, 16, C.verde, 3) + t(x + w - 43, y + 20 * k2, "ELEITO", { s: 11, b: true, a: "middle", ls: 1 });
    o += t(x + w - (compacto && temEl ? 84 : 12), y + 22 * k2, do2 ? "urnas " + pct(g.urnas_pct) : "1º turno · vão ao 2º turno", { s: Math.round(12 * k2), c: C.apagado, a: "end" });
    dois.forEach(function (c, i) {
      var yy = y + 30 * k2 + i * lh, cc = corPartidoCamara(c.partido, i), fh = lh - 6, fw = fh * 0.78;
      o += fotoOuSilhueta(urlFotoGov(k, { c: c, g: g }), x + 12, yy + 2, fw, fh);
      var tx = x + 20 + fw;
      var resPct = Math.round(110 * Math.max(1, k2));
      o += t(tx, yy + lh * 0.55, c.nome + "  ·  " + c.partido, { s: Math.round(15 * k2), b: true, max: w - (tx - x) - resPct - 10 });
      o += barraFina(tx, yy + lh - 10, w - (tx - x) - resPct, (c.pct || 0) / 100, cc);
      o += t(x + w - 12, yy + lh * 0.55, pct(c.pct), { s: Math.round(22 * k2), b: true, a: "end" });
      // 3.28.6: ELEITO embaixo do %, na linha da barra (nao cobre o numero)
      if (c.eleito && compacto) o += r(x + 4, yy + 4, 4, lh - 8, C.verde, 2);
      if (c.eleito && !compacto) { var we = Math.round(84 * Math.max(1, k2 * 0.9)), he = Math.round(18 * Math.max(1, k2 * 0.9)); o += r(x + w - 12 - we, yy + lh - 8 - he / 2 - 2, we, he, C.verde, 3) + t(x + w - 12 - we / 2, yy + lh - 8 + he / 2 - 6, "ELEITO", { s: Math.round(12 * Math.max(1, k2 * 0.9)), b: true, a: "middle", ls: 1 }); }
    });
    return o;
  }
  function telaGov2t(v) {
    var ls = estadosGov2t(), o, n = ls.length;
    var nEl = ls.filter(function (k) { return comoLista(((E().ufs || {})[k] || {}).gov.candidatos).some(function (c) { return c.eleito; }); }).length;
    var sub = n + " estados no 2º turno · " + nEl + (nEl === 1 ? " já definido" : " já definidos");
    var sl = { texto: nEl >= n && n ? "TODOS DEFINIDOS" : (n - nEl) + " EM DISPUTA", cor: nEl >= n && n ? C.verde : C.destaque };
    if (!v) {
      var W = 1280, H = 720;
      o = t(73, 57, "GOVERNADORES — 2º TURNO", { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, sub, { s: 18, c: C.apagado }) + seloH(W, sl);
      if (!n) return svg(W, H, marcaVazio() + o + t(640, 380, "nenhum estado com 2º turno de governador", { s: 22, c: C.apagado, a: "middle" }));
      // 3.28.6: com poucos estados os cartoes crescem e ocupam a tela
      var rows = Math.ceil(n / 2), ch = Math.min(200, (582 - (rows - 1) * 10) / rows);
      ls.forEach(function (k, i) { o += cartaoGov2t(k, 73 + (i % 2) * 575, 106 + Math.floor(i / 2) * (ch + 10), 559, ch, Math.min(1.4, ch / 108)); });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — Governador, 2º turno" + (E().turno === 2 ? "" : " (hoje: os dois que vão ao 2º turno, % do 1º turno)"), { s: 11, c: C.apagado2 }));
    }
    var W2 = 540, H2 = 960;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "GOVERNADORES", { s: 30, b: true, ls: 1 }) + t(53, 106, "2º turno · " + sub, { s: 13, c: C.apagado, max: 450 }) + seloV(W2, sl);
    if (!n) return svg(W2, H2, marcaVazio() + o + t(270, 480, "nenhum estado com 2º turno", { s: 18, c: C.apagado, a: "middle" }));
    var ch2 = Math.min(170, (770 - (n - 1) * 8) / n);
    ls.forEach(function (k, i) { o += cartaoGov2t(k, 35, 164 + i * (ch2 + 8), 470, ch2, Math.min(1.2, ch2 / 112)); });
    return svg(W2, H2, o + t(35, 950, "Fonte: TSE — Governador, 2º turno", { s: 10, c: C.apagado2 }));
  }
  G["gov2t-h"] = function () { return telaGov2t(false); };
  G["gov2t-v"] = function () { return telaGov2t(true); };

  // ---- GOVERNADORES: 1o x 2o TURNO (estados com 2o turno) -------------------
  // 2o turno ao vivo (estados.js, gov) x 1o turno guardado (gov1t), os dois do
  // TSE. Os finalistas sao ligados pelo numero do candidato.
  function govDoisTurnos() {
    var out = [];
    Object.keys(DEP_UF).forEach(function (k) {
      var u = (E().ufs || {})[k], g2 = u && u.gov, g1 = u && u.gov1t;
      if (!g2 || !g2.tem || +g2.turno !== 2 || !g1 || !g1.tem) return;
      var c2 = comoLista(g2.candidatos).slice().sort(function (a, b) { return (+b.votos || 0) - (+a.votos || 0); }).slice(0, 2);
      if (c2.length < 2) return;
      var c1 = comoLista(g1.candidatos), urnas = +g2.urnas_pct || 0;
      var par = c2.map(function (c) {
        var a = c1.filter(function (x) { return String(x.numero) === String(c.numero); })[0];
        return { c: c, p1: a ? +a.pct : null, v1: a ? +a.votos : null };
      });
      var lider1 = par[0].p1 != null && par[1].p1 != null ? (par[0].p1 >= par[1].p1 ? 0 : 1) : null;
      out.push({ k: k, par: par, urnas: urnas, fim: urnas >= 99.99, virou: urnas > 0 && lider1 === 1, eleito: c2.some(function (c) { return c.eleito; }) });
    });
    return out.sort(function (a, b) { return DEP_UF[a.k].localeCompare(DEP_UF[b.k], "pt-BR"); });
  }
  function telaGov12(v) {
    var ls = govDoisTurnos(), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "GOVERNADORES: 1º × 2º TURNO", o;
    if (!ls.length) return semDados(W, H, v, v ? "GOVERNADOR 1º × 2º" : tit, "disponível quando sair o 2º turno de governador (TSE)");
    var nv = ls.filter(function (x) { return x.virou; }).length, nEl = ls.filter(function (x) { return x.eleito; }).length;
    var sub = ls.length + " estados no 2º turno · " + (nv ? nv + (nv === 1 ? " virou" : " viraram") + " (quem liderava no 1º turno está atrás)" : "ninguém virou até agora");
    var sl = nEl >= ls.length ? { texto: "TODOS DEFINIDOS", cor: C.verde } : { texto: (ls.length - nEl) + " EM DISPUTA", cor: C.destaque };
    function dif(p) { if (p.p1 == null) return "1º: —"; var d = (+p.c.pct || 0) - p.p1; return "1º " + pct1(p.p1) + " → " + pct1(+p.c.pct || 0) + "  (" + (d >= 0 ? "+" : "−") + Number(Math.abs(d)).toFixed(1).replace(".", ",") + " p.p.)"; }
    function ganho(p, fim) { return fim && p.v1 != null ? "  ·  " + (p.c.votos - p.v1 >= 0 ? "+" : "−") + inteiro(Math.abs(p.c.votos - p.v1)) + " votos" : ""; }
    if (!v) {
      o = t(73, 57, tit, { s: 34, b: true, ls: 1, max: 667 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 680 }) + seloH(W, sl);
      var n = ls.length, ph = Math.min(64, 584 / n), k2 = Math.min(1, ph / 60);
      ls.forEach(function (x, i) {
        var y = 106 + i * ph, hh = ph - 5;
        o += r(73, y, 1134, hh, i % 2 ? "rgba(8,14,32,0.70)" : "rgba(8,14,32,0.86)", 6);
        o += t(87, y + hh * 0.44, DEP_UF[x.k], { s: Math.round(15 * k2), b: true, max: 142 });
        if (x.virou) o += r(87, y + hh * 0.58, 46, hh * 0.32, "#ffd43b", 3) + t(110, y + hh * 0.83, "VIROU", { s: Math.round(10 * k2), b: true, a: "middle", c: "#111" });
        o += t(x.virou ? 139 : 87, y + hh * 0.84, x.fim ? "final" : "urnas " + pct(x.urnas), { s: Math.round(11 * k2), c: C.apagado, max: x.virou ? 92 : 142 });
        x.par.forEach(function (p, j) {
          var bx = 240 + j * 487, cc = corPartidoCamara(p.c.partido, j);
          o += r(bx, y + hh * 0.18, 5, hh * 0.64, cc, 2);
          o += t(bx + 14, y + hh * 0.44, p.c.nome + " · " + p.c.partido, { s: Math.round(15 * k2), b: true, max: 330 }) + t(bx + 14, y + hh * 0.82, dif(p) + ganho(p, x.fim), { s: Math.round(12 * k2), c: "#c9d6e6", max: 460 });
          o += t(bx + 470, y + hh * 0.56, pct1(+p.c.pct || 0), { s: Math.round(22 * k2), b: true, a: "end" });
          if (p.c.eleito) o += r(bx + 352, y + hh * 0.12, 64, 15, C.verde, 2) + t(bx + 384, y + hh * 0.12 + 11, "ELEITO", { s: 10, b: true, a: "middle" });
        });
      });
      return svg(W, H, o + t(73, 704, "Fonte: TSE — Governador, 2º turno ao vivo × 1º turno (% dos votos válidos)" + (ls.some(function (x) { return x.fim; }) ? " · votos ganhos só com 100% das urnas" : ""), { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "GOVERNADOR 1º × 2º", { s: 28, b: true, ls: 1, max: 450 }) + t(53, 106, ls.length + " estados · " + (nv ? nv + (nv === 1 ? " virou" : " viraram") : "ninguém virou"), { s: 14, c: C.apagado, max: 450 }) + seloV(W, sl);
    var n2 = ls.length, pv = Math.min(90, 770 / n2), kv = Math.min(1, pv / 86);
    ls.forEach(function (x, i) {
      var y = 160 + i * pv, hh = pv - 6;
      o += r(35, y, 470, hh, i % 2 ? "rgba(8,14,32,0.70)" : "rgba(8,14,32,0.86)", 6);
      o += t(47, y + 18 * kv, DEP_UF[x.k], { s: Math.round(14 * kv), b: true, max: 300 }) + t(493, y + 18 * kv, x.virou ? "VIROU" : (x.fim ? "final" : "urnas " + pct(x.urnas)), { s: Math.round(12 * kv), b: x.virou, c: x.virou ? "#ffd43b" : C.apagado, a: "end" });
      x.par.forEach(function (p, j) {
        var yy = y + 22 * kv + j * ((hh - 22 * kv) / 2), lh = (hh - 22 * kv) / 2;
        o += r(47, yy + lh * 0.2, 4, lh * 0.6, corPartidoCamara(p.c.partido, j), 2);
        o += t(58, yy + lh * 0.58, p.c.nome + " · " + p.c.partido, { s: Math.round(12 * kv), b: true, max: 230 });
        o += t(390, yy + lh * 0.58, p.p1 != null ? "1º " + pct1(p.p1) + " →" : "", { s: Math.round(11 * kv), c: C.apagado, a: "end" });
        o += t(493, yy + lh * 0.62, pct1(+p.c.pct || 0), { s: Math.round(16 * kv), b: true, a: "end" });
      });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — 2º turno × 1º turno (% válidos)", { s: 10, c: C.apagado2 }));
  }
  G["gov12-h"] = function () { return telaGov12(false); };
  G["gov12-v"] = function () { return telaGov12(true); };

  // ---- MAPA DAS VIRADAS (Presidente): quem liderava no 1o e quem lidera agora
  function viradas() {
    var f1 = fontePres(true), f2 = fontePres(false), out = [];
    if (!f1.guardado) return null;
    Object.keys(DEP_UF).forEach(function (k) {
      var l1 = liderF(f1, k), l2 = liderF(f2, k);
      if (l1 && l2 && String(l1.numero) !== String(l2.numero)) out.push({ k: k, de: l1, para: l2, x2: f2.uf(k) });
    });
    return { lista: out, f1: f1, f2: f2 };
  }
  function mapaViradas(vr, x, y, esc) {
    var M = window.MAPA_BRASIL, o = '<g transform="translate(' + x + " " + y + ") scale(" + esc + ')">', vir = {};
    vr.lista.forEach(function (v) { vir[v.k] = v; });
    var k, e, l;
    for (k in M.estados) {
      e = M.estados[k]; l = liderF(vr.f2, k);
      var c0 = l ? cor(l) : C.semDado;
      o += '<path d="' + e.path + '" fill="' + (vir[k] ? c0 : misturar(c0, "#0b1220", 0.32)) + '" stroke="' + C.fundo + '" stroke-width="' + (1.2 / esc).toFixed(2) + '"/>';
    }
    for (k in vir) { e = M.estados[k]; o += '<path d="' + e.path + '" fill="none" stroke="#ffffff" stroke-width="' + (3 / esc).toFixed(2) + '" stroke-linejoin="round"/>'; }
    var contorno = ' stroke="' + C.fundo + '" stroke-width="' + (3 / esc).toFixed(2) + '" paint-order="stroke"';
    for (k in vir) { e = M.estados[k]; o += '<text x="' + e.cx + '" y="' + (e.cy + 5) + '" font-size="' + (13 / esc).toFixed(1) + '" font-weight="700" fill="#fff" text-anchor="middle"' + contorno + ">" + k.toUpperCase() + "</text>"; }
    return o + "</g>";
  }
  function telaViradas(v) {
    var vr = viradas(), W = v ? 540 : 1280, H = v ? 960 : 720, o;
    var tit = "ESTADOS QUE VIRARAM";
    if (!vr) {
      o = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 28, b: true, ls: 1 }) : t(73, 57, tit, { s: 36, b: true, ls: 1 });
      return svg(W, H, marcaVazio() + o + t(W / 2, H / 2, "disponível no 2º turno (compara com o 1º turno guardado)", { s: v ? 15 : 22, c: C.apagado, a: "middle", max: W - 60 }));
    }
    var cont = {}, ref = {};
    vr.lista.forEach(function (x) { cont[x.para.numero] = (cont[x.para.numero] || 0) + 1; ref[x.para.numero] = x.para; });
    var resumo = Object.keys(cont).map(function (n) { return cont[n] + " para " + nomeCurto(ref[n]); }).join(" · ");
    var sub = "Presidente · quem liderava no 1º turno × quem lidera agora · " + vr.lista.length + (vr.lista.length === 1 ? " estado mudou" : " estados mudaram");
    var lst = vr.lista.slice().sort(function (a, b) { return DEP_UF[a.k].localeCompare(DEP_UF[b.k], "pt-BR"); });
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 660 }) + seloH(W, seloDe(vr.f2));
      o += mapaViradas(vr, 40, 112, 0.86);
      o += t(650, 132, resumo ? "VIRARAM " + resumo.toUpperCase() : "NENHUM ESTADO VIROU", { s: 16, b: true, c: "#c9d6e6", ls: 1, max: 557 });
      lst.slice(0, 12).forEach(function (x, i) {
        var y = 160 + i * 42;
        o += r(650, y, 557, 36, "rgba(8,14,32,0.84)", 6) + t(664, y + 24, DEP_UF[x.k], { s: 15, b: true, max: 190 });
        o += r(860, y + 10, 12, 16, cor(x.de), 2) + t(878, y + 24, nomeCurto(x.de), { s: 13, c: "#c9d6e6", max: 110 });
        o += t(990, y + 24, "→", { s: 18, b: true, c: C.apagado, a: "middle" });
        o += r(1004, y + 10, 12, 16, cor(x.para), 2) + t(1022, y + 24, nomeCurto(x.para), { s: 13, b: true, max: 110 });
        o += t(1196, y + 24, pct(x.para.pct), { s: 15, b: true, a: "end" });
      });
      if (lst.length > 12) o += t(650, 680, "+ " + (lst.length - 12) + " estados (contorno branco no mapa)", { s: 13, c: C.apagado });
      o += '<rect x="73" y="660" width="14" height="14" fill="#2b3a55" stroke="#fff" stroke-width="2"/>' + t(94, 672, "contorno branco = virou · cor apagada = mesmo líder do 1º turno", { s: 12, c: C.apagado });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — Presidente por estado, 1º turno (final) e 2º turno" + (vr.f2.br && vr.f2.br.andamento === "f" ? "" : " (parcial)"), { s: 11, c: C.apagado2 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 28, b: true, ls: 1, max: 450 }) + t(53, 106, vr.lista.length + " estados mudaram de líder do 1º para o 2º turno", { s: 13, c: C.apagado, max: 450 }) + seloV(W, seloDe(vr.f2));
    o += mapaViradas(vr, 50, 160, 0.72);
    lst.slice(0, 9).forEach(function (x, i) {
      var y = 640 + i * 32;
      o += r(35, y, 470, 28, "rgba(8,14,32,0.84)", 4) + t(47, y + 19, DEP_UF[x.k], { s: 13, b: true, max: 160 });
      o += r(220, y + 7, 10, 14, cor(x.de), 2) + t(236, y + 19, nomeCurto(x.de), { s: 12, c: "#c9d6e6", max: 90 }) + t(340, y + 19, "→", { s: 14, c: C.apagado, a: "middle" });
      o += r(352, y + 7, 10, 14, cor(x.para), 2) + t(368, y + 19, nomeCurto(x.para), { s: 12, b: true, max: 90 }) + t(495, y + 19, pct(x.para.pct), { s: 13, b: true, a: "end" });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — 1º turno × 2º turno", { s: 10, c: C.apagado2 }));
  }
  G["viradas-h"] = function () { return telaViradas(false); };
  G["viradas-v"] = function () { return telaViradas(true); };

  // ---- MARGEM MAIS APERTADA (Presidente, por estado) ------------------------
  function margens() {
    var f = fontePres(false);
    return Object.keys(DEP_UF).map(function (k) {
      var x = f.uf(k), cs = x ? candidatos(x).filter(function (c) { return c.votos > 0; }) : [];
      if (cs.length < 2) return null;
      return { k: k, c1: cs[0], c2: cs[1], dpp: cs[0].pct - cs[1].pct, dv: cs[0].votos - cs[1].votos, urnas: x.secoes ? x.secoes.pct : null };
    }).filter(Boolean).sort(function (a, b) { return a.dpp - b.dpp; });
  }
  function telaMargem(v) {
    var f = fontePres(false), ls = margens(), b = f.br, cs = b ? candidatos(b) : [], o;
    var bra = cs.length > 1 ? (cs[0].pct - cs[1].pct) : null;
    var n = v ? 12 : 10, top = ls.slice(0, n), max = top.length ? Math.max(1, top[top.length - 1].dpp) : 1;
    var sub = "Presidente · diferença entre 1º e 2º colocados por estado · " + turnoTxt(f) + (bra != null ? " · Brasil: " + Number(bra).toFixed(2).replace(".", ",") + " p.p." : "");
    if (!v) {
      var W = 1280, H = 720;
      o = t(73, 57, "DISPUTA MAIS APERTADA", { s: 36, b: true, ls: 1 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
      if (!top.length) return svg(W, H, marcaVazio() + o + t(640, 380, "aguardando os boletins dos estados", { s: 22, c: C.apagado, a: "middle" }));
      top.forEach(function (m, i) {
        var y = 112 + i * 56;
        o += r(73, y, 1134, 50, "rgba(8,14,32,0.84)", 6) + t(100, y + 33, (i + 1) + "º", { s: 18, b: true, c: C.apagado });
        o += t(150, y + 33, DEP_UF[m.k], { s: 20, b: true, max: 260 });
        o += r(430, y + 12, 6, 26, cor(m.c1), 2) + t(446, y + 24, nomeCurto(m.c1) + " " + pct(m.c1.pct), { s: 14, b: true, max: 210 }) + t(446, y + 42, "× " + nomeCurto(m.c2) + " " + pct(m.c2.pct), { s: 12, c: C.apagado, max: 210 });
        o += barraFina(680, y + 21, 300, m.dpp / max, cor(m.c1));
        o += t(1120, y + 31, Number(m.dpp).toFixed(2).replace(".", ",") + " p.p.", { s: 22, b: true, a: "end" });
        o += t(1196, y + 22, inteiro(m.dv), { s: 12, c: "#c9d6e6", a: "end" }) + t(1196, y + 38, "votos", { s: 11, c: C.apagado, a: "end" });
      });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — boletins de Presidente dos estados · urnas apuradas em cada estado podem diferir", { s: 11, c: C.apagado2 }));
    }
    var W2 = 540, H2 = 960;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "MAIS APERTADOS", { s: 30, b: true, ls: 1 }) + t(53, 106, "Presidente · diferença por estado", { s: 14, c: C.apagado }) + seloV(W2, seloDe(f));
    top.forEach(function (m, i) {
      var y = 166 + i * 62;
      o += r(35, y, 470, 56, "rgba(8,14,32,0.84)", 6) + r(35, y, 6, 56, cor(m.c1), 3);
      o += t(52, y + 24, DEP_UF[m.k], { s: 17, b: true, max: 260 }) + t(52, y + 45, nomeCurto(m.c1) + " à frente · " + inteiro(m.dv) + " votos", { s: 12, c: C.apagado, max: 300 });
      o += t(493, y + 36, Number(m.dpp).toFixed(2).replace(".", ",") + " p.p.", { s: 22, b: true, a: "end" });
    });
    return svg(W2, H2, o + t(35, 950, "Fonte: TSE — Presidente por estado", { s: 10, c: C.apagado2 }));
  }
  G["margem-h"] = function () { return telaMargem(false); };
  G["margem-v"] = function () { return telaMargem(true); };

  // ---- GANHO DE VOTOS DO 1o PARA O 2o TURNO (Presidente) --------------------
  function ganhos() {
    var f1 = fontePres(true), f2 = fontePres(false);
    if (!f1.guardado || !f2.br) return null;
    var fin = candidatos(f2.br).slice(0, 2); if (fin.length < 2) return null;
    function votosDe(cs, n) { for (var i = 0; i < cs.length; i++) if (String(cs[i].numero) === String(n)) return +cs[i].votos || 0; return 0; }
    var br = fin.map(function (c) { var v1 = votosDe(candidatos(f1.br), c.numero), v2 = +c.votos || 0; return { c: c, v1: v1, v2: v2, g: v2 - v1 }; });
    var regs = ["Norte", "Nordeste", "Centro-Oeste", "Sudeste", "Sul"].map(function (nome) {
      var a1 = agregar(f1, ufsDaRegiao(nome)), a2 = agregar(f2, ufsDaRegiao(nome));
      return { nome: nome, it: fin.map(function (c) { var v1 = votosDe(a1.cs, c.numero), v2 = votosDe(a2.cs, c.numero); return { c: c, v1: v1, v2: v2, g: v2 - v1 }; }) };
    });
    return { br: br, regs: regs, f2: f2 };
  }
  function sinalVotos(g) { return (g > 0 ? "+" : g < 0 ? "−" : "") + inteiro(Math.abs(g)); }
  function telaGanho(v) {
    var gn = ganhos(), W = v ? 540 : 1280, H = v ? 960 : 720, o;
    var tit = "GANHO DE VOTOS: 1º → 2º TURNO";
    if (!gn) {
      o = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, "GANHO DE VOTOS", { s: 28, b: true, ls: 1 }) : t(73, 57, tit, { s: 36, b: true, ls: 1 });
      return svg(W, H, marcaVazio() + o + t(W / 2, H / 2, "disponível no 2º turno (compara com o 1º turno guardado)", { s: v ? 15 : 22, c: C.apagado, a: "middle", max: W - 60 }));
    }
    var pU = gn.f2.br.secoes ? gn.f2.br.secoes.pct : 0, parcial = !(gn.f2.br.andamento === "f"), maxG = 1;
    if (!(pU >= 100)) {
      o = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, "GANHO DE VOTOS", { s: 28, b: true, ls: 1 }) + seloV(W, seloDe(gn.f2)) : t(73, 57, tit, { s: 34, b: true, ls: 1, max: 667 }) + seloH(W, seloDe(gn.f2));
      return svg(W, H, marcaVazio() + o + t(W / 2, H / 2 - 12, "aguardando o fim da apuração do 2º turno", { s: v ? 18 : 26, b: true, c: "#c9d6e6", a: "middle" }) +
        t(W / 2, H / 2 + 20, "urnas apuradas: " + pct(pU) + " — antes de 100% a comparação com o 1º turno engana", { s: v ? 12 : 16, c: C.apagado, a: "middle", max: W - 60 }));
    }
    gn.regs.forEach(function (rg) { rg.it.forEach(function (x) { maxG = Math.max(maxG, Math.abs(x.g)); }); });
    var sub = "Presidente · votos no 2º turno menos votos no 1º turno" + (parcial ? " · 2º turno PARCIAL (urnas " + pct(gn.f2.br.secoes.pct) + "): o ganho cresce até o fim" : "");
    if (!v) {
      o = t(73, 57, tit, { s: 34, b: true, ls: 1, max: 667 }) + t(73, 85, sub, { s: 15, c: C.apagado, max: 660 }) + seloH(W, seloDe(gn.f2));
      gn.br.forEach(function (x, i) {
        var X = 73 + i * 575, cc = cor(x.c);
        o += r(X, 106, 559, 196, "rgba(8,14,32,0.84)", 10) + r(X, 106, 559, 7, cc, 4);
        o += fotoOuSilhueta(urlFotoPres(x.c, gn.f2.eleicao), X + 18, 126, 120, 160);
        o += t(X + 156, 150, x.c.nome, { s: 22, b: true, max: 390 }) + t(X + 156, 172, x.c.partido, { s: 14, c: C.apagado });
        o += t(X + 156, 212, "1º turno  " + inteiro(x.v1), { s: 15, c: "#c9d6e6" }) + t(X + 156, 236, "2º turno  " + inteiro(x.v2), { s: 15, c: "#c9d6e6" });
        o += t(X + 545, 282, sinalVotos(x.g), { s: 34, b: true, c: x.g >= 0 ? "#69db7c" : "#ff8787", a: "end" });
        o += t(X + 545, 296, "votos " + (x.v1 ? "(" + (x.g >= 0 ? "+" : "−") + pct1(Math.abs(100 * x.g / x.v1)) + ")" : ""), { s: 11, c: C.apagado, a: "end" });
      });
      o += t(73, 336, "POR REGIÃO", { s: 15, b: true, c: "#c9d6e6", ls: 1 });
      gn.regs.forEach(function (rg, i) {
        var y = 352 + i * 66;
        o += r(73, y, 1134, 58, "rgba(8,14,32,0.84)", 6) + t(92, y + 36, REG_NOME[rg.nome], { s: 18, b: true, ls: 1 });
        rg.it.forEach(function (x, j) {
          var X = 300 + j * 455, w = 260 * Math.abs(x.g) / maxG;
          o += t(X, y + 22, nomeCurto(x.c), { s: 12, c: C.apagado, max: 160 });
          o += r(X, y + 30, 260, 14, "rgba(255,255,255,0.08)", 4) + (w > 0 ? r(X, y + 30, Math.max(4, w), 14, x.g >= 0 ? cor(x.c) : "#ff8787", 4) : "");
          o += t(X + 420, y + 43, sinalVotos(x.g), { s: 18, b: true, c: x.g >= 0 ? C.texto : "#ff8787", a: "end" });
        });
      });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — Presidente, 1º turno (final) e 2º turno · regiões = soma dos estados (sem exterior). Não mostra de quem veio o voto.", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "GANHO DE VOTOS", { s: 30, b: true, ls: 1 }) + t(53, 106, "Presidente · 1º → 2º turno" + (parcial ? " · parcial" : ""), { s: 14, c: C.apagado }) + seloV(W, seloDe(gn.f2));
    gn.br.forEach(function (x, i) {
      var y = 166 + i * 150, cc = cor(x.c);
      o += r(35, y, 470, 140, "rgba(8,14,32,0.84)", 8) + r(35, y, 7, 140, cc, 3);
      o += fotoOuSilhueta(urlFotoPres(x.c, gn.f2.eleicao), 52, y + 12, 87, 116);
      o += t(152, y + 34, x.c.nome, { s: 18, b: true, max: 340 }) + t(152, y + 60, "1º " + inteiro(x.v1) + "  ·  2º " + inteiro(x.v2), { s: 13, c: "#c9d6e6", max: 340 });
      o += t(493, y + 116, sinalVotos(x.g), { s: 30, b: true, c: x.g >= 0 ? "#69db7c" : "#ff8787", a: "end" });
    });
    gn.regs.forEach(function (rg, i) {
      var y = 480 + i * 92;
      o += r(35, y, 470, 84, "rgba(8,14,32,0.84)", 6) + t(52, y + 26, REG_NOME[rg.nome], { s: 16, b: true, ls: 1 });
      rg.it.forEach(function (x, j) { o += r(52, y + 40 + j * 22, 8, 14, cor(x.c), 2) + t(68, y + 52 + j * 22, nomeCurto(x.c), { s: 13, c: "#c9d6e6", max: 200 }) + t(493, y + 52 + j * 22, sinalVotos(x.g), { s: 15, b: true, c: x.g >= 0 ? C.texto : "#ff8787", a: "end" }); });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — 1º turno (final) × 2º turno", { s: 10, c: C.apagado2 }));
  }
  G["ganho-h"] = function () { return telaGanho(false); };
  G["ganho-v"] = function () { return telaGanho(true); };

  // ---- ABSTENCAO 1o x 2o TURNO POR ESTADO ----------------------------------
  var FAIXAS_DIFABST = [[-99, -2, "#1f9e74", "caiu mais de 2 p.p."], [-2, -0.5, "#63c5a0", "caiu até 2 p.p."], [-0.5, 0.5, "#6b7688", "estável (±0,5)"],
    [0.5, 2, "#f0a35b", "subiu até 2 p.p."], [2, 99, "#e8590c", "subiu mais de 2 p.p."]];
  function difAbst() {
    var f1 = fontePres(true), f2 = fontePres(false);
    if (!f1.guardado) return null;
    var ls = Object.keys(DEP_UF).map(function (k) {
      var a = f1.uf(k), b = f2.uf(k), p1 = a && a.eleitorado ? a.eleitorado.pct_abstencao : null, p2 = b && b.eleitorado ? b.eleitorado.pct_abstencao : null;
      if (p1 == null || p2 == null || !(b.secoes && b.secoes.pct > 0)) return { k: k, d: null };
      return { k: k, p1: +p1, p2: +p2, d: p2 - p1 };
    });
    var b1 = f1.br && f1.br.eleitorado ? f1.br.eleitorado.pct_abstencao : null, b2 = f2.br && f2.br.eleitorado ? f2.br.eleitorado.pct_abstencao : null;
    return { ls: ls, b1: b1, b2: b2, f2: f2 };
  }
  function corDifAbst(d) { if (d == null) return null; for (var i = 0; i < FAIXAS_DIFABST.length; i++) if (d >= FAIXAS_DIFABST[i][0] && d < FAIXAS_DIFABST[i][1]) return FAIXAS_DIFABST[i][2]; return "#6b7688"; }
  function ppS(d) { return (d > 0 ? "+" : d < 0 ? "−" : "") + Number(Math.abs(d)).toFixed(2).replace(".", ",") + " p.p."; }
  function telaAbstUf(v) { return telaVarUf(v, { da: difAbst(), tit: "ABSTENÇÃO: 1º × 2º TURNO", titV: "ABSTENÇÃO 1º × 2º", oque: "variação da abstenção por estado (pontos percentuais)", sem: "disponível no 2º turno (compara com o 1º turno guardado)", fonte: "Fonte: TSE — abstenção sobre o eleitorado; 1º turno final × 2º turno", fonteV: "Fonte: TSE — abstenção 1º × 2º turno" }); }
  // Variacao por estado (mapa + mais subiu/caiu): abstencao 1o x 2o, 2022 x 2026, brancos e nulos.
  function telaVarUf(v, P) {
    var da = P.da, W = v ? 540 : 1280, H = v ? 960 : 720, o, tit = P.tit;
    if (!da) {
      o = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, P.titV, { s: 28, b: true, ls: 1 }) : t(73, 57, tit, { s: 36, b: true, ls: 1 });
      return svg(W, H, marcaVazio() + o + t(W / 2, H / 2, P.sem, { s: v ? 15 : 22, c: C.apagado, a: "middle", max: W - 60 }));
    }
    var ok = da.ls.filter(function (x) { return x.d != null; }), sob = ok.slice().sort(function (a, b) { return b.d - a.d; }), des = ok.slice().sort(function (a, b) { return a.d - b.d; });
    var corM = function (k) { var x = da.ls.filter(function (y) { return y.k === k; })[0]; return x ? corDifAbst(x.d) : null; };
    var sub = P.oque + (da.b1 != null && da.b2 != null ? " · Brasil: " + pct(da.b1) + " → " + pct(da.b2) : "");
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 660 }) + seloH(W, seloDe(da.f2));
      o += mapaCor(40, 112, 0.84, corM, { rotulos: true, fonte: 12, apagado: "#1c2a40" });
      FAIXAS_DIFABST.forEach(function (fx, i) { o += r(60, 600 + i * 20, 14, 14, fx[2], 2) + t(82, 612 + i * 20, fx[3], { s: 12, c: C.apagado }); });
      [["MAIS SUBIU", sob.filter(function (x) { return x.d > 0; }).slice(0, 5)], ["MAIS CAIU", des.filter(function (x) { return x.d < 0; }).slice(0, 5)]].forEach(function (bl, j) {
        var y0 = 120 + j * 290;
        o += t(650, y0, bl[0], { s: 16, b: true, c: "#c9d6e6", ls: 1 });
        if (!bl[1].length) o += t(650, y0 + 34, "nenhum estado", { s: 14, c: C.apagado });
        bl[1].forEach(function (x, i) {
          var y = y0 + 14 + i * 48;
          o += r(650, y, 557, 42, "rgba(8,14,32,0.84)", 6) + r(650, y, 7, 42, corDifAbst(x.d), 3);
          o += t(670, y + 27, DEP_UF[x.k], { s: 16, b: true, max: 230 }) + t(1000, y + 27, pct(x.p1) + " → " + pct(x.p2), { s: 13, c: C.apagado, a: "end" });
          o += t(1195, y + 28, ppS(x.d), { s: 19, b: true, a: "end" });
        });
      });
      return svg(W, H, o + t(73, 708, P.fonte + (da.f2.br && da.f2.br.andamento === "f" ? "" : " (parcial: só seções já totalizadas)"), { s: 11, c: C.apagado2 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, P.titV, { s: 28, b: true, ls: 1 }) + t(53, 106, da.b1 != null && da.b2 != null ? "Brasil: " + pct(da.b1) + " → " + pct(da.b2) : "por estado", { s: 14, c: C.apagado }) + seloV(W, seloDe(da.f2));
    o += mapaCor(70, 165, 0.65, corM, { rotulos: true, fonte: 10, apagado: "#1c2a40" });
    FAIXAS_DIFABST.forEach(function (fx, i) { o += r(40 + (i % 3) * 160, 600 + Math.floor(i / 3) * 20, 12, 12, fx[2], 2) + t(58 + (i % 3) * 160, 610 + Math.floor(i / 3) * 20, fx[3], { s: 10, c: C.apagado }); });
    [["SUBIU", sob.filter(function (x) { return x.d > 0; }).slice(0, 4)], ["CAIU", des.filter(function (x) { return x.d < 0; }).slice(0, 4)]].forEach(function (bl, j) {
      var y0 = 670 + j * 140;
      o += t(35, y0, bl[0], { s: 13, b: true, c: "#c9d6e6", ls: 1 });
      bl[1].forEach(function (x, i) { var y = y0 + 8 + i * 30; o += r(35, y, 470, 26, "rgba(8,14,32,0.84)", 4) + r(35, y, 6, 26, corDifAbst(x.d), 2) + t(50, y + 18, DEP_UF[x.k], { s: 13, b: true, max: 250 }) + t(495, y + 18, ppS(x.d), { s: 14, b: true, a: "end" }); });
    });
    return svg(W, H, o + t(35, 950, P.fonteV, { s: 10, c: C.apagado2 }));
  }
  G["abstuf-h"] = function () { return telaAbstUf(false); };
  G["abstuf-v"] = function () { return telaAbstUf(true); };

  // ---- ABSTENCAO 1o x 2o: BRASIL, REGIOES E OS 27 ESTADOS (tabela) -----------
  // Regiao = soma da abstencao / soma (comparecimento + abstencao) dos estados
  // (mesma conta do TSE, so secoes totalizadas). Regiao incompleta fica "—".
  function abstConta(x) {
    var e = x && x.eleitorado; if (!e) return null;
    var a = +e.abstencao, c = +e.comparecimento;
    return isFinite(a) && isFinite(c) && a + c > 0 ? { a: a, c: c } : null;
  }
  function abstRegioes() {
    var f1 = fontePres(true), f2 = fontePres(false);
    if (!f1.guardado || !f2.br) return null;
    function uf1(k) { var x = f1.uf(k), y = f2.uf(k), p1 = x && x.eleitorado ? x.eleitorado.pct_abstencao : null, p2 = y && y.eleitorado ? y.eleitorado.pct_abstencao : null;
      if (p1 == null || p2 == null || !(y.secoes && y.secoes.pct > 0)) return { k: k, d: null, fim: false };
      return { k: k, p1: +p1, p2: +p2, d: p2 - p1, fim: y.andamento === "f" || y.secoes.pct >= 100 }; }
    function soma(f, ks) { var a = 0, c = 0; for (var i = 0; i < ks.length; i++) { var z = abstConta(f.uf(ks[i])); if (!z) return null; a += z.a; c += z.c; } return 100 * a / (a + c); }
    var regs = DEP_REGIOES.map(function (rg) {
      var p1 = soma(f1, rg[1]), p2 = soma(f2, rg[1]), ufs = rg[1].map(uf1);
      ufs.sort(function (a, b) { return (b.d == null ? -99 : b.d) - (a.d == null ? -99 : a.d); });
      return { nome: rg[0], p1: p1, p2: p2, d: p1 != null && p2 != null ? p2 - p1 : null, ufs: ufs };
    });
    var b1 = f1.br.eleitorado ? f1.br.eleitorado.pct_abstencao : null, b2 = f2.br.eleitorado ? f2.br.eleitorado.pct_abstencao : null;
    if (b1 == null || b2 == null) return null;
    return { regs: regs, b1: +b1, b2: +b2, d: b2 - b1, f2: f2, parcial: f2.br.andamento !== "f" };
  }
  function corPP(d) { return d == null ? C.apagado : Math.abs(d) < 0.005 ? C.texto : d > 0 ? "#ffa94d" : "#69db7c"; }
  function ppC(d) { return d == null ? "—" : (d > 0 ? "+" : d < 0 ? "−" : "") + Number(Math.abs(d)).toFixed(2).replace(".", ","); }
  function pctOu(v) { return v == null ? "—" : pct(v); }
  function telaAbstReg(v) {
    var da = abstRegioes(), W = v ? 540 : 1280, H = v ? 960 : 720, o, tit = "ABSTENÇÃO 1º × 2º TURNO";
    if (!da) {
      o = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, "ABSTENÇÃO 1º × 2º", { s: 28, b: true, ls: 1 }) : t(73, 57, tit, { s: 36, b: true, ls: 1 });
      return svg(W, H, marcaVazio() + o + t(W / 2, H / 2, "disponível no 2º turno (compara com o 1º turno guardado)", { s: v ? 15 : 22, c: C.apagado, a: "middle", max: W - 60 }));
    }
    var nota = da.parcial ? "2º turno PARCIAL (urnas " + pct(da.f2.br.secoes ? da.f2.br.secoes.pct : 0) + "): só seções já totalizadas" : "";
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, "% do eleitorado que não votou · 1º turno → 2º turno · diferença em pontos percentuais (p.p.)", { s: 15, c: C.apagado, max: 660 }) + seloH(W, seloDe(da.f2));
      o += r(73, 100, 1134, 52, "rgba(8,14,32,0.84)", 8) + r(73, 100, 7, 52, corPP(da.d), 3) + t(96, 134, "BRASIL", { s: 20, b: true, ls: 2 });
      o += t(330, 134, "1º turno " + pct(da.b1) + "   →   2º turno " + pct(da.b2), { s: 19, b: true, c: "#c9d6e6" });
      o += t(1190, 136, ppC(da.d) + " p.p.", { s: 26, b: true, a: "end", c: corPP(da.d) });
      da.regs.forEach(function (rg, i) {
        var x = 73 + i * 228, w = 222;
        o += r(x, 162, w, 84, "rgba(8,14,32,0.84)", 8) + r(x, 162, w, 6, corPP(rg.d), 3);
        o += t(x + 12, 190, REG_NOME[rg.nome], { s: 16, b: true, ls: 1, max: w - 24 });
        o += t(x + 12, 214, pctOu(rg.p1) + " → " + pctOu(rg.p2), { s: 14, c: "#c9d6e6", max: w - 24 });
        o += t(x + w - 12, 238, ppC(rg.d) + " p.p.", { s: 20, b: true, a: "end", c: corPP(rg.d) });
        rg.ufs.forEach(function (u, j) {
          var y = 254 + j * 48;
          o += r(x, y, w, 44, j % 2 ? "rgba(8,14,32,0.70)" : "rgba(8,14,32,0.84)", 5) + r(x, y, 5, 44, corPP(u.d), 2);
          o += t(x + 14, y + 20, u.k.toUpperCase(), { s: 16, b: true }) + t(x + 14, y + 37, u.d == null ? "sem dado" : pct(u.p1) + " → " + pct(u.p2), { s: 11, c: C.apagado, max: 140 });
          o += t(x + w - 10, y + 29, ppC(u.d), { s: 18, b: true, a: "end", c: corPP(u.d) });
        });
      });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — Presidente, abstenção sobre o eleitorado; 1º turno final × 2º turno" + (nota ? " · " + nota : "") + " · laranja = abstenção subiu, verde = caiu", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "ABSTENÇÃO 1º × 2º", { s: 28, b: true, ls: 1 }) + t(53, 106, "% do eleitorado que não votou · p.p." + (da.parcial ? " · parcial" : ""), { s: 14, c: C.apagado, max: 330 }) + seloV(W, seloDe(da.f2));
    o += r(35, 166, 470, 58, "rgba(8,14,32,0.84)", 8) + r(35, 166, 6, 58, corPP(da.d), 3) + t(52, 192, "BRASIL", { s: 17, b: true, ls: 2 }) + t(52, 214, pct(da.b1) + " → " + pct(da.b2), { s: 13, c: "#c9d6e6" });
    o += t(493, 204, ppC(da.d) + " p.p.", { s: 24, b: true, a: "end", c: corPP(da.d) });
    da.regs.forEach(function (rg, i) {
      var y = 232 + i * 46;
      o += r(35, y, 470, 40, "rgba(8,14,32,0.84)", 6) + r(35, y, 6, 40, corPP(rg.d), 2) + t(52, y + 26, REG_NOME[rg.nome], { s: 15, b: true, ls: 1 });
      o += t(330, y + 26, pctOu(rg.p1) + " → " + pctOu(rg.p2), { s: 12, c: C.apagado, a: "end" }) + t(493, y + 27, ppC(rg.d), { s: 18, b: true, a: "end", c: corPP(rg.d) });
    });
    var todos = []; da.regs.forEach(function (rg) { todos = todos.concat(rg.ufs); });
    todos.sort(function (a, b) { return (b.d == null ? -99 : b.d) - (a.d == null ? -99 : a.d); });
    o += t(35, 488, "ESTADOS (do que mais subiu ao que mais caiu)", { s: 12, b: true, c: "#c9d6e6", ls: 1 });
    todos.forEach(function (u, i) {
      var col = Math.floor(i / 9), li = i % 9, x = 35 + col * 159, y = 498 + li * 48, w = 153;
      o += r(x, y, w, 42, "rgba(8,14,32,0.84)", 5) + r(x, y, 5, 42, corPP(u.d), 2);
      o += t(x + 12, y + 20, u.k.toUpperCase(), { s: 15, b: true }) + t(x + 12, y + 37, u.d == null ? "sem dado" : Number(u.p1).toFixed(1).replace(".", ",") + "→" + Number(u.p2).toFixed(1).replace(".", ","), { s: 10, c: C.apagado, max: 80 });
      o += t(x + w - 8, y + 29, ppC(u.d), { s: 15, b: true, a: "end", c: corPP(u.d) });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — abstenção 1º × 2º turno · laranja subiu, verde caiu", { s: 10, c: C.apagado2 }));
  }
  G["abstreg-h"] = function () { return telaAbstReg(false); };
  G["abstreg-v"] = function () { return telaAbstReg(true); };

  // ---- COMPARECIMENTO 1o x 2o TURNO DESDE 2002 --------------------------------
  // Anos anteriores: comparativo-config.js (TSE). 2026: ao vivo do TSE quando
  // ha o 1o turno guardado e o 2o turno com 100% das urnas.
  function comparecAnos() {
    var cfg = ((window.GCTSE_COMPARATIVO || {}).comparecimento || []).map(function (x) { return { ano: +x.ano, t1: +x.t1, t2: +x.t2, vivo: false }; });
    var f1 = fontePres(true), f2 = fontePres(false), e1 = f1.guardado && f1.br ? f1.br.eleitorado : null, e2 = f2.br ? f2.br.eleitorado : null;
    var anoAtual = +String((D().tse || {}).ciclo || "").replace(/\D/g, "") || 0;
    if (anoAtual && e1 && e2 && +e1.comparecimento > 0 && +e2.comparecimento > 0 && f2.turno === 2 && f2.br.secoes && f2.br.secoes.pct >= 100) {
      cfg = cfg.filter(function (x) { return x.ano !== anoAtual; });
      cfg.push({ ano: anoAtual, t1: +e1.comparecimento, t2: +e2.comparecimento, vivo: true });
    }
    cfg = cfg.filter(function (x) { return x.ano > 0 && x.t1 > 0 && x.t2 > 0; }).sort(function (a, b) { return a.ano - b.ano; });
    cfg.forEach(function (x) { x.d = x.t2 - x.t1; x.p = 100 * x.d / x.t1; });
    return cfg;
  }
  function pctS(v) { return (v > 0 ? "+" : v < 0 ? "−" : "") + Number(Math.abs(v)).toFixed(2).replace(".", ",") + "%"; }
  function telaComparec(v) {
    var ls = comparecAnos(), W = v ? 540 : 1280, H = v ? 960 : 720, o, f = fontePres(false);
    var tit = "COMPARECIMENTO ÀS URNAS DESDE 2002", sub = "eleitores que votaram no 1º e no 2º turno (Presidente) · diferença do 2º para o 1º";
    if (ls.length) tit = "COMPARECIMENTO ÀS URNAS DESDE " + ls[0].ano;
    if (!ls.length) {
      o = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, "COMPARECIMENTO", { s: 28, b: true, ls: 1 }) : t(73, 57, tit, { s: 34, b: true, ls: 1 });
      return svg(W, H, marcaVazio() + o + t(W / 2, H / 2, "falta a tabela em web\\comparativo-config.js", { s: v ? 15 : 22, c: C.apagado, a: "middle" }));
    }
    var maxP = 0.5; ls.forEach(function (x) { maxP = Math.max(maxP, Math.abs(x.p)); });
    var ultimo = ls[ls.length - 1], vivo = ls.some(function (x) { return x.vivo; });
    var corD = function (d) { return d > 0 ? "#69db7c" : d < 0 ? "#ff8787" : C.texto; };
    var fonte = "Fonte: TSE — comparecimento (eleitores que votaram) no 1º e no 2º turno para Presidente" + (vivo ? " · " + ultimo.ano + ": boletim do TSE" : "");
    if (!v) {
      o = t(73, 57, tit, { s: 30, b: true, ls: 1, max: 690 }) + t(73, 85, sub, { s: 15, c: C.apagado, max: 700 }) + seloH(W, seloDe(f));
      var cx = [73, 220, 450, 680, 900], top = 104, hl = Math.min(74, Math.floor(560 / ls.length));
      o += r(73, top, 1134, 44, "rgba(8,14,32,0.92)", 6);
      [["ANO", 92, "start"], ["VOTARAM NO 1º TURNO", 420, "end"], ["VOTARAM NO 2º TURNO", 650, "end"], ["DIFERENÇA (2º − 1º)", 875, "end"], ["VARIAÇÃO", 1188, "end"]].forEach(function (c) { o += t(c[1], top + 28, c[0], { s: 13, b: true, c: "#c9d6e6", ls: 1, a: c[2] }); });
      var zx = 1010, bw = 100;
      ls.forEach(function (x, i) {
        var y = top + 52 + i * hl, eu = x === ultimo, h = hl - 6;
        o += r(73, y, 1134, h, eu ? "rgba(43,132,255,0.22)" : i % 2 ? "rgba(8,14,32,0.70)" : "rgba(8,14,32,0.84)", 6) + (eu ? r(73, y, 7, h, C.destaque, 3) : "");
        var ym = y + h / 2 + 9;
        o += t(96, ym, String(x.ano), { s: 26, b: true });
        o += t(420, ym, inteiro(x.t1), { s: 24, b: eu, c: eu ? C.texto : "#dbe4ef", a: "end" }) + t(650, ym, inteiro(x.t2), { s: 24, b: eu, c: eu ? C.texto : "#dbe4ef", a: "end" });
        o += t(875, ym, sinalVotos(x.d), { s: 24, b: true, c: corD(x.d), a: "end" });
        var w = bw * Math.abs(x.p) / maxP;
        o += r(zx - 1, y + 10, 2, h - 20, "rgba(255,255,255,0.35)", 1) + (w > 0 ? r(x.p >= 0 ? zx + 1 : zx - 1 - w, y + h / 2 - 7, Math.max(3, w), 14, corD(x.d), 3) : "");
        o += t(1188, ym, pctS(x.p), { s: 22, b: true, c: corD(x.d), a: "end" });
      });
      return svg(W, H, o + t(73, 708, fonte + " · verde = mais gente votou no 2º turno", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "COMPARECIMENTO", { s: 28, b: true, ls: 1 }) + t(53, 106, "1º × 2º turno desde " + ls[0].ano + " · Presidente", { s: 14, c: C.apagado }) + seloV(W, seloDe(f));
    var hv = Math.min(104, Math.floor(740 / ls.length));
    ls.forEach(function (x, i) {
      var y = 166 + i * hv, h = hv - 8, eu = x === ultimo;
      o += r(35, y, 470, h, eu ? "rgba(43,132,255,0.22)" : "rgba(8,14,32,0.84)", 8) + (eu ? r(35, y, 6, h, C.destaque, 3) : "");
      o += t(52, y + 34, String(x.ano), { s: 24, b: true }) + t(493, y + 34, pctS(x.p), { s: 22, b: true, a: "end", c: corD(x.d) });
      o += t(52, y + 62, "1º " + inteiro(x.t1) + "  →  2º " + inteiro(x.t2), { s: 14, c: "#c9d6e6", max: 300 }) + t(493, y + 62, sinalVotos(x.d), { s: 16, b: true, a: "end", c: corD(x.d) });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — comparecimento no 1º e no 2º turno", { s: 10, c: C.apagado2 }));
  }
  G["comparec-h"] = function () { return telaComparec(false); };
  G["comparec-v"] = function () { return telaComparec(true); };

  // ---- 2o TURNO: 2022 x 2026 (Presidente, % por partido em cada estado) ------
  // 2022: boletim do 2o turno de 2022 que o TSE mantem publicado (ESTADOS.bat,
  // ref2022_2t). 2026: ao vivo. Compara o PARTIDO (os candidatos podem ser
  // outros); partido que nao disputou o 2o turno de 2022 aparece com "—".
  function ref22() { var x = (window.GCTSE_ESTADOS || {}).ref2022_2t; return x && x.br ? x : null; }
  function comp22(x26, r22, sgs) {
    var cs = x26 ? candidatos(x26) : [];
    return sgs.map(function (sg) {
      var c = cs.filter(function (k) { return String(k.partido).toUpperCase() === sg; })[0];
      var a = r22 && r22[sg] != null ? +r22[sg] : null, b = c && c.votos > 0 ? +c.pct : null;
      return { sg: sg, c: c, p22: a, p26: b, d: a != null && b != null ? b - a : null };
    });
  }
  function difPP(d, curto) {
    if (d == null) return "";
    if (Math.abs(d) < 0.05) return "=";
    if (curto) return (d > 0 ? "▲ +" : "▼ −") + Number(Math.abs(d)).toFixed(1).replace(".", ",");
    return (d > 0 ? "▲ +" : d < 0 ? "▼ −" : "") + Number(Math.abs(d)).toFixed(1).replace(".", ",") + " p.p.";
  }
  function telaT22(v) {
    var f = fontePres(false), R = ref22(), W = v ? 540 : 1280, H = v ? 960 : 720, o, tit = "2º TURNO: 2022 × 2026";
    var cab = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 28, b: true, ls: 1, max: 450 }) + t(53, 106, "Presidente · % por partido", { s: 14, c: C.apagado }) + seloV(W, seloDe(f))
                : t(73, 57, tit, { s: 36, b: true, ls: 1 }) + t(73, 85, "Presidente · % dos votos válidos de cada partido no 2º turno · " + subtitulo(), { s: 16, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
    if (f.turno !== 2) return svg(W, H, marcaVazio() + cab + t(W / 2, H / 2, "disponível no 2º turno", { s: v ? 18 : 24, c: C.apagado, a: "middle" }));
    if (!R) return svg(W, H, marcaVazio() + cab + t(W / 2, H / 2, "aguardando o 2º turno de 2022 do TSE (ESTADOS.bat)", { s: v ? 16 : 22, c: C.apagado, a: "middle", max: W - 60 }));
    var cs = f.br ? candidatos(f.br) : [], sgs = cs.slice(0, 2).map(function (c) { return String(c.partido).toUpperCase(); });
    var brc = comp22(f.br, R.br, sgs), ufs = Object.keys(DEP_UF).sort(function (a, b) { return DEP_UF[a].localeCompare(DEP_UF[b], "pt-BR"); });
    function celula(x, y, it, fs, larg) {
      var cc = it.c ? cor(it.c) : C.outros, oo = r(x, y - fs + 1, 5, fs + 2, cc, 2);
      var n1 = function (v0) { return v0 != null ? Number(v0).toFixed(1).replace(".", ",") : "—"; };
      oo += t(x + 10, y, n1(it.p22) + " → " + n1(it.p26), { s: fs, b: true, max: larg * 0.6 });
      if (it.d != null) oo += t(x + larg, y, difPP(it.d, true), { s: fs - 1, b: true, a: "end", c: Math.abs(it.d) < 0.05 ? C.apagado : it.d > 0 ? "#69db7c" : "#ff8787" });
      return oo;
    }
    if (!v) {
      o = cab + r(73, 100, 1134, 60, "rgba(8,14,32,0.84)", 8) + t(93, 137, "BRASIL", { s: 18, b: true, ls: 2 });
      brc.forEach(function (it, i) {
        var x = 300 + i * 450, nm = it.c ? nomeCurto(it.c) + " (" + it.sg + ")" : it.sg, n22 = R.br["_nome_" + it.sg];
        o += r(x, 112, 6, 36, it.c ? cor(it.c) : C.outros, 2) + t(x + 14, 128, nm, { s: 14, b: true, max: 250 }) + t(x + 14, 148, "2022: " + (n22 || "—"), { s: 11, c: C.apagado, max: 250 });
        o += t(x + 420, 128, (it.p22 != null ? pct1(it.p22) : "—") + " → " + (it.p26 != null ? pct1(it.p26) : "—"), { s: 16, b: true, a: "end" }) +
          t(x + 420, 150, difPP(it.d), { s: 14, b: true, a: "end", c: it.d >= 0 ? "#69db7c" : "#ff8787" });
      });
      [0, 1].forEach(function (col) {
        var x = 73 + col * 575;
        o += t(x + 6, 186, "ESTADO", { s: 10, b: true, c: C.apagado, ls: 1 });
        sgs.forEach(function (sg, i) { o += t(x + 150 + i * 205, 186, sg + "  2022 → 2026 (%)", { s: 10, b: true, c: C.apagado, ls: 1 }); });
      });
      ufs.forEach(function (k, i) {
        var col = i < 14 ? 0 : 1, li = col ? i - 14 : i, x = 73 + col * 575, y = 212 + li * 34;
        o += r(x, y - 20, 559, 30, li % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 3) + t(x + 6, y, DEP_UF[k], { s: 12, b: true, max: 136 });
        comp22(f.uf(k), (R.ufs || {})[k], sgs).forEach(function (it, j) { o += celula(x + 150 + j * 205, y, it, 13, 195); });
      });
      return svg(W, H, o + t(73, 706, "Fonte: TSE — 2º turno de 2022 (eleição " + R.eleicao + ") e 2026 ao vivo. Compara o partido, não o candidato.", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = cab + r(35, 160, 470, 62, "rgba(8,14,32,0.84)", 8) + t(50, 182, "BRASIL", { s: 13, b: true, ls: 2 });
    brc.forEach(function (it, i) { o += celula(50 + i * 230, 210, it, 13, 215); });
    o += t(41, 246, "UF", { s: 10, b: true, c: C.apagado });
    sgs.forEach(function (sg, i) { o += t(80 + i * 215, 246, sg + " 2022 → 2026 (%)", { s: 10, b: true, c: C.apagado }); });
    ufs.forEach(function (k, i) {
      var y = 268 + i * 24.5;
      o += r(35, y - 16, 470, 22, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 3) + t(41, y, k.toUpperCase(), { s: 11, b: true });
      comp22(f.uf(k), (R.ufs || {})[k], sgs).forEach(function (it, j) { o += celula(78 + j * 215, y, it, 11, 205); });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — 2º turno 2022 e 2026 · compara o partido", { s: 10, c: C.apagado2 }));
  }
  G["turno22-h"] = function () { return telaT22(false); };
  G["turno22-v"] = function () { return telaT22(true); };

  // ---- PRESIDENTE NAS CAPITAIS ----------------------------------------------
  // Boletim de cada capital (municipio do TSE), lido pelo GRAFICOS.bat.
  // No 2o turno, "VIROU" = quem lidera agora nao liderava no 1o turno.
  function capitais() {
    var cp = D().capitais || {}, c1 = D().capitais_1t || {};
    return Object.keys(DEP_UF).filter(function (k) { return cp[k] && cp[k].tem; }).map(function (k) {
      var x = cp[k], cs = candidatos(x).filter(function (c) { return c.votos > 0; }), l1 = c1[k] ? candidatos(c1[k])[0] : null;
      return { k: k, x: x, cs: cs, lider: cs[0] || null, l1: l1, virou: !!(l1 && cs[0] && String(l1.numero) !== String(cs[0].numero)) };
    }).sort(function (a, b) { return DEP_UF[a.k].localeCompare(DEP_UF[b.k], "pt-BR"); });
  }
  function placarLideres(lista, quem) {
    var n = {}; lista.forEach(function (l) { if (l.lider) n[l.lider.numero] = (n[l.lider.numero] || 0) + 1; });
    var cs = br() ? candidatos(br()).slice(0, 2) : [];
    return cs.map(function (c) { return { c: c, n: n[c.numero] || 0 }; });
  }
  function nomeCap(x) { return String(x.nome || "").toUpperCase(); }
  function telaCapitais(v) {
    var f = fontePres(false), ls = capitais(), W = v ? 540 : 1280, H = v ? 960 : 720, o, pl = placarLideres(ls);
    var sub = "Presidente · " + turnoTxt(f) + " · " + ls.length + (ls.length === 1 ? " capital" : " capitais") + " com boletim";
    if (!v) {
      o = t(73, 57, "PRESIDENTE NAS CAPITAIS", { s: 36, b: true, ls: 1 }) + t(73, 85, sub, { s: 17, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
      if (!ls.length) return svg(W, H, marcaVazio() + o + t(640, 380, "aguardando os boletins das capitais (GRAFICOS.bat)", { s: 22, c: C.apagado, a: "middle" }));
      o += r(73, 100, 1134, 44, "rgba(8,14,32,0.84)", 8);
      pl.forEach(function (p, i) { o += r(93 + i * 400, 111, 6, 22, cor(p.c), 2) + t(107 + i * 400, 130, nomeCurto(p.c) + " lidera em " + p.n + (p.n === 1 ? " capital" : " capitais"), { s: 17, b: true, max: 380 }); });
      ls.forEach(function (l, i) {
        var col = i < 14 ? 0 : 1, li = col ? i - 14 : i, x = 73 + col * 575, y = 178 + li * 37.5, c = l.lider, c2 = l.cs[1];
        o += r(x, y - 23, 559, 33, li % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 3);
        o += t(x + 8, y - 2, nomeCap(l.x), { s: 13, b: true, max: 170 }) + t(x + 8, y + 8, DEP_UF[l.k] + (l.x.secoes ? " · urnas " + pct1(l.x.secoes.pct) : ""), { s: 8, c: C.apagado, max: 170 });
        if (c) o += r(x + 188, y - 16, 5, 20, cor(c), 2) + t(x + 200, y, nomeCurto(c) + " " + pct(c.pct), { s: 14, b: true, max: 205 });
        if (c2) o += t(x + 420, y, nomeCurto(c2).split(" ")[0] + " " + pct(c2.pct), { s: 12, c: C.apagado, max: 100 });
        if (l.virou) o += r(x + 497, y - 14, 56, 18, "#ffffff", 3) + t(x + 525, y, "VIROU", { s: 10, b: true, c: "#0b1220", a: "middle" });
      });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — boletim de Presidente de cada capital" + (f.turno === 2 ? " · VIROU = outro candidato liderava no 1º turno" : ""), { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "NAS CAPITAIS", { s: 30, b: true, ls: 1 }) + t(53, 106, "Presidente · " + turnoTxt(f), { s: 14, c: C.apagado }) + seloV(W, seloDe(f));
    if (!ls.length) return svg(W, H, marcaVazio() + o + t(270, 480, "aguardando as capitais", { s: 18, c: C.apagado, a: "middle" }));
    pl.forEach(function (p, i) { o += r(40 + i * 235, 166, 5, 18, cor(p.c), 2) + t(52 + i * 235, 181, nomeCurto(p.c) + ": " + p.n, { s: 15, b: true, max: 215 }); });
    ls.forEach(function (l, i) {
      var y = 220 + i * 26.5, c = l.lider;
      o += r(35, y - 17, 470, 24, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 3);
      o += t(42, y, nomeCap(l.x) + " (" + l.k.toUpperCase() + ")", { s: 11, b: true, max: 200 });
      if (c) o += r(250, y - 11, 4, 14, cor(c), 2) + t(260, y, nomeCurto(c) + " " + pct(c.pct), { s: 12, b: true, max: 180 });
      if (l.virou) o += t(498, y, "VIROU", { s: 10, b: true, a: "end" });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — Presidente em cada capital", { s: 10, c: C.apagado2 }));
  }
  G["capitais-h"] = function () { return telaCapitais(false); };
  G["capitais-v"] = function () { return telaCapitais(true); };

  // ---- PRESIDENTE NAS MAIORES CIDADES (fora as capitais) ---------------------
  // Boletim de cada cidade (GRAFICOS.bat, lista de nomes no graficos.ps1),
  // em ordem de eleitorado. "VIROU" = outro liderava no 1o turno.
  function cidades() {
    var cp = D().cidades || {}, c1 = D().cidades_1t || {};
    return Object.keys(cp).filter(function (k) { return cp[k] && cp[k].tem; }).map(function (k) {
      var x = cp[k], cs = candidatos(x).filter(function (c) { return c.votos > 0; }), l1 = c1[k] ? candidatos(c1[k])[0] : null;
      return { k: k, uf: String(x.uf || k.split("-")[0]), x: x, cs: cs, lider: cs[0] || null, l1: l1, virou: !!(l1 && cs[0] && String(l1.numero) !== String(cs[0].numero)),
        apt: +((x.eleitorado || {}).aptos) || 0 };
    }).filter(function (l) { return l.lider; }).sort(function (a, b) { return b.apt - a.apt; }).slice(0, 12);
  }
  function telaCidades(v) {
    var f = fontePres(false), ls = cidades(), W = v ? 540 : 1280, H = v ? 960 : 720, o, pl = placarLideres(ls);
    var tit = "NAS MAIORES CIDADES", sub = "Presidente · " + turnoTxt(f) + " · as " + ls.length + " maiores fora as capitais, por eleitorado";
    if (!v) {
      o = t(73, 57, tit, { s: 34, b: true, ls: 1, max: 600 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 600 }) + seloH(W, seloDe(f));
      if (!ls.length) return svg(W, H, marcaVazio() + o + t(640, 380, "aguardando os boletins das cidades (GRAFICOS.bat)", { s: 22, c: C.apagado, a: "middle" }));
      o += r(73, 100, 1134, 44, "rgba(8,14,32,0.84)", 8);
      pl.forEach(function (p, i) { o += r(93 + i * 400, 111, 6, 22, cor(p.c), 2) + t(107 + i * 400, 130, nomeCurto(p.c) + " lidera em " + p.n + (p.n === 1 ? " cidade" : " cidades"), { s: 17, b: true, max: 380 }); });
      ls.forEach(function (l, i) {
        var col = i < 6 ? 0 : 1, li = col ? i - 6 : i, x = 73 + col * 575, y = 160 + li * 88, c = l.lider, c2 = l.cs[1], ap = l.x.secoes ? l.x.secoes.pct : null;
        o += r(x, y, 559, 80, "rgba(8,14,32,0.84)", 8) + r(x, y, 7, 80, cor(c), 3);
        o += t(x + 20, y + 28, nomeCap(l.x), { s: 18, b: true, max: 330 }) + t(x + 20, y + 48, l.uf.toUpperCase() + " · " + inteiro(l.apt) + " eleitores · urnas " + pct1(ap || 0), { s: 12, c: C.apagado, max: 330 });
        o += t(x + 20, y + 70, nomeCurto(c) + " " + pct(c.pct) + (c2 ? "   ·   " + nomeCurto(c2) + " " + pct(c2.pct) : ""), { s: 13, c: "#c9d6e6", max: 420 });
        o += t(x + 545, y + 40, pct(c.pct), { s: 28, b: true, a: "end" });
        if (l.virou) o += r(x + 480, y + 52, 64, 20, "#ffffff", 3) + t(x + 512, y + 67, "VIROU", { s: 12, b: true, c: "#0b1220", a: "middle" });
      });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — boletim de Presidente de cada cidade" + (f.turno === 2 ? " · VIROU = outro candidato liderava ali no 1º turno" : ""), { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "MAIORES CIDADES", { s: 30, b: true, ls: 1 }) + t(53, 106, "Presidente · " + turnoTxt(f) + " · fora as capitais", { s: 14, c: C.apagado }) + seloV(W, seloDe(f));
    if (!ls.length) return svg(W, H, marcaVazio() + o + t(270, 480, "aguardando as cidades", { s: 18, c: C.apagado, a: "middle" }));
    pl.forEach(function (p, i) { o += r(40 + i * 235, 166, 5, 18, cor(p.c), 2) + t(52 + i * 235, 181, nomeCurto(p.c) + ": " + p.n, { s: 15, b: true, max: 215 }); });
    ls.forEach(function (l, i) {
      var y = 210 + i * 58, c = l.lider;
      o += r(35, y, 470, 52, "rgba(8,14,32,0.84)", 6) + r(35, y, 5, 52, cor(c), 2);
      o += t(50, y + 22, nomeCap(l.x) + " (" + l.uf.toUpperCase() + ")", { s: 14, b: true, max: 300 }) + t(50, y + 42, nomeCurto(c) + (l.cs[1] ? " × " + nomeCurto(l.cs[1]) : ""), { s: 11, c: C.apagado, max: 300 });
      o += t(493, y + 32, pct(c.pct), { s: 20, b: true, a: "end" });
      if (l.virou) o += t(400, y + 42, "VIROU", { s: 10, b: true, a: "end" });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — Presidente em cada cidade", { s: 10, c: C.apagado2 }));
  }
  G["cidades-h"] = function () { return telaCidades(false); };
  G["cidades-v"] = function () { return telaCidades(true); };

  // ---- ONDE CADA UM CRESCEU: ganho de votos 1o -> 2o turno POR ESTADO --------
  // So estados com 100% das urnas no 2o turno (antes disso a conta engana).
  function ganhosUf() {
    var f1 = fontePres(true), f2 = fontePres(false);
    if (!f1.guardado || !f2.br || f2.turno !== 2) return null;
    var fin = candidatos(f2.br).slice(0, 2); if (fin.length < 2) return null;
    function vDe(x, n) { var cs = x ? candidatos(x) : []; for (var i = 0; i < cs.length; i++) if (String(cs[i].numero) === String(n)) return +cs[i].votos || 0; return null; }
    var prontos = Object.keys(DEP_UF).filter(function (k) { var x = f2.uf(k); return x && x.secoes && +x.secoes.pct >= 100 && f1.uf(k); });
    var por = fin.map(function (c) {
      var it = prontos.map(function (k) { var a = vDe(f1.uf(k), c.numero), b = vDe(f2.uf(k), c.numero); return a == null || b == null ? null : { k: k, v1: a, v2: b, g: b - a }; }).filter(Boolean);
      it.sort(function (p, q) { return q.g - p.g; });
      return { c: c, it: it };
    });
    return { fin: fin, por: por, n: prontos.length, f2: f2 };
  }
  function telaGanhoUf(v) {
    var gu = ganhosUf(), W = v ? 540 : 1280, H = v ? 960 : 720, o, tit = "ONDE CADA UM CRESCEU";
    var cab = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 28, b: true, ls: 1, max: 450 }) : t(73, 57, tit, { s: 34, b: true, ls: 1, max: 600 });
    if (!gu) return svg(W, H, marcaVazio() + cab + t(W / 2, H / 2, "disponível no 2º turno (compara com o 1º turno guardado)", { s: v ? 15 : 22, c: C.apagado, a: "middle", max: W - 60 }));
    cab += v ? seloV(W, seloDe(gu.f2)) : seloH(W, seloDe(gu.f2));
    if (!gu.n) return svg(W, H, marcaVazio() + cab + t(W / 2, H / 2, "aguardando estados com 100% das urnas no 2º turno", { s: v ? 16 : 24, c: C.apagado, a: "middle", max: W - 60 }));
    var maxG = 1; gu.por.forEach(function (p) { p.it.forEach(function (x) { maxG = Math.max(maxG, Math.abs(x.g)); }); });
    var sub = "1º → 2º turno: votos no 2º menos votos no 1º, por estado · " + gu.n + " de 27 estados com 100% das urnas";
    if (!v) {
      o = cab + t(73, 85, sub, { s: 15, c: C.apagado, max: 600 });
      gu.por.forEach(function (p, j) {
        var X = 73 + j * 575, cc = cor(p.c);
        o += r(X, 104, 559, 46, "rgba(8,14,32,0.84)", 8) + r(X, 104, 559, 5, cc, 3) + t(X + 16, 136, p.c.nome + "  |  " + p.c.partido, { s: 19, b: true, max: 520 });
        p.it.slice(0, 10).forEach(function (x, i) {
          var y = 166 + i * 52, w = 210 * Math.abs(x.g) / maxG;
          o += r(X, y, 559, 46, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 5);
          o += t(X + 14, y + 29, DEP_UF[x.k], { s: 15, b: true, max: 170 });
          o += r(X + 190, y + 17, 210, 14, "rgba(255,255,255,0.08)", 4) + (w > 0 ? r(X + 190, y + 17, Math.max(4, w), 14, x.g >= 0 ? cc : "#ff8787", 4) : "");
          o += t(X + 545, y + 30, sinalVotos(x.g), { s: 17, b: true, a: "end", c: x.g >= 0 ? C.texto : "#ff8787" });
        });
      });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — Presidente, 1º turno (final) × 2º turno, só estados já com 100% das urnas · não mostra de quem veio o voto", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = cab + t(53, 106, "1º → 2º turno · " + gu.n + " estados com 100%", { s: 14, c: C.apagado, max: 450 });
    gu.por.forEach(function (p, j) {
      var Y = 160 + j * 390, cc = cor(p.c);
      o += r(35, Y, 470, 40, "rgba(8,14,32,0.84)", 6) + r(35, Y, 6, 40, cc, 3) + t(52, Y + 27, p.c.nome, { s: 17, b: true, max: 440 });
      p.it.slice(0, 7).forEach(function (x, i) {
        var y = Y + 52 + i * 46, w = 170 * Math.abs(x.g) / maxG;
        o += t(40, y + 22, x.k.toUpperCase(), { s: 15, b: true }) + r(85, y + 10, 170, 14, "rgba(255,255,255,0.08)", 4) + (w > 0 ? r(85, y + 10, Math.max(4, w), 14, x.g >= 0 ? cc : "#ff8787", 4) : "");
        o += t(500, y + 23, sinalVotos(x.g), { s: 16, b: true, a: "end", c: x.g >= 0 ? C.texto : "#ff8787" });
      });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — 1º turno (final) × 2º turno", { s: 10, c: C.apagado2 }));
  }
  G["ganhouf-h"] = function () { return telaGanhoUf(false); };
  G["ganhouf-v"] = function () { return telaGanhoUf(true); };

  // ---- ONDE AINDA HA VOTOS: eleitores das urnas que faltam, por estado -------
  // "faltam" = eleitores das secoes que o TSE ainda nao totalizou (boletim).
  function telaFaltam(v) {
    var f = fontePres(false), b = f.br, W = v ? 540 : 1280, H = v ? 960 : 720, o, tit = "ONDE AINDA HÁ VOTOS";
    var cab = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 28, b: true, ls: 1, max: 450 }) : t(73, 57, tit, { s: 34, b: true, ls: 1, max: 600 });
    var falt = b && b.eleitorado ? +b.eleitorado.faltam || 0 : 0, pU = b && b.secoes ? +b.secoes.pct || 0 : 0;
    if (!b || !(pU > 0)) return svg(W, H, marcaVazio() + cab + t(W / 2, H / 2, "aguardando a apuração", { s: v ? 16 : 24, c: C.apagado, a: "middle" }));
    cab += v ? seloV(W, seloDe(f)) : seloH(W, seloDe(f));
    var ls = Object.keys(DEP_UF).map(function (k) {
      var x = f.uf(k); if (!x || !x.eleitorado) return null;
      var fa = +x.eleitorado.faltam || 0, cs = candidatos(x).filter(function (c) { return c.votos > 0; });
      return fa > 0 ? { k: k, fa: fa, x: x, l: cs[0] || null, c2: cs[1] || null, comp: (+x.eleitorado.pct_comparec || 0) / 100 } : null;
    }).filter(Boolean).sort(function (p, q) { return q.fa - p.fa; });
    if (!(falt > 0) || !ls.length) return svg(W, H, marcaVazio() + cab + t(W / 2, H / 2, "todas as urnas já apuradas", { s: v ? 18 : 26, c: C.apagado, a: "middle" }));
    var cs = candidatos(b), dif = cs.length >= 2 ? (+cs[0].votos || 0) - (+cs[1].votos || 0) : 0, compB = (+b.eleitorado.pct_comparec || 0) / 100;
    var maxF = ls[0].fa, resumo = "faltam " + inteiro(falt) + " eleitores (≈ " + inteiro(Math.round(falt * compB)) + " votos pelo comparecimento até agora) · diferença hoje: " + inteiro(dif) + " votos";
    if (!v) {
      o = cab + t(73, 85, "Presidente · urnas apuradas " + pct(pU) + " · eleitores das urnas que o TSE ainda não totalizou", { s: 15, c: C.apagado, max: 600 });
      o += r(73, 100, 1134, 40, "rgba(8,14,32,0.84)", 8) + t(93, 127, resumo, { s: 16, b: true, max: 1094 });
      ls.slice(0, 10).forEach(function (L, i) {
        var y = 154 + i * 52, w = 420 * L.fa / maxF, pu = L.x.secoes ? L.x.secoes.pct : null;
        o += r(73, y, 1134, 46, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 5);
        o += t(90, y + 29, DEP_UF[L.k], { s: 16, b: true, max: 200 }) + t(300, y + 29, "urnas " + pct1(pu || 0), { s: 13, c: C.apagado });
        o += r(420, y + 16, 420, 14, "rgba(255,255,255,0.08)", 4) + r(420, y + 16, Math.max(4, w), 14, L.l ? cor(L.l) : C.outros, 4);
        o += t(960, y + 30, inteiro(L.fa), { s: 17, b: true, a: "end" });
        if (L.l) o += r(985, y + 13, 5, 20, cor(L.l), 2) + t(998, y + 29, nomeCurto(L.l) + " " + pct(L.l.pct), { s: 14, b: true, max: 200 });
      });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — eleitores das seções ainda não totalizadas · cor = quem lidera no estado (votos já apurados); não é projeção", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = cab + t(53, 106, "Presidente · urnas " + pct(pU), { s: 14, c: C.apagado });
    o += r(35, 160, 470, 66, "rgba(8,14,32,0.84)", 8) + t(50, 188, "faltam " + inteiro(falt) + " eleitores", { s: 18, b: true, max: 440 }) + t(50, 212, "diferença hoje: " + inteiro(dif) + " votos", { s: 14, c: "#c9d6e6", max: 440 });
    ls.slice(0, 10).forEach(function (L, i) {
      var y = 244 + i * 64, w = 240 * L.fa / maxF;
      o += r(35, y, 470, 58, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 5);
      o += t(48, y + 24, DEP_UF[L.k], { s: 15, b: true, max: 250 }) + t(493, y + 24, inteiro(L.fa), { s: 16, b: true, a: "end" });
      o += r(48, y + 36, 240, 12, "rgba(255,255,255,0.08)", 4) + r(48, y + 36, Math.max(4, w), 12, L.l ? cor(L.l) : C.outros, 4);
      if (L.l) o += t(493, y + 48, nomeCurto(L.l) + " " + pct(L.l.pct), { s: 12, c: "#c9d6e6", a: "end", max: 190 });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — eleitores das seções não totalizadas", { s: 10, c: C.apagado2 }));
  }
  G["faltam-h"] = function () { return telaFaltam(false); };
  G["faltam-v"] = function () { return telaFaltam(true); };

  // ---- BRASILEIROS NO EXTERIOR ----------------------------------------------
  // Total: boletim "zz" do TSE. Por pais: soma dos boletins das cidades do
  // exterior (TSE), agrupadas pelo pais da tabela web\exterior-paises.js.
  function chaveCidade(n) { return String(n || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().trim(); }
  function paisDe(x) { var P = window.GCTSE_EXTERIOR_PAISES || {}; return x.pais ? chaveCidade(x.pais) : (P[chaveCidade(x.nome)] || ""); }
  function exteriorSemPais() { return comoLista(D().exterior).filter(function (x) { return !paisDe(x); }).map(function (x) { return x.nome; }); }
  function agruparExterior(porPais, t1) {
    var g = {};
    comoLista(t1 ? D().exterior_1t : D().exterior).forEach(function (x) {
      var k = porPais ? (paisDe(x) || "OUTROS PAÍSES") : String(x.nome || "").toUpperCase();
      var a = g[k] = g[k] || { nome: k, validos: 0, cs: {}, cidades: 0, aptos: 0, comp: 0 };
      a.cidades++; a.validos += +(x.votos || {}).validos || 0; a.aptos += +(x.eleitorado || {}).aptos || 0; a.comp += +(x.eleitorado || {}).comparecimento || 0;
      candidatos(x).forEach(function (c) { var s = a.cs[c.numero] = a.cs[c.numero] || { nome: c.nome, numero: c.numero, partido: c.partido, votos: 0 }; s.votos += +c.votos || 0; });
    });
    return Object.keys(g).map(function (k) {
      var a = g[k], cs = Object.keys(a.cs).map(function (n) { var c = a.cs[n]; c.pct = a.validos ? 100 * c.votos / a.validos : 0; return c; }).sort(function (p, q) { return q.votos - p.votos; });
      a.lista = cs; return a;
    }).filter(function (a) { return a.validos > 0; }).sort(function (p, q) { return q.validos - p.validos; });
  }
  function caixaExteriorTotal(x, y, w, h, k2) {
    var z = D().exterior_total, f = fontePres(false), o = r(x, y, w, h, "rgba(8,14,32,0.84)", 10);
    o += t(x + 20, y + 32 * k2, "TOTAL NO EXTERIOR", { s: Math.round(16 * k2), b: true, c: "#c9d6e6", ls: 2 });
    if (!z || !z.tem) return o + t(x + w / 2, y + h / 2, "aguardando o boletim do exterior", { s: 16, c: C.apagado, a: "middle" });
    var cs = candidatos(z).slice(0, f.turno === 2 ? 2 : 3);
    cs.forEach(function (c, i) {
      var yy = y + (62 + i * 64) * k2;
      o += r(x + 20, yy, 6, 46 * k2, cor(c), 2) + t(x + 36, yy + 20 * k2, c.nome, { s: Math.round(18 * k2), b: true, max: w - 190 }) +
        t(x + 36, yy + 42 * k2, inteiro(c.votos) + " votos", { s: Math.round(12 * k2), c: C.apagado }) + t(x + w - 20, yy + 36 * k2, pct(c.pct), { s: Math.round(30 * k2), b: true, a: "end" });
    });
    var e = z.eleitorado || {}, yb = y + h - 58 * k2, t1 = ((D().turno1 || {}).ufs || {}).zz;
    // barra dos dois primeiros e, no 2o turno, como foi o 1o turno no exterior
    var yBar = y + (62 + cs.length * 64 + 8) * k2, tot = cs.reduce(function (a0, c) { return a0 + (+c.pct || 0); }, 0) || 1, xx = x + 20;
    cs.forEach(function (c) { var wv = (w - 40) * (+c.pct || 0) / tot; o += r(xx, yBar, Math.max(0, wv - 2), 14 * k2, cor(c), 2); xx += wv; });
    if (f.turno === 2 && t1 && t1.tem && h > 400) {
      var c1s = candidatos(t1).slice(0, 4), y1 = yBar + 56 * k2;
      o += t(x + 20, y1, "1º TURNO NO EXTERIOR", { s: Math.round(13 * k2), b: true, c: C.apagado, ls: 2 });
      c1s.forEach(function (c, i) { var yy = y1 + (26 + i * 30) * k2; o += r(x + 20, yy - 13 * k2, 5, 16 * k2, cor(c), 2) + t(x + 32, yy, c.nome, { s: Math.round(14 * k2), b: true, max: w - 160 }) + t(x + w - 20, yy, pct(c.pct), { s: Math.round(15 * k2), b: true, a: "end", c: "#c9d6e6" }); });
    }
    var z22 = ((ref22() || {}).ufs || {}).zz;
    if (f.turno === 2 && z22) {
      var ps22 = Object.keys(z22).filter(function (k) { return k.charAt(0) !== "_"; }).sort(function (a, b) { return z22[b] - z22[a]; }).slice(0, 2);
      o += t(x + 20, yb - 24 * k2, "2022 (2º turno): " + ps22.map(function (sg) { return sg + " " + pct(z22[sg]); }).join(" · ") + (z22._pc != null ? " · comparecimento " + pct(z22._pc) : ""), { s: Math.round(12 * k2), b: true, c: "#ffd43b", max: w - 40 });
    }
    o += t(x + 20, yb, "comparecimento " + (e.pct_comparec != null ? pct(e.pct_comparec) : "—") + " · abstenção " + (e.pct_abstencao != null ? pct(e.pct_abstencao) : "—"), { s: Math.round(13 * k2), c: "#c9d6e6", max: w - 40 });
    o += t(x + 20, yb + 20 * k2, inteiro(e.aptos) + " eleitores aptos no exterior · urnas " + pct((z.secoes || {}).pct), { s: Math.round(12 * k2), c: C.apagado, max: w - 40 });
    if (f.turno === 2 && t1 && t1.tem && h <= 400) { var c1 = candidatos(t1)[0]; if (c1) o += t(x + 20, yb + 40 * k2, "1º turno no exterior: " + nomeCurto(c1) + " " + pct(c1.pct), { s: Math.round(12 * k2), c: C.apagado, max: w - 40 }); }
    return o;
  }
  function linhasExterior(lista, x, y, w, passo, n, fs, rotulo, l1) {
    var o = t(x, y - passo * 0.55, rotulo, { s: fs - 2, b: true, c: C.apagado, ls: 1 }), m1 = {};
    (l1 || []).forEach(function (a) { m1[a.nome] = a.lista[0]; });
    lista.slice(0, n).forEach(function (a, i) {
      var yy = y + i * passo, c = a.lista[0], c2 = a.lista[1], p1 = m1[a.nome];
      o += r(x - 6, yy - passo * 0.62, w + 12, passo - 4, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 3);
      o += t(x, yy, a.nome, { s: fs, b: true, max: w * 0.36 }) + t(x, yy + fs * 0.95, inteiro(a.validos) + " votos válidos" + (a.cidades > 1 ? " · " + a.cidades + " cidades" : ""), { s: fs - 5, c: C.apagado, max: w * 0.36 });
      if (c) o += r(x + w * 0.39, yy - fs * 0.8, 5, fs + 2, cor(c), 2) + t(x + w * 0.39 + 12, yy, nomeCurto(c) + " " + pct(c.pct), { s: fs, b: true, max: w * 0.36 });
      // 2o turno: quem liderava ali no 1o turno (e VIROU, se mudou)
      if (c && p1) {
        var virou = String(p1.numero) !== String(c.numero);
        o += t(x + w * 0.39 + 12, yy + fs * 0.95, "1º turno: " + nomeCurto(p1) + " " + pct(p1.pct), { s: fs - 5, c: virou ? "#ffd43b" : C.apagado, max: w * 0.36 });
        if (virou) o += r(x + w * 0.79, yy - fs * 0.85, 52, fs + 2, "#ffd43b", 3) + t(x + w * 0.79 + 26, yy + 1, "VIROU", { s: fs - 6, b: true, c: "#0b1220", a: "middle" });
      }
      if (c2 && !l1) o += t(x + w, yy, nomeCurto(c2) + " " + pct(c2.pct), { s: fs - 2, c: C.apagado, a: "end", max: w * 0.22 });
    });
    return o;
  }
  function telaExterior(v, porPais) {
    var f = fontePres(false), ls = agruparExterior(porPais), W = v ? 540 : 1280, H = v ? 960 : 720, o, nCid = +D().exterior_cidades || 0;
    var venc = {}; ls.forEach(function (a) { if (a.nome !== "OUTROS PAÍSES" && a.lista[0]) venc[a.lista[0].numero] = (venc[a.lista[0].numero] || 0) + 1; });
    var csBr = br() ? candidatos(br()).slice(0, 2) : [], nGrupos = ls.filter(function (a) { return a.nome !== "OUTROS PAÍSES"; }).length;
    var resumo = porPais && nGrupos ? csBr.map(function (c) { return nomeCurto(c) + " vence em " + (venc[c.numero] || 0); }).join(" · ") + " de " + nGrupos + " países" : "";
    var tit = porPais ? "BRASILEIROS NO EXTERIOR" : "EXTERIOR — POR CIDADE";
    var rod = "Fonte: TSE — votos do exterior (boletim ZZ e de cada cidade)" + (porPais ? "; país de cada cidade: tabela exterior-paises.js" : "") + (nCid ? " · " + comoLista(D().exterior).length + " de " + nCid + " cidades lidas" : "");
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1, max: 667 }) + t(73, 85, "Presidente · " + turnoTxt(f) + (resumo ? " · " + resumo : ""), { s: 16, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
      o += caixaExteriorTotal(73, 106, 440, 568, 1);
      o += r(533, 106, 674, 568, "rgba(8,14,32,0.60)", 10);
      if (!ls.length) o += t(870, 390, "aguardando os boletins das cidades", { s: 18, c: C.apagado, a: "middle" });
      else o += linhasExterior(ls, 553, 160, 634, 42.5, 12, 17, porPais ? "PAÍSES COM MAIS VOTOS" : "CIDADES COM MAIS VOTOS", f.turno === 2 ? agruparExterior(porPais, true) : null);
      return svg(W, H, o + t(73, 704, rod, { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, porPais ? "NO EXTERIOR" : "EXTERIOR: CIDADES", { s: 30, b: true, ls: 1 }) + t(53, 106, "Presidente · " + turnoTxt(f), { s: 14, c: C.apagado }) + seloV(W, seloDe(f));
    o += caixaExteriorTotal(35, 160, 470, 330, 0.95);
    if (ls.length) o += linhasExterior(ls, 45, 540, 450, 40, 10, 15, porPais ? "PAÍSES COM MAIS VOTOS" : "CIDADES COM MAIS VOTOS", f.turno === 2 ? agruparExterior(porPais, true) : null);
    return svg(W, H, o + t(35, 950, "Fonte: TSE" + (porPais ? " · país: tabela da emissora" : ""), { s: 10, c: C.apagado2 }));
  }
  G["exterior-h"] = function () { return telaExterior(false, true); };
  G["exterior-v"] = function () { return telaExterior(true, true); };
  G["excidades-h"] = function () { return telaExterior(false, false); };
  G["excidades-v"] = function () { return telaExterior(true, false); };

  // ---- EXTERIOR: 1o x 2o TURNO --------------------------------------------
  // 1o turno: boletim ZZ guardado (turno1.ufs.zz); 2o: exterior_total ao vivo.
  function telaExComp(v) {
    var W = v ? 540 : 1280, H = v ? 960 : 720, f = fontePres(false), z2 = D().exterior_total, z1 = ((D().turno1 || {}).ufs || {}).zz, o;
    var tit = v ? "EXTERIOR: 1º × 2º" : "EXTERIOR: 1º × 2º TURNO";
    var cab = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 28, b: true, ls: 1, max: 450 }) : t(73, 57, tit, { s: 36, b: true, ls: 1, max: 600 });
    if (f.turno !== 2 || !z1 || !z1.tem || !z2 || !z2.tem) return svg(W, H, marcaVazio() + cab + t(W / 2, H / 2, "disponível no 2º turno (compara com o 1º turno guardado do exterior)", { s: v ? 15 : 22, c: C.apagado, a: "middle", max: W - 60 }));
    cab += v ? seloV(W, seloDe({ br: z2 })) : seloH(W, seloDe({ br: z2 }));
    var fin = candidatos(z2).slice(0, 2), e1 = z1.eleitorado || {}, e2 = z2.eleitorado || {}, v1 = z1.votos || {}, v2 = z2.votos || {}, pu = (z2.secoes || {}).pct;
    function vDe(x, n) { var cs = candidatos(x); for (var i = 0; i < cs.length; i++) if (String(cs[i].numero) === String(n)) return cs[i]; return null; }
    var linhas = [["Comparecimento", e1.pct_comparec, e2.pct_comparec], ["Abstenção", e1.pct_abstencao, e2.pct_abstencao], ["Brancos", v1.pct_brancos, v2.pct_brancos], ["Nulos", v1.pct_nulos, v2.pct_nulos]];
    var parcial = !(pu >= 100), sub = "Presidente · brasileiros no exterior · urnas do 2º turno " + pct(pu) + (parcial ? " (o ganho de votos só vale com 100%)" : "");
    if (!v) {
      o = cab + t(73, 85, sub, { s: 16, c: C.apagado, max: 600 });
      fin.forEach(function (c, i) {
        var X = 73 + i * 575, a = vDe(z1, c.numero), cc = cor(c), g = a ? (+c.votos || 0) - (+a.votos || 0) : null;
        o += r(X, 106, 559, 250, "rgba(8,14,32,0.84)", 10) + r(X, 106, 559, 7, cc, 4);
        o += t(X + 20, 150, c.nome, { s: 22, b: true, max: 380 }) + t(X + 20, 172, c.partido, { s: 14, c: C.apagado });
        o += t(X + 20, 222, "1º turno", { s: 13, c: C.apagado }) + t(X + 20, 252, a ? pct(a.pct) : "—", { s: 28, b: true, c: "#c9d6e6" }) + t(X + 20, 274, a ? inteiro(a.votos) + " votos" : "", { s: 13, c: C.apagado });
        o += t(X + 290, 222, "2º turno", { s: 13, c: C.apagado }) + t(X + 290, 252, pct(c.pct), { s: 34, b: true }) + t(X + 290, 274, inteiro(c.votos) + " votos", { s: 13, c: C.apagado });
        if (g != null && !parcial) o += t(X + 20, 330, "ganhou " + sinalVotos(g) + " votos" + (a && a.votos ? " (" + (g >= 0 ? "+" : "−") + pct1(Math.abs(100 * g / a.votos)) + ")" : ""), { s: 18, b: true, c: g >= 0 ? "#69db7c" : "#ff8787", max: 520 });
        else if (g != null) o += t(X + 20, 330, "ganho de votos: aguardando 100% das urnas do exterior", { s: 14, c: C.apagado, max: 520 });
      });
      o += r(73, 376, 1134, 300, "rgba(8,14,32,0.84)", 10) + t(93, 412, "", {}) + t(600, 412, "1º TURNO", { s: 13, b: true, c: C.apagado, a: "end", ls: 1 }) + t(820, 412, "2º TURNO", { s: 13, b: true, c: C.apagado, a: "end", ls: 1 }) + t(1050, 412, "DIFERENÇA", { s: 13, b: true, c: C.apagado, a: "end", ls: 1 });
      linhas.forEach(function (L, i) {
        var y = 470 + i * 52, d = L[1] != null && L[2] != null ? L[2] - L[1] : null;
        o += t(110, y, L[0], { s: 22, b: true }) + t(600, y, pct(L[1]), { s: 22, c: "#c9d6e6", a: "end" }) + t(820, y, pct(L[2]), { s: 24, b: true, a: "end" }) + t(1050, y, d == null ? "—" : difPP(d), { s: 20, b: true, a: "end", c: Math.abs(d || 0) < 0.05 ? C.apagado : "#ffd43b" });
      });
      return svg(W, H, o + t(73, 704, "Fonte: TSE — boletim do exterior (ZZ): 1º turno final × 2º turno · eleitores aptos no exterior: " + inteiro(e2.aptos), { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = cab + t(53, 106, "Presidente · urnas " + pct(pu), { s: 14, c: C.apagado });
    fin.forEach(function (c, i) {
      var Y = 160 + i * 200, a = vDe(z1, c.numero), cc = cor(c), g = a ? (+c.votos || 0) - (+a.votos || 0) : null;
      o += r(35, Y, 470, 186, "rgba(8,14,32,0.84)", 8) + r(35, Y, 7, 186, cc, 3) + t(55, Y + 34, c.nome, { s: 20, b: true, max: 430 });
      o += t(55, Y + 70, "1º turno", { s: 12, c: C.apagado }) + t(55, Y + 100, a ? pct(a.pct) : "—", { s: 24, b: true, c: "#c9d6e6" });
      o += t(280, Y + 70, "2º turno", { s: 12, c: C.apagado }) + t(280, Y + 100, pct(c.pct), { s: 28, b: true });
      o += t(55, Y + 128, (a ? inteiro(a.votos) : "—") + " → " + inteiro(c.votos) + " votos", { s: 13, c: C.apagado, max: 430 });
      if (g != null && !parcial) o += t(55, Y + 164, "ganhou " + sinalVotos(g) + " votos", { s: 17, b: true, c: g >= 0 ? "#69db7c" : "#ff8787", max: 430 });
    });
    o += r(35, 572, 470, 300, "rgba(8,14,32,0.84)", 8) + t(330, 604, "1º T", { s: 12, b: true, c: C.apagado, a: "end" }) + t(420, 604, "2º T", { s: 12, b: true, c: C.apagado, a: "end" }) + t(495, 604, "DIF.", { s: 12, b: true, c: C.apagado, a: "end" });
    linhas.forEach(function (L, i) {
      var y = 650 + i * 56, d = L[1] != null && L[2] != null ? L[2] - L[1] : null;
      o += t(52, y, L[0], { s: 18, b: true, max: 190 }) + t(330, y, pct1(L[1] || 0), { s: 16, c: "#c9d6e6", a: "end" }) + t(420, y, pct1(L[2] || 0), { s: 18, b: true, a: "end" }) + t(495, y, d == null ? "—" : difPP(d, true), { s: 14, b: true, a: "end", c: "#ffd43b" });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — exterior, 1º turno final × 2º turno", { s: 10, c: C.apagado2 }));
  }
  G["excomp-h"] = function () { return telaExComp(false); };
  G["excomp-v"] = function () { return telaExComp(true); };

  // ---- EXTERIOR: RESULTADO FINAL DO 1o E DO 2o TURNO (3.28.3) ------------------
  // Como os brasileiros no exterior votaram para Presidente: todos os
  // candidatos do 1o turno (boletim ZZ guardado, turno1.ufs.zz) e os dois do
  // 2o turno (exterior_total ao vivo), lado a lado. So numero do TSE.
  function telaExFinal(v) {
    var W = v ? 540 : 1280, H = v ? 960 : 720, z2 = D().exterior_total, z1 = ((D().turno1 || {}).ufs || {}).zz;
    var tem1 = !!(z1 && z1.tem && candidatos(z1).length), tem2 = !!(z2 && z2.tem && candidatos(z2).length);
    var tit = v ? "EXTERIOR: PRESIDENTE" : "EXTERIOR: COMO VOTOU PARA PRESIDENTE", sub = "brasileiros no exterior · 1º turno (04/10) e 2º turno (25/10)";
    var cab = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 26, b: true, ls: 1, max: 450 }) + t(53, 106, sub, { s: 13, c: C.apagado, max: 470 })
                : t(73, 57, tit, { s: 34, b: true, ls: 1, max: 700 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 700 });
    if (!tem1 && !tem2) return svg(W, H, marcaVazio() + cab + t(W / 2, H / 2, "aguardando o boletim do exterior", { s: v ? 16 : 22, c: C.apagado, a: "middle" }));
    if (tem2) cab += v ? seloV(W, seloDe({ br: z2 })) : seloH(W, seloDe({ br: z2 }));
    function rodapeT(z) {
      var e = z.eleitorado || {}, vt = z.votos || {};
      return "comparecimento " + pct(e.pct_comparec) + " · brancos " + pct(vt.pct_brancos) + " · nulos " + pct(vt.pct_nulos);
    }
    function painel(x, y, w, h, rot, z, tem, max, grande) {
      var o = r(x, y, w, h, "rgba(8,14,32,0.84)", 10) + t(x + 20, y + 34, rot, { s: 15, b: true, c: "#c9d6e6", ls: 2 });
      if (!tem) return o + t(x + w / 2, y + h / 2, z === z1 ? "1º turno do exterior não guardado" : "aguardando o boletim do exterior", { s: 16, c: C.apagado, a: "middle", max: w - 40 });
      var cs = candidatos(z).filter(function (c) { return (+c.votos || 0) > 0; }).slice(0, max), topo = Math.max.apply(null, cs.map(function (c) { return +c.pct || 0; }).concat([1]));
      var pu = (z.secoes || {}).pct, wb = w - 40;
      var passo = grande ? (v ? 100 : 150) : Math.min(v ? 44 : 62, Math.floor((h - 130) / Math.max(1, cs.length))), y0 = y + (grande ? (v ? 100 : 130) : 80);
      cs.forEach(function (c, i) {
        var yy = y0 + i * passo, cc = cor(c), lado = grande ? 28 : (v ? 15 : 18), wv = Math.max(4, wb * (+c.pct || 0) / topo * 0.62);
        if (grande) {
          o += r(x + 20, yy - 24, 6, 56, cc, 2) + t(x + 36, yy, c.nome + (c.partido ? " (" + c.partido + ")" : ""), { s: v ? 18 : 22, b: true, max: w - 210 }) +
            t(x + w - 20, yy + 4, pct(c.pct), { s: v ? 30 : 38, b: true, a: "end" }) +
            r(x + 36, yy + 14, wv, 14, cc, 3) + t(x + 36, yy + 48, inteiro(c.votos) + " votos", { s: v ? 12 : 14, c: C.apagado });
          if (i === 0 && pu >= 100) o += t(x + w - 20, yy + 48, "VENCEU NO EXTERIOR", { s: v ? 11 : 13, b: true, c: "#69db7c", a: "end" });
        } else {
          o += r(x + 20, yy - lado + 3, 5, lado + 18, cc, 2) + t(x + 32, yy, c.nome, { s: lado, b: true, max: w * 0.48 - 40 }) +
            t(x + 32, yy + 17, inteiro(c.votos) + " votos", { s: v ? 11 : 12, c: C.apagado }) +
            r(x + w * 0.52, yy - lado + 5, Math.max(4, (w * 0.28) * (+c.pct || 0) / topo), lado - 4, cc, 2) +
            t(x + w - 20, yy, pct(c.pct), { s: lado, b: true, a: "end" });
        }
      });
      return o + t(x + 20, y + h - 18, rodapeT(z) + (pu != null && pu < 100 ? " · urnas " + pct(pu) : ""), { s: v ? 11 : 13, c: C.apagado, max: w - 40 });
    }
    var o = cab;
    if (!v) {
      o += painel(73, 110, 560, 570, "1º TURNO · 04/10", z1, tem1, 8, false) + painel(653, 110, 554, 570, "2º TURNO · 25/10", z2, tem2, 2, true);
      return svg(W, H, o + t(73, 706, "Fonte: TSE — boletim do exterior (ZZ) de Presidente: 1º turno final e 2º turno" + (tem2 && z2.eleitorado ? " · eleitores aptos no exterior: " + inteiro(z2.eleitorado.aptos) : ""), { s: 11, c: C.apagado2, max: 1134 }));
    }
    o += painel(35, 160, 470, 420, "1º TURNO · 04/10", z1, tem1, 8, false) + painel(35, 596, 470, 330, "2º TURNO · 25/10", z2, tem2, 2, true);
    return svg(W, H, o + t(35, 950, "Fonte: TSE — boletim do exterior (ZZ), Presidente", { s: 10, c: C.apagado2, max: 470 }));
  }
  G["exfinal-h"] = function () { return telaExFinal(false); };
  G["exfinal-v"] = function () { return telaExFinal(true); };

  // =====================================================================
  // MAIS COMPARATIVOS (3.13): saldo por estado, mudou de lado desde 2022,
  // intensidade da vitoria, abstencao 2022 x 2026, brancos e nulos 1o x 2o,
  // eleitos com menos votos, Senado por partido, concentracao do voto e
  // governadores por partido 2022 x 2026. Tudo do TSE (2026 ao vivo; 2022
  // dos boletins que o TSE mantem publicados).
  // =====================================================================
  function doisNacionais(f) { var cs = f.br ? candidatos(f.br).filter(function (c) { return c.votos > 0; }) : []; return cs.slice(0, 2); }
  function votosDe(x, c) { var k = x ? candidatos(x).filter(function (y) { return String(y.numero) === String(c.numero); })[0] : null; return k ? +k.votos || 0 : 0; }
  function pctDeC(x, c) { var k = x ? candidatos(x).filter(function (y) { return String(y.numero) === String(c.numero); })[0] : null; return k ? +k.pct || 0 : null; }
  function milhoes(n) { var a = Math.abs(n); return a >= 1e6 ? (a / 1e6).toFixed(2).replace(".", ",") + " mi" : inteiro(a); }
  // TELA VAZIA: a tela marca quando nao tem dado para mostrar. O gerenciador
  // esconde o botao dela e o rodizio pula - nunca vai ao ar uma tela vazia.
  function semDados(W, H, v, tit, msg) {
    var o = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 26, b: true, ls: 1, max: 450 }) : t(73, 57, tit, { s: 34, b: true, ls: 1, max: 660 });
    return svg(W, H, marcaVazio() + o + t(W / 2, H / 2, msg, { s: v ? 16 : 22, c: C.apagado, a: "middle", max: W - 60 }));
  }

  // ---- 1. DE ONDE VEIO A VANTAGEM: saldo de votos por estado ----------------
  function telaSaldo(v) {
    var f = fontePres(false), cs = doisNacionais(f), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "DE ONDE VEIO A VANTAGEM";
    if (cs.length < 2) return semDados(W, H, v, tit, "aguardando o boletim do TSE");
    var A = cs[0], B = cs[1], ls = Object.keys(DEP_UF).map(function (k) { var x = f.uf(k); return { k: k, d: x ? votosDe(x, A) - votosDe(x, B) : 0, tem: !!x }; }).filter(function (l) { return l.tem; });
    ls.sort(function (p, q) { return Math.abs(q.d) - Math.abs(p.d); });
    var regs = DEP_REGIOES.map(function (rg) { var d = 0; ls.forEach(function (l) { if (rg[1].indexOf(l.k) >= 0) d += l.d; }); return { nome: REG_NOME[rg[0]], d: d }; });
    var somaUf = ls.reduce(function (a0, l) { return a0 + l.d; }, 0), dBr = (+A.votos || 0) - (+B.votos || 0), z = D().exterior_total, dZz = z && z.tem ? votosDe(z, A) - votosDe(z, B) : null;
    var max = Math.max.apply(null, ls.map(function (l) { return Math.abs(l.d); }).concat([1]));
    function linha(l, x, y, w, fs, nome) {
      var c = l.d >= 0 ? A : B, meio = x + w / 2, wb = Math.max(2, (w / 2 - (v ? 78 : 100)) * Math.abs(l.d) / max), o = "";
      o += r(x, y - fs - 4, w, fs + 12, "rgba(255,255,255,0.05)", 3) + r(meio - 1, y - fs - 4, 2, fs + 12, "rgba(255,255,255,0.25)", 0);
      o += l.d >= 0 ? r(meio + 1, y - fs + 1, wb, fs, cor(A), 2) : r(meio - 1 - wb, y - fs + 1, wb, fs, cor(B), 2);
      o += t(l.d >= 0 ? meio - 8 : meio + 8, y, nome, { s: fs - 1, b: true, a: l.d >= 0 ? "end" : "start", max: w / 2 - 20 });
      o += t(l.d >= 0 ? meio + wb + 8 : meio - wb - 8, y, "+" + milhoes(l.d), { s: fs - 1, b: true, a: l.d >= 0 ? "start" : "end", c: "#c9d6e6" });
      return o;
    }
    var o, n = v ? 15 : 14;
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1 }) + t(73, 85, "Presidente · " + turnoTxt(f) + " · votos de diferença que cada estado deu a cada candidato", { s: 16, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
      o += r(73, 100, 760, 34, "rgba(8,14,32,0.84)", 6) + r(83, 109, 6, 16, cor(B), 2) + t(95, 123, "← " + nomeCurto(B), { s: 14, b: true }) + t(823, 123, nomeCurto(A) + " →", { s: 14, b: true, a: "end" }) + r(827, 109, 6, 16, cor(A), 2);
      ls.slice(0, n).forEach(function (l, i) { o += linha(l, 73, 168 + i * 38, 760, 17, DEP_UF[l.k]); });
      o += r(853, 100, 354, 574, "rgba(8,14,32,0.84)", 10) + t(873, 134, "POR REGIÃO", { s: 15, b: true, c: "#c9d6e6", ls: 2 });
      regs.forEach(function (g, i) { var c = g.d >= 0 ? A : B, y = 176 + i * 54; o += r(873, y - 22, 6, 32, cor(c), 2) + t(889, y - 4, g.nome, { s: 15, b: true }) + t(889, y + 14, nomeCurto(c) + " +" + milhoes(g.d), { s: 13, c: "#c9d6e6" }); });
      var y2 = 466;
      o += r(873, y2 - 10, 314, 1, "rgba(255,255,255,0.2)") + t(873, y2 + 14, "SOMA DOS ESTADOS", { s: 12, b: true, c: C.apagado, ls: 1 }) + t(873, y2 + 36, nomeCurto(somaUf >= 0 ? A : B) + " +" + milhoes(somaUf), { s: 16, b: true, max: 314 });
      if (dZz != null) o += t(873, y2 + 66, "EXTERIOR", { s: 12, b: true, c: C.apagado, ls: 1 }) + t(873, y2 + 88, nomeCurto(dZz >= 0 ? A : B) + " +" + milhoes(dZz), { s: 16, b: true, max: 314 });
      o += r(873, y2 + 104, 314, 1, "rgba(255,255,255,0.2)") + t(873, y2 + 128, "BRASIL · votos de vantagem", { s: 13, b: true, c: "#c9d6e6", ls: 1 }) + t(873, y2 + 160, nomeCurto(dBr >= 0 ? A : B) + " +" + milhoes(dBr), { s: 26, b: true, max: 314 });
      return svg(W, H, o + t(73, 704, "Fonte: TSE — votos de cada candidato nos boletins dos 27 estados e do exterior · os " + n + " estados com maior saldo", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "DE ONDE VEIO A VANTAGEM", { s: 24, b: true, ls: 1, max: 450 }) + t(53, 106, "saldo de votos por estado", { s: 14, c: C.apagado }) + seloV(W, seloDe(f));
    o += t(40, 182, "← " + nomeCurto(B), { s: 13, b: true }) + t(500, 182, nomeCurto(A) + " →", { s: 13, b: true, a: "end" });
    ls.slice(0, n).forEach(function (l, i) { o += linha(l, 35, 218 + i * 33, 470, 14, l.k.toUpperCase()); });
    o += r(35, 728, 470, 200, "rgba(8,14,32,0.84)", 8);
    regs.forEach(function (g, i) { var c = g.d >= 0 ? A : B; o += r(50, 742 + i * 26, 5, 16, cor(c), 2) + t(62, 756 + i * 26, g.nome, { s: 12, b: true }) + t(490, 756 + i * 26, nomeCurto(c) + " +" + milhoes(g.d), { s: 12, a: "end", c: "#c9d6e6" }); });
    o += t(50, 906, "BRASIL", { s: 14, b: true, ls: 1 }) + t(490, 906, nomeCurto(dBr >= 0 ? A : B) + " +" + milhoes(dBr), { s: 18, b: true, a: "end" });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — votos por estado", { s: 10, c: C.apagado2 }));
  }
  G["saldo-h"] = function () { return telaSaldo(false); };
  G["saldo-v"] = function () { return telaSaldo(true); };

  // ---- 2. MUDOU DE LADO DESDE 2022 (2o turno, partido vencedor por estado) ----
  function vencedor22(r22) {
    if (!r22) return null; var best = null;
    Object.keys(r22).forEach(function (k) { if (k.charAt(0) === "_") return; if (!best || +r22[k] > +r22[best]) best = k; });
    return best;
  }
  function telaMudou(v) {
    var f = fontePres(false), R = ref22(), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "MUDOU DE LADO DESDE 2022";
    if (f.turno !== 2) return semDados(W, H, v, tit, "disponível no 2º turno");
    if (!R) return semDados(W, H, v, tit, "aguardando o 2º turno de 2022 do TSE (ESTADOS.bat)");
    var ls = Object.keys(DEP_UF).map(function (k) {
      var l = liderF(f, k), p22 = vencedor22((R.ufs || {})[k]);
      return { k: k, l: l, p22: p22, mudou: !!(l && p22 && String(l.partido).toUpperCase() !== p22.toUpperCase()) };
    }).filter(function (x) { return x.l && x.p22; });
    var mud = ls.filter(function (x) { return x.mudou; }), man = ls.length - mud.length, o;
    var corK = function (k) { var x = ls.filter(function (y) { return y.k === k; })[0]; return x ? (x.mudou ? cor(x.l) : misturar(cor(x.l), C.fundo, 0.45)) : null; };
    var opc = { rotulos: true, fonte: 12, apagado: "#1c2a40", hachura: function (k) { return mud.some(function (x) { return x.k === k; }); } };
    if (!v) {
      o = HACH + t(73, 57, tit, { s: 36, b: true, ls: 1 }) + t(73, 85, "Presidente · partido que lidera cada estado no 2º turno de 2026 × o que venceu no 2º turno de 2022", { s: 15, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
      o += mapaCor(40, 112, 0.84, corK, opc);
      o += r(700, 110, 507, 90, "rgba(8,14,32,0.84)", 10) + t(730, 168, String(mud.length), { s: 54, b: true }) + t(810, 150, mud.length === 1 ? "estado mudou" : "estados mudaram", { s: 20, b: true }) + t(810, 176, "de partido vencedor · " + man + " mantiveram", { s: 15, c: C.apagado });
      o += t(700, 236, "QUEM MUDOU", { s: 14, b: true, c: "#c9d6e6", ls: 2 });
      mud.slice(0, 11).forEach(function (x, i) { var y = 264 + i * 36; o += r(700, y - 22, 507, 32, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 3) + t(712, y, DEP_UF[x.k], { s: 15, b: true, max: 230 }) + t(1195, y, x.p22 + "  →  " + String(x.l.partido).toUpperCase(), { s: 15, b: true, a: "end", c: "#c9d6e6" }) + r(1080, y - 13, 4, 16, cor(x.l), 2); });
      if (!mud.length) o += t(700, 270, "nenhum estado mudou de lado", { s: 16, c: C.apagado });
      o += r(60, 640, 14, 14, "#7f8ca3", 2) + '<rect x="60" y="640" width="14" height="14" fill="url(#hach)"/>' + t(82, 652, "hachurado = mudou desde 2022 · cor = quem lidera em 2026 (clara = manteve)", { s: 12, c: C.apagado });
      return svg(W, H, o + t(73, 704, "Fonte: TSE — 2º turno de 2022 (eleição " + R.eleicao + ") e 2026 ao vivo · compara o partido, não o candidato", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = HACH + r(35, 48, 6, 38, C.destaque) + t(53, 80, "MUDOU DE LADO", { s: 28, b: true, ls: 1 }) + t(53, 106, "desde o 2º turno de 2022", { s: 14, c: C.apagado }) + seloV(W, seloDe(f));
    o += mapaCor(70, 165, 0.65, corK, { rotulos: true, fonte: 10, apagado: "#1c2a40", hachura: opc.hachura });
    o += t(35, 625, mud.length + (mud.length === 1 ? " estado mudou" : " estados mudaram") + " · " + man + " mantiveram", { s: 18, b: true });
    mud.slice(0, 9).forEach(function (x, i) { var y = 664 + i * 30; o += r(35, y - 19, 470, 26, "rgba(8,14,32,0.84)", 4) + t(45, y, DEP_UF[x.k], { s: 13, b: true, max: 250 }) + t(495, y, x.p22 + " → " + String(x.l.partido).toUpperCase(), { s: 13, b: true, a: "end" }); });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — 2022 e 2026 · compara o partido", { s: 10, c: C.apagado2 }));
  }
  G["mudou22-h"] = function () { return telaMudou(false); };
  G["mudou22-v"] = function () { return telaMudou(true); };

  // ---- 3. INTENSIDADE DA VITORIA: mapa pela margem ---------------------------
  var FAIXAS_MARGEM = [[0, 5, 0.35, "até 5 p.p."], [5, 15, 0.6, "5 a 15"], [15, 30, 0.82, "15 a 30"], [30, 101, 1, "mais de 30"]];
  function margemUf(f, k) { var x = f.uf(k), cs = x ? candidatos(x).filter(function (c) { return c.votos > 0; }) : []; return cs.length > 1 ? { c: cs[0], m: cs[0].pct - cs[1].pct } : null; }
  function telaIntensidade(v) {
    var f = fontePres(false), cs = doisNacionais(f), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "INTENSIDADE DA VITÓRIA";
    if (cs.length < 2) return semDados(W, H, v, tit, "aguardando o boletim do TSE");
    var ms = {}; Object.keys(DEP_UF).forEach(function (k) { ms[k] = margemUf(f, k); });
    var corK = function (k) { var m = ms[k]; if (!m) return null; for (var i = 0; i < FAIXAS_MARGEM.length; i++) if (m.m < FAIXAS_MARGEM[i][1]) return misturar(cor(m.c), C.fundo, FAIXAS_MARGEM[i][2]); return cor(m.c); };
    function legenda(x, y, k2) {
      var o = "";
      cs.forEach(function (c, j) {
        o += t(x, y + j * 52 * k2, nomeCurto(c), { s: Math.round(14 * k2), b: true, max: 200 });
        FAIXAS_MARGEM.forEach(function (fx, i) { o += r(x + i * 110 * k2, y + 10 * k2 + j * 52 * k2, 100 * k2, 16 * k2, misturar(cor(c), C.fundo, fx[2]), 2); });
      });
      FAIXAS_MARGEM.forEach(function (fx, i) { o += t(x + i * 110 * k2 + 50 * k2, y + 118 * k2, fx[3], { s: Math.round(11 * k2), c: C.apagado, a: "middle" }); });
      return o;
    }
    var fortes = cs.map(function (c) { return Object.keys(ms).filter(function (k) { return ms[k] && String(ms[k].c.numero) === String(c.numero); }).sort(function (a, b) { return ms[b].m - ms[a].m; }).slice(0, 4); });
    var o;
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1 }) + t(73, 85, "Presidente · " + turnoTxt(f) + " · cor de quem lidera; mais forte = maior diferença para o 2º colocado", { s: 15, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
      o += mapaCor(40, 112, 0.84, corK, { rotulos: true, fonte: 12, apagado: "#1c2a40" });
      o += r(690, 110, 517, 200, "rgba(8,14,32,0.84)", 10) + legenda(712, 145, 1);
      cs.forEach(function (c, j) {
        var y0 = 345 + j * 170;
        o += t(690, y0, "ONDE " + nomeCurto(c) + " FOI MAIS FORTE", { s: 13, b: true, c: "#c9d6e6", ls: 1, max: 517 });
        fortes[j].forEach(function (k, i) { var y = y0 + 30 + i * 32; o += r(690, y - 20, 517, 28, "rgba(8,14,32,0.84)", 4) + r(690, y - 20, 6, 28, cor(c), 2) + t(706, y, DEP_UF[k], { s: 14, b: true, max: 260 }) + t(1195, y, "+" + Number(ms[k].m).toFixed(1).replace(".", ",") + " p.p. · " + pct(ms[k].c.pct), { s: 14, b: true, a: "end" }); });
      });
      return svg(W, H, o + t(73, 704, "Fonte: TSE — diferença em pontos percentuais entre 1º e 2º colocados em cada estado", { s: 11, c: C.apagado2 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "INTENSIDADE", { s: 28, b: true, ls: 1 }) + t(53, 106, "da vitória em cada estado", { s: 14, c: C.apagado }) + seloV(W, seloDe(f));
    o += mapaCor(70, 165, 0.65, corK, { rotulos: true, fonte: 10, apagado: "#1c2a40" });
    o += r(35, 600, 470, 150, "rgba(8,14,32,0.84)", 8) + legenda(50, 628, 0.95);
    cs.forEach(function (c, j) { var y = 790 + j * 70; o += r(35, y - 18, 6, 50, cor(c), 2) + t(50, y, nomeCurto(c) + " mais forte em:", { s: 13, b: true }) + t(50, y + 24, fortes[j].map(function (k) { return k.toUpperCase() + " +" + Number(ms[k].m).toFixed(0); }).join("  ·  "), { s: 13, c: "#c9d6e6", max: 450 }); });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — margem por estado", { s: 10, c: C.apagado2 }));
  }
  G["intensidade-h"] = function () { return telaIntensidade(false); };
  G["intensidade-v"] = function () { return telaIntensidade(true); };

  // ---- 4. ABSTENCAO NO 2o TURNO: 2022 x 2026 por estado ----------------------
  function difAbst22() {
    var f2 = fontePres(false), R = ref22();
    if (f2.turno !== 2 || !R) return null;
    var ls = Object.keys(DEP_UF).map(function (k) {
      var a = (R.ufs || {})[k], b = f2.uf(k), p1 = a && a._pa != null ? +a._pa : null, p2 = b && b.eleitorado ? b.eleitorado.pct_abstencao : null;
      if (p1 == null || p2 == null || !(b.secoes && b.secoes.pct > 0)) return { k: k, d: null };
      return { k: k, p1: p1, p2: +p2, d: p2 - p1 };
    });
    return { ls: ls, b1: R.br && R.br._pa != null ? +R.br._pa : null, b2: f2.br && f2.br.eleitorado ? f2.br.eleitorado.pct_abstencao : null, f2: f2 };
  }
  G["abst22-h"] = function () { return telaVarUf(false, { da: difAbst22(), tit: "ABSTENÇÃO NO 2º TURNO: 2022 × 2026", titV: "ABSTENÇÃO 2022 × 2026", oque: "2º turno · variação da abstenção por estado (p.p.)", sem: "disponível no 2º turno, com o 2º turno de 2022 do TSE (ESTADOS.bat)", fonte: "Fonte: TSE — 2º turno de 2022 × 2º turno de 2026", fonteV: "Fonte: TSE — 2022 × 2026" }); };
  G["abst22-v"] = function () { return telaVarUf(true, { da: difAbst22(), tit: "ABSTENÇÃO NO 2º TURNO: 2022 × 2026", titV: "ABSTENÇÃO 2022 × 2026", oque: "2º turno · variação da abstenção por estado (p.p.)", sem: "disponível no 2º turno, com 2022 do TSE", fonte: "Fonte: TSE — 2º turno de 2022 × 2º turno de 2026", fonteV: "Fonte: TSE — 2022 × 2026" }); };

  // ---- 6. BRANCOS E NULOS: 1o x 2o turno por estado ---------------------------
  function bn(x) { var vv = x && x.votos; return vv && vv.pct_brancos != null && vv.pct_nulos != null ? +vv.pct_brancos + +vv.pct_nulos : null; }
  function difBN() {
    var f1 = fontePres(true), f2 = fontePres(false);
    if (!f1.guardado) return null;
    var ls = Object.keys(DEP_UF).map(function (k) {
      var b = f2.uf(k), p1 = bn(f1.uf(k)), p2 = bn(b);
      if (p1 == null || p2 == null || !(b.secoes && b.secoes.pct > 0)) return { k: k, d: null };
      return { k: k, p1: p1, p2: p2, d: p2 - p1 };
    });
    return { ls: ls, b1: bn(f1.br), b2: bn(f2.br), f2: f2 };
  }
  G["brnulos-h"] = function () { return telaVarUf(false, { da: difBN(), tit: "BRANCOS E NULOS: 1º × 2º TURNO", titV: "BRANCOS E NULOS", oque: "Presidente · brancos + nulos por estado, variação em p.p.", sem: "disponível no 2º turno (compara com o 1º turno guardado)", fonte: "Fonte: TSE — brancos + nulos (% do boletim); 1º turno final × 2º turno", fonteV: "Fonte: TSE — brancos + nulos 1º × 2º" }); };
  G["brnulos-v"] = function () { return telaVarUf(true, { da: difBN(), tit: "BRANCOS E NULOS: 1º × 2º TURNO", titV: "BRANCOS E NULOS", oque: "brancos + nulos por estado", sem: "disponível no 2º turno", fonte: "Fonte: TSE", fonteV: "Fonte: TSE — brancos + nulos 1º × 2º" }); };

  // ---- 7. DEPUTADOS FEDERAIS ELEITOS COM MENOS VOTOS -------------------------
  function telaMenosVot(v) {
    var cm = (window.GCTSE_ESTADOS || {}).camara || {}, todos = [], ufs = 0;
    Object.keys(cm).forEach(function (u) { var l = comoLista((cm[u] || {}).lista); if (l.length) ufs++; l.forEach(function (c) { if (+c.votos > 0) todos.push({ c: c, u: u }); }); });
    todos.sort(function (a, b) { return ((+a.c.votos || 0) - (+b.c.votos || 0)) || String(a.c.nome).localeCompare(String(b.c.nome), "pt-BR"); });
    var l = todos.slice(0, 10), W = v ? 540 : 1280, H = v ? 960 : 720, o, top = topDep(1).lista[0];
    var sl = !ufs ? { texto: "AGUARDANDO", cor: C.trilho } : (ufs >= 27 ? { texto: "TOTALIZAÇÃO FINAL", cor: C.verde } : { texto: "PARCIAL", cor: C.vermelho });
    if (!l.length) return semDados(W, H, v, "ELEITOS COM MENOS VOTOS", "aguardando os deputados eleitos (ESTADOS.bat)");
    var nota = "Sistema proporcional: a vaga é do partido/federação pelos votos de toda a legenda" + (top ? " · o mais votado do Brasil teve " + inteiro(top.c.votos) : "");
    if (!v) {
      o = t(73, 57, "OS 10 ELEITOS COM MENOS VOTOS", { s: 32, b: true, ls: 1, max: 667 }) + t(73, 85, "Câmara dos Deputados · deputados federais eleitos com a menor votação nominal" + (ufs < 27 ? " · " + ufs + " de 27 estados" : ""), { s: 15, c: C.apagado, max: 660 }) + seloH(W, sl);
      l.forEach(function (it, i) {
        var y = 106 + i * 56, c = it.c, cc = corPartidoCamara(c.partido, i);
        o += r(73, y, 1134, 50, i % 2 ? "rgba(8,14,32,0.70)" : "rgba(8,14,32,0.86)", 6);
        o += fotoDep(it.u, c, 85, y + 4, 31, 42) + r(126, y + 9, 5, 32, cc, 2);
        o += t(141, y + 24, c.nome, { s: 20, b: true, max: 560 }) + t(141, y + 42, (c.partido || "") + "  ·  " + (DEP_UF[it.u] || it.u.toUpperCase()), { s: 13, c: C.apagado, max: 560 });
        o += t(1190, y + 33, inteiro(c.votos) + " votos", { s: 22, b: true, a: "end" });
      });
      return svg(W, H, o + t(73, 682, nota, { s: 13, c: "#c9d6e6", max: 1134 }) + t(73, 704, "Fonte: TSE — boletins de Deputado Federal dos 27 estados (eleitos marcados pelo TSE)", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "MENOS VOTADOS", { s: 30, b: true, ls: 1 }) + t(53, 106, "entre os deputados federais eleitos", { s: 14, c: C.apagado }) + seloV(W, sl);
    l.forEach(function (it, i) { var y = 166 + i * 70, c = it.c; o += r(35, y, 470, 64, "rgba(8,14,32,0.84)", 6) + fotoDep(it.u, c, 45, y + 6, 39, 52) + r(92, y + 10, 4, 44, corPartidoCamara(c.partido, i), 2) + t(104, y + 28, c.nome, { s: 17, b: true, max: 380 }) + t(104, y + 50, (c.partido || "") + " · " + it.u.toUpperCase(), { s: 12, c: C.apagado }) + t(495, y + 50, inteiro(c.votos) + " votos", { s: 15, b: true, a: "end" }); });
    return svg(W, H, o + t(35, 880, "Sistema proporcional: a vaga é do partido", { s: 13, c: "#c9d6e6", max: 470 }) + t(35, 950, "Fonte: TSE — deputados federais eleitos", { s: 10, c: C.apagado2 }));
  }
  G["menosvot-h"] = function () { return telaMenosVot(false); };
  G["menosvot-v"] = function () { return telaMenosVot(true); };

  // ---- 8. SENADO: VOTOS POR PARTIDO NO BRASIL --------------------------------
  function senadoVotos() {
    var u = (window.GCTSE_ESTADOS || {}).ufs || {}, soma = {}, el = {}, tot = 0, n = 0;
    Object.keys(DEP_UF).forEach(function (k) {
      var s0 = u[k] && u[k].sen && u[k].sen.tem ? u[k].sen : null; if (!s0) return; n++;
      comoLista(s0.candidatos).forEach(function (c) { var sg = String(c.partido || "").toUpperCase(); soma[sg] = (soma[sg] || 0) + (+c.votos || 0); tot += +c.votos || 0; if (c.eleito) el[sg] = (el[sg] || 0) + 1; });
    });
    var ls = Object.keys(soma).map(function (sg) { return { sg: sg, votos: soma[sg], pct: tot ? 100 * soma[sg] / tot : 0, el: el[sg] || 0 }; }).sort(function (a, b) { return b.votos - a.votos; });
    return { ls: ls, tot: tot, ufs: n };
  }
  function telaSenVotos(v) {
    var S = senadoVotos(), W = v ? 540 : 1280, H = v ? 960 : 720, o, tit = "SENADO: VOTOS POR PARTIDO";
    if (!S.ls.length) return semDados(W, H, v, tit, "aguardando o boletim de Senador (ESTADOS.bat)");
    var n = v ? 12 : 12, ls = S.ls.slice(0, n), max = ls[0].pct || 1;
    var sub = "soma dos votos para o Senado nos " + S.ufs + " estados · " + inteiro(S.tot) + " votos (cada eleitor votou em 2)";
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 660 }) + seloH(W, { texto: S.ufs >= 27 ? "1º TURNO · FINAL" : "PARCIAL", cor: S.ufs >= 27 ? C.verde : C.vermelho });
      o += t(840, 128, "% DOS VOTOS", { s: 11, b: true, c: C.apagado, a: "end", ls: 1 }) + t(1080, 128, "VOTOS", { s: 11, b: true, c: C.apagado, a: "end", ls: 1 }) + t(1195, 128, "ELEITOS", { s: 11, b: true, c: C.apagado, a: "end", ls: 1 });
      ls.forEach(function (p, i) {
        var y = 162 + i * 43, cc = corPartidoCamara(p.sg, i);
        o += r(73, y - 26, 1134, 37, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 4) + r(83, y - 18, 6, 22, cc, 2) + t(99, y, p.sg, { s: 18, b: true, max: 200 });
        o += barraFina(310, y - 10, 440, p.pct / max, cc) + t(840, y, pct1(p.pct), { s: 18, b: true, a: "end" }) + t(1080, y, inteiro(p.votos), { s: 16, c: "#c9d6e6", a: "end" }) + t(1195, y, String(p.el), { s: 20, b: true, a: "end" });
      });
      return svg(W, H, o + t(73, 704, "Fonte: TSE — boletins de Senador dos 27 estados (1º turno de 2026); eleitos marcados pelo TSE", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "SENADO: VOTOS", { s: 28, b: true, ls: 1 }) + t(53, 106, "por partido no Brasil", { s: 14, c: C.apagado }) + seloV(W, { texto: S.ufs >= 27 ? "1º TURNO · FINAL" : "PARCIAL", cor: S.ufs >= 27 ? C.verde : C.vermelho });
    o += t(390, 168, "% VOTOS", { s: 10, b: true, c: C.apagado, a: "end" }) + t(495, 168, "ELEITOS", { s: 10, b: true, c: C.apagado, a: "end" });
    ls.forEach(function (p, i) { var y = 204 + i * 58, cc = corPartidoCamara(p.sg, i); o += r(35, y - 30, 470, 52, "rgba(8,14,32,0.84)", 5) + r(45, y - 22, 5, 36, cc, 2) + t(60, y - 4, p.sg, { s: 16, b: true, max: 200 }) + barraFina(60, y + 6, 250, p.pct / max, cc) + t(390, y, pct1(p.pct), { s: 16, b: true, a: "end" }) + t(495, y, String(p.el), { s: 18, b: true, a: "end" }); });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — Senador, 1º turno", { s: 10, c: C.apagado2 }));
  }
  G["senvotos-h"] = function () { return telaSenVotos(false); };
  G["senvotos-v"] = function () { return telaSenVotos(true); };

  // ---- 9. CONCENTRACAO DO VOTO: estados por faixa de votacao -----------------
  var FAIXAS_CONC = [[70, 101, "70% ou mais"], [60, 70, "60% a 70%"], [50, 60, "50% a 60%"], [0, 50, "abaixo de 50%"]];
  function telaConcentracao(v) {
    var f = fontePres(false), cs = doisNacionais(f), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "CONCENTRAÇÃO DO VOTO";
    if (cs.length < 2) return semDados(W, H, v, tit, "aguardando o boletim do TSE");
    var grupos = cs.map(function (c) { return FAIXAS_CONC.map(function (fx) { return Object.keys(DEP_UF).filter(function (k) { var p = pctDeC(f.uf(k), c); return p != null && p >= fx[0] && p < fx[1]; }); }); });
    var o;
    function chips(lista, x, y, w, c, fs) { var oo = "", px = x, py = y, cw = fs * 2.7; lista.forEach(function (k) { if (px + cw > x + w) { px = x; py += fs * 1.9; } oo += r(px, py - fs, cw - 4, fs * 1.55, misturar(cor(c), C.fundo, 0.8), 3) + t(px + (cw - 4) / 2, py + fs * 0.25, k.toUpperCase(), { s: fs - 2, b: true, a: "middle" }); px += cw; }); return oo; }
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1 }) + t(73, 85, "Presidente · " + turnoTxt(f) + " · em quantos estados cada candidato teve cada faixa de votação (% dos válidos)", { s: 15, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
      cs.forEach(function (c, j) {
        var x = 73 + j * 575;
        o += r(x, 104, 559, 570, "rgba(8,14,32,0.84)", 10) + r(x, 104, 559, 8, cor(c), 4) + t(x + 20, 146, c.nome, { s: 22, b: true, max: 380 }) + t(x + 539, 146, pct(c.pct) + " no Brasil", { s: 15, c: "#c9d6e6", a: "end" });
        FAIXAS_CONC.forEach(function (fx, i) {
          var y0 = 190 + i * 120, lst = grupos[j][i];
          o += t(x + 20, y0, fx[2], { s: 15, b: true, c: "#c9d6e6" }) + t(x + 539, y0, lst.length + (lst.length === 1 ? " estado" : " estados"), { s: 18, b: true, a: "end" });
          o += chips(lst, x + 20, y0 + 32, 519, c, 14);
        });
      });
      return svg(W, H, o + t(73, 704, "Fonte: TSE — % dos votos válidos de cada candidato em cada estado", { s: 11, c: C.apagado2 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "CONCENTRAÇÃO", { s: 28, b: true, ls: 1 }) + t(53, 106, "estados por faixa de votação", { s: 14, c: C.apagado }) + seloV(W, seloDe(f));
    cs.forEach(function (c, j) {
      var y = 168 + j * 390;
      o += r(35, y, 470, 378, "rgba(8,14,32,0.84)", 8) + r(35, y, 470, 6, cor(c), 3) + t(50, y + 32, c.nome, { s: 18, b: true, max: 300 }) + t(495, y + 32, pct(c.pct), { s: 15, c: "#c9d6e6", a: "end" });
      FAIXAS_CONC.forEach(function (fx, i) { var y0 = y + 66 + i * 80, lst = grupos[j][i]; o += t(50, y0, fx[2], { s: 12, b: true, c: "#c9d6e6" }) + t(495, y0, String(lst.length), { s: 15, b: true, a: "end" }) + chips(lst, 50, y0 + 24, 445, c, 12); });
    });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — % dos válidos por estado", { s: 10, c: C.apagado2 }));
  }
  G["concentracao-h"] = function () { return telaConcentracao(false); };
  G["concentracao-v"] = function () { return telaConcentracao(true); };

  // ---- 10. GOVERNADORES POR PARTIDO: 2022 x 2026 -----------------------------
  function telaGov22(v) {
    var R = (window.GCTSE_ESTADOS || {}).ref2022_gov, W = v ? 540 : 1280, H = v ? 960 : 720, tit = "GOVERNADORES: 2022 × 2026";
    if (!R || !R.ufs) return semDados(W, H, v, tit, "aguardando os governadores de 2022 do TSE (ESTADOS.bat)");
    var c22 = {}, c26 = {}, emDisputa = 0, trocas = [];
    Object.keys(DEP_UF).forEach(function (k) {
      var a = R.ufs[k], st = govEstado(k), p26 = (st.tipo === "eleito1" || st.tipo === "eleito2") && st.c ? String(st.c.partido).toUpperCase() : null;
      if (a) c22[String(a.partido).toUpperCase()] = (c22[String(a.partido).toUpperCase()] || 0) + 1;
      if (p26) c26[p26] = (c26[p26] || 0) + 1; else emDisputa++;
      if (a && p26 && String(a.partido).toUpperCase() !== p26) trocas.push({ k: k, de: String(a.partido).toUpperCase(), para: p26 });
    });
    var sgs = Object.keys(c22).concat(Object.keys(c26)).filter(function (s0, i, arr) { return arr.indexOf(s0) === i; })
      .sort(function (a, b) { return ((c26[b] || 0) - (c26[a] || 0)) || ((c22[b] || 0) - (c22[a] || 0)) || a.localeCompare(b); });
    var o, sub = "governadores eleitos por partido" + (emDisputa ? " · 2026: " + emDisputa + (emDisputa === 1 ? " estado ainda em disputa" : " estados ainda em disputa") : "");
    function saldoTxt(sg) { var d = (c26[sg] || 0) - (c22[sg] || 0); return d > 0 ? "▲ +" + d : d < 0 ? "▼ −" + Math.abs(d) : "="; }
    if (!v) {
      o = t(73, 57, tit, { s: 36, b: true, ls: 1 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 660 }) + seloH(W, { texto: emDisputa ? "PARCIAL" : "27 ESTADOS", cor: emDisputa ? C.vermelho : C.verde });
      o += t(99, 128, "PARTIDO", { s: 11, b: true, c: C.apagado, ls: 1 }) + t(400, 128, "2022", { s: 11, b: true, c: C.apagado, a: "end" }) + t(500, 128, "2026", { s: 11, b: true, c: C.apagado, a: "end" }) + t(610, 128, "SALDO", { s: 11, b: true, c: C.apagado, a: "end" });
      sgs.slice(0, 13).forEach(function (sg, i) {
        var y = 162 + i * 40, cc = corPartidoCamara(sg, i), d = (c26[sg] || 0) - (c22[sg] || 0);
        o += r(73, y - 24, 550, 34, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 4) + r(83, y - 16, 6, 20, cc, 2) + t(99, y, sg, { s: 17, b: true, max: 200 });
        o += t(400, y, String(c22[sg] || 0), { s: 18, c: "#c9d6e6", a: "end" }) + t(500, y, String(c26[sg] || 0), { s: 20, b: true, a: "end" }) + t(610, y, saldoTxt(sg), { s: 16, b: true, a: "end", c: d > 0 ? "#69db7c" : d < 0 ? "#ff8787" : C.apagado });
      });
      o += r(653, 104, 554, 570, "rgba(8,14,32,0.84)", 10) + t(673, 138, "ESTADOS QUE TROCARAM DE PARTIDO (" + trocas.length + ")", { s: 14, b: true, c: "#c9d6e6", ls: 1 });
      trocas.slice(0, 13).forEach(function (x, i) { var y = 176 + i * 37; o += t(673, y, DEP_UF[x.k], { s: 15, b: true, max: 250 }) + t(1187, y, x.de + "  →  " + x.para, { s: 15, b: true, a: "end", c: "#c9d6e6" }); });
      if (!trocas.length) o += t(673, 180, "nenhum até agora", { s: 15, c: C.apagado });
      return svg(W, H, o + t(73, 704, "Fonte: TSE — partido de quem foi ELEITO em 2022 (eleições " + R.eleicao + "/" + R.eleicao_2turno + "), não do governador de hoje (vice que assumiu), e eleitos em 2026", { s: 11, c: C.apagado2, max: 1134 }));
    }
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "GOVERNADORES", { s: 28, b: true, ls: 1 }) + t(53, 106, "por partido · 2022 × 2026", { s: 14, c: C.apagado }) + seloV(W, { texto: emDisputa ? "PARCIAL" : "27 ESTADOS", cor: emDisputa ? C.vermelho : C.verde });
    o += t(300, 168, "2022", { s: 11, b: true, c: C.apagado, a: "end" }) + t(400, 168, "2026", { s: 11, b: true, c: C.apagado, a: "end" }) + t(495, 168, "SALDO", { s: 11, b: true, c: C.apagado, a: "end" });
    sgs.slice(0, 12).forEach(function (sg, i) { var y = 202 + i * 40, d = (c26[sg] || 0) - (c22[sg] || 0); o += r(35, y - 24, 470, 34, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 4) + r(45, y - 16, 5, 20, corPartidoCamara(sg, i), 2) + t(58, y, sg, { s: 15, b: true, max: 180 }) + t(300, y, String(c22[sg] || 0), { s: 16, c: "#c9d6e6", a: "end" }) + t(400, y, String(c26[sg] || 0), { s: 18, b: true, a: "end" }) + t(495, y, saldoTxt(sg), { s: 14, b: true, a: "end", c: d > 0 ? "#69db7c" : d < 0 ? "#ff8787" : C.apagado }); });
    o += t(35, 720, "TROCARAM DE PARTIDO: " + trocas.length, { s: 14, b: true, c: "#c9d6e6" });
    trocas.slice(0, 6).forEach(function (x, i) { o += t(35, 750 + i * 28, x.k.toUpperCase() + "  " + x.de + " → " + x.para, { s: 14, b: true }); });
    return svg(W, H, o + t(35, 950, "Fonte: TSE — partido do eleito em 2022 (não do vice que assumiu) e 2026", { s: 10, c: C.apagado2, max: 470 }));
  }
  G["gov22-h"] = function () { return telaGov22(false); };
  G["gov22-v"] = function () { return telaGov22(true); };

  // ---- ESTADOS DECISIVOS: os 6 maiores eleitorados, placar ao vivo ----------
  // Quais sao os 6: pelo eleitorado (aptos) que o proprio TSE publica no
  // boletim de Presidente de cada estado - nada fixo no codigo.
  function decisivos() {
    var f = fontePres(false), f1 = fontePres(true);
    return Object.keys(DEP_UF).map(function (k) { var x = f.uf(k); return { k: k, x: x, aptos: x && x.eleitorado ? +x.eleitorado.aptos || 0 : 0 }; })
      .filter(function (s) { return s.aptos > 0; }).sort(function (a, b) { return b.aptos - a.aptos; }).slice(0, 6)
      .map(function (s) {
        s.cs = candidatos(s.x).slice(0, 2); s.l1 = f1.guardado ? liderF(f1, s.k) : null; s.l2 = liderF(f, s.k);
        s.virou = !!(s.l1 && s.l2 && String(s.l1.numero) !== String(s.l2.numero));
        return s;
      });
  }
  function cartaoDecisivoV(s, x, y, w, h, aptosBr) {   // vertical: compacto, sem votos
    var o = r(x, y, w, h, "rgba(8,14,32,0.84)", 8), urn = s.x && s.x.secoes ? s.x.secoes.pct : null;
    o += t(x + 14, y + 22, DEP_UF[s.k], { s: 16, b: true, max: w - 130 }) + t(x + w - 12, y + 21, "urnas " + (urn == null ? "—" : pct(urn)), { s: 11, b: true, c: "#c9d6e6", a: "end" });
    o += t(x + 14, y + 38, inteiro(s.aptos) + " eleitores" + (aptosBr ? " · " + pct1(100 * s.aptos / aptosBr) + " do Brasil" : ""), { s: 10, c: C.apagado, max: w - 28 });
    s.cs.forEach(function (c, i) {
      var yy = y + 60 + i * 30;
      o += r(x + 14, yy - 13, 5, 26, cor(c), 2) + t(x + 26, yy, c.nome, { s: 14, b: true, max: w - 130 }) + t(x + w - 12, yy + 2, pct(c.pct), { s: 19, b: true, a: "end" });
      o += barraFina(x + 26, yy + 6, w - 120, (c.pct || 0) / 100, cor(c));
    });
    if (!s.cs.length) o += t(x + w / 2, y + 74, "aguardando o boletim", { s: 13, c: C.apagado, a: "middle" });
    if (s.l1) {
      o += t(x + 14, y + h - 8, "1º turno: " + nomeCurto(s.l1) + " liderou com " + pct(s.l1.pct), { s: 10, c: C.apagado, max: w - 100 });
      if (s.virou) o += r(x + w - 74, y + h - 21, 62, 17, "#ffffff", 3) + t(x + w - 43, y + h - 8, "VIROU", { s: 11, b: true, c: "#0b1220", a: "middle", ls: 1 });
    }
    return o;
  }
  function cartaoDecisivo(s, x, y, w, h, k2, aptosBr) {
    var o = r(x, y, w, h, "rgba(8,14,32,0.84)", 8), urn = s.x && s.x.secoes ? s.x.secoes.pct : null;
    o += t(x + 16, y + 30 * k2, DEP_UF[s.k], { s: Math.round(20 * k2), b: true, max: w - 165 });
    o += t(x + w - 14, y + 28 * k2, "urnas " + (urn == null ? "—" : pct(urn)), { s: Math.round(13 * k2), b: true, c: "#c9d6e6", a: "end" });
    o += t(x + 16, y + 50 * k2, inteiro(s.aptos) + " eleitores" + (aptosBr ? " · " + pct1(100 * s.aptos / aptosBr) + " do Brasil" : ""), { s: Math.round(12 * k2), c: C.apagado, max: w - 30 });
    var lh = (h - 96 * k2) / 2;
    s.cs.forEach(function (c, i) {
      var yy = y + 62 * k2 + i * lh;
      o += r(x + 16, yy + 4, 6, lh - 12, cor(c), 2);
      o += t(x + 32, yy + lh * 0.42, c.nome, { s: Math.round(17 * k2), b: true, max: w - 160 });
      o += t(x + w - 14, yy + lh * 0.48, pct(c.pct), { s: Math.round(26 * k2), b: true, a: "end" });
      o += barraFina(x + 32, yy + lh * 0.62, w - 48, (c.pct || 0) / 100, cor(c));
      o += t(x + 32, yy + lh * 0.62 + 24 * k2, inteiro(c.votos) + " votos", { s: Math.round(11 * k2), c: C.apagado });
    });
    if (!s.cs.length) o += t(x + w / 2, y + h / 2, "aguardando o boletim", { s: 15, c: C.apagado, a: "middle" });
    var yb = y + h - 14 * k2;
    if (s.l1) {
      o += t(x + 16, yb, "1º turno: " + nomeCurto(s.l1) + " liderou com " + pct(s.l1.pct), { s: Math.round(12 * k2), c: C.apagado, max: w - 120 });
      if (s.virou) o += r(x + w - 92, yb - 15 * k2, 78, 20 * k2, "#ffffff", 3) + t(x + w - 53, yb, "VIROU", { s: Math.round(12 * k2), b: true, c: "#0b1220", a: "middle", ls: 1 });
    }
    return o;
  }
  function telaDecisivos(v) {
    var f = fontePres(false), ls = decisivos(), b = f.br, aptosBr = b && b.eleitorado ? +b.eleitorado.aptos || 0 : 0, o;
    var soma = ls.reduce(function (a, s) { return a + s.aptos; }, 0);
    var sub = "Presidente · " + turnoTxt(f) + " · os 6 maiores eleitorados" + (aptosBr && soma ? " = " + pct1(100 * soma / aptosBr) + " dos eleitores do Brasil" : "");
    if (!v) {
      var W = 1280, H = 720;
      o = t(73, 57, "ESTADOS DECISIVOS", { s: 36, b: true, ls: 1 }) + t(73, 85, sub, { s: 16, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
      if (!ls.length) return svg(W, H, marcaVazio() + o + t(640, 380, "aguardando os boletins dos estados", { s: 22, c: C.apagado, a: "middle" }));
      ls.forEach(function (s, i) { o += cartaoDecisivo(s, 73 + (i % 3) * 382, 108 + Math.floor(i / 3) * 296, 370, 284, 1, aptosBr); });
      return svg(W, H, o + t(73, 708, "Fonte: TSE — boletins de Presidente dos estados; eleitorado (aptos) do próprio TSE", { s: 11, c: C.apagado2 }));
    }
    var W2 = 540, H2 = 960;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "ESTADOS DECISIVOS", { s: 28, b: true, ls: 1 }) + t(53, 106, "os 6 maiores eleitorados · " + turnoTxt(f), { s: 13, c: C.apagado, max: 450 }) + seloV(W2, seloDe(f));
    if (!ls.length) return svg(W2, H2, marcaVazio() + o + t(270, 480, "aguardando os boletins", { s: 18, c: C.apagado, a: "middle" }));
    ls.forEach(function (s, i) { o += cartaoDecisivoV(s, 35, 162 + i * 128, 470, 122, aptosBr); });
    return svg(W2, H2, o + t(35, 948, "Fonte: TSE — Presidente por estado", { s: 10, c: C.apagado2 }));
  }
  G["decisivos-h"] = function () { return telaDecisivos(false); };
  G["decisivos-v"] = function () { return telaDecisivos(true); };

  // ---- GOVERNADOR ELEITO x PRESIDENTE MAIS VOTADO NO ESTADO ------------------
  // So o fato: o partido do governador eleito e o partido do candidato a
  // presidente mais votado no estado. "Mesmo partido" = siglas iguais; nada
  // de apoio, alianca ou coligacao (isso o boletim do TSE nao traz).
  function siglaP(c) { return String(c && c.partido || "").toUpperCase().replace(/\s+/g, ""); }
  function govPres() {
    var f = fontePres(false);
    return Object.keys(DEP_UF).sort(function (a, b) { return DEP_UF[a].localeCompare(DEP_UF[b], "pt-BR"); }).map(function (k) {
      var st = govEstado(k), lp = liderF(f, k), gv = (st.tipo === "eleito1" || st.tipo === "eleito2") && st.c ? st.c : null;
      return { k: k, st: st, gov: gv, pres: lp, mesmo: !!(gv && lp && siglaP(gv) && siglaP(gv) === siglaP(lp)) };
    });
  }
  function celulaGov(l, x, y, wmax, fs) {
    if (l.gov) return r(x, y - fs - 4, 6, fs * 2 + 6, corPartidoCamara(l.gov.partido, 0), 2) + t(x + 12, y - 4, siglaP(l.gov), { s: fs, b: true, max: wmax - 12 }) +
      t(x + 12, y + fs - 2, l.gov.nome, { s: fs - 3, c: "#c9d6e6", max: wmax - 12 });
    if (l.st.tipo === "segundo") {
      var cs = l.st.cs || [];
      return t(x, y, "2º TURNO" + (cs.length === 2 ? ": " + siglaP(cs[0]) + " × " + siglaP(cs[1]) : ""), { s: fs - 1, b: true, c: "#7fb8ff", max: wmax });
    }
    return t(x, y, l.st.tipo === "apurando" ? "apurando" : "aguardando", { s: fs - 1, c: C.apagado, max: wmax });
  }
  function celulaPres(l, x, y, wmax, fs) {
    if (!l.pres) return t(x, y, "aguardando", { s: fs - 1, c: C.apagado });
    return r(x, y - fs - 4, 6, fs * 2 + 6, cor(l.pres), 2) + t(x + 12, y - 4, nomeCurto(l.pres), { s: fs, b: true, max: wmax - 12 }) +
      t(x + 12, y + fs - 2, siglaP(l.pres) + " · " + pct(l.pres.pct), { s: fs - 3, c: "#c9d6e6", max: wmax - 12 });
  }
  function chipMesmo(x, y, fs) { return r(x - 4, y - fs - 2, fs * 8.4, fs + 7, "rgba(255,255,255,0.92)", 3) + t(x - 4 + fs * 4.2, y, "MESMO PARTIDO", { s: fs - 1, b: true, c: "#0b1220", a: "middle" }); }
  function telaGovPres(v) {
    var f = fontePres(false), ls = govPres(), o;
    var comGov = ls.filter(function (l) { return l.gov && l.pres; }).length, mesmo = ls.filter(function (l) { return l.mesmo; }).length;
    var resumo = comGov ? "mesmo partido em " + mesmo + " de " + comGov + " estados com governador eleito" : "aguardando governadores eleitos";
    if (!v) {
      var W = 1280, H = 720;
      o = t(73, 57, "GOVERNADOR × PRESIDENTE", { s: 36, b: true, ls: 1 }) + t(73, 85, "governador eleito e o candidato a presidente mais votado no estado · " + turnoTxt(f), { s: 16, c: C.apagado, max: 660 }) + seloH(W, seloDe(f));
      o += r(73, 100, 1134, 34, "rgba(8,14,32,0.84)", 6) + t(90, 123, resumo.toUpperCase(), { s: 15, b: true, ls: 1 });
      [0, 1].forEach(function (col) {
        var x = 73 + col * 575;
        o += t(x + 6, 156, "ESTADO", { s: 10, b: true, c: C.apagado, ls: 1 }) + t(x + 128, 156, "GOVERNADOR", { s: 10, b: true, c: C.apagado, ls: 1 }) + t(x + 358, 156, "MAIS VOTADO P/ PRESIDENTE", { s: 10, b: true, c: C.apagado, ls: 1 });
      });
      ls.forEach(function (l, i) {
        var col = i < 14 ? 0 : 1, li = col ? i - 14 : i, x = 73 + col * 575, y = 182 + li * 37;
        o += r(x, y - 22, 559, 35, l.mesmo ? "rgba(255,255,255,0.13)" : (li % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)"), 3);
        o += t(x + 6, y, DEP_UF[l.k], { s: 12, b: true, max: 116 });
        o += celulaGov(l, x + 128, y, 222, 13);
        o += celulaPres(l, x + 358, y, 112, 13);
        if (l.mesmo) o += chipMesmo(x + 472, y + 1, 10);
      });
      return svg(W, H, o + t(73, 708, "Fonte: TSE. \"Mesmo partido\" = a sigla do governador eleito é a mesma do candidato a presidente mais votado no estado (não indica apoio).", { s: 11, c: C.apagado2, max: 1134 }));
    }
    var W2 = 540, H2 = 960;
    o = r(35, 48, 6, 38, C.destaque) + t(53, 80, "GOVERNADOR × PRESIDENTE", { s: 24, b: true, ls: 1, max: 330 }) + t(53, 106, resumo, { s: 13, c: C.apagado, max: 450 }) + seloV(W2, seloDe(f));
    o += t(41, 176, "UF", { s: 10, b: true, c: C.apagado }) + t(80, 176, "GOVERNADOR", { s: 10, b: true, c: C.apagado }) + t(300, 176, "PRESIDENTE (MAIS VOTADO)", { s: 10, b: true, c: C.apagado });
    ls.forEach(function (l, i) {
      var y = 200 + i * 27;
      o += r(35, y - 18, 470, 24, l.mesmo ? "rgba(255,255,255,0.15)" : (i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)"), 3);
      o += t(41, y, l.k.toUpperCase(), { s: 12, b: true });
      if (l.gov) o += r(80, y - 11, 5, 13, corPartidoCamara(l.gov.partido, 0), 2) + t(90, y, siglaP(l.gov) + " · " + nomeCurto(l.gov), { s: 11, b: true, max: 200 });
      else o += t(80, y, l.st.tipo === "segundo" ? "2º TURNO" : "aguardando", { s: 10, b: true, c: l.st.tipo === "segundo" ? "#7fb8ff" : C.apagado });
      if (l.pres) o += r(300, y - 11, 5, 13, cor(l.pres), 2) + t(310, y, nomeCurto(l.pres) + " " + pct(l.pres.pct), { s: 11, c: "#c9d6e6", max: l.mesmo ? 120 : 190 });
      if (l.mesmo) o += t(499, y, "= PARTIDO", { s: 10, b: true, a: "end" });
    });
    return svg(W2, H2, o + t(35, 948, "Fonte: TSE · \"= partido\": mesma sigla do governador eleito e do mais votado (não indica apoio)", { s: 9, c: C.apagado2, max: 470 }));
  }
  G["govpres-h"] = function () { return telaGovPres(false); };
  G["govpres-v"] = function () { return telaGovPres(true); };

  // ---- PRESIDENTE ELEITO -----------------------------------------------------
  // Vai ao ar SOZINHA nas duas saidas quando o TSE declara o eleito (vigia do
  // gerenciador). "ELEITO" so com a marca do TSE no boletim; antes disso a
  // tela diz que aguarda a declaracao e mostra o placar.
  function eleitoPres() {
    var f = fontePres(false), b = f.br, cs = b ? candidatos(b) : [], el = cs.filter(function (c) { return c.eleito; })[0] || null;
    var outro = el ? cs.filter(function (c) { return c !== el; })[0] : cs[1];
    var nUf = 0, nOutro = 0;
    Object.keys(DEP_UF).forEach(function (k) { var l = liderF(f, k); if (!l || !el) return; if (String(l.numero) === String(el.numero)) nUf++; else nOutro++; });
    return { f: f, b: b, el: el, lider: el || cs[0] || null, outro: outro || null, nUf: nUf, nOutro: nOutro };
  }
  function mapaEleito(e, x, y, esc) {
    return mapaCor(x, y, esc, function (k) {
      var l = liderF(e.f, k); if (!l) return null;
      return e.el && String(l.numero) === String(e.el.numero) ? cor(l) : misturar(cor(l), C.fundo, 0.55);
    }, { esp: 1 });
  }
  G["eleito-h"] = function () {
    var W = 1280, H = 720, e = eleitoPres(), c = e.lider, o = "", s = e.b ? e.b.secoes : null;
    if (!c) return svg(W, H, marcaVazio() + t(73, 57, "PRESIDENTE ELEITO", { s: 36, b: true, ls: 1 }) + seloH(W) + t(640, 380, "aguardando o boletim do TSE", { s: 24, c: C.apagado, a: "middle" }));
    o += t(73, 57, e.el ? "PRESIDENTE ELEITO" : "PRESIDENTE — " + turnoTxt(e.f), { s: 36, b: true, ls: 2 }) +
      t(73, 85, e.el ? "Eleições 2026 · declarado pelo TSE" : (e.b && e.b.andamento === "f" && e.f.turno === 1 ? "sem eleito no 1º turno: haverá 2º turno · " : "aguardando o TSE declarar o eleito · ") + subtitulo(), { s: 18, c: C.apagado, max: 660 }) + seloH(W);
    o += r(73, 112, 760, 520, "rgba(8,14,32,0.84)", 12) + r(73, 112, 10, 520, cor(c), 5);
    o += fotoOuSilhueta(urlFoto(c), 108, 146, 270, 360);
    o += t(410, 190, c.nome, { s: 52, b: true, max: 400, nome: true }) + t(410, 228, c.partido, { s: 24, c: C.apagado, max: 400 });
    if (e.el) o += r(410, 252, 186, 48, C.verde, 6) + t(503, 286, "ELEITO", { s: 30, b: true, a: "middle", ls: 3 });
    else o += t(410, 284, c.segundo_turno ? "vai ao 2º turno" : "lidera a apuração", { s: 22, b: true, c: "#ffd43b" });
    o += t(410, 400, pct(c.pct), { s: 92, b: true }) + t(410, 430, "dos votos válidos", { s: 18, c: C.apagado });
    o += t(410, 470, inteiro(c.votos) + " votos", { s: 26, b: true, c: "#c9d6e6" });
    if (e.outro) o += r(108, 540, 690, 2, "rgba(255,255,255,0.15)", 0) + r(108, 562, 6, 40, cor(e.outro), 2) +
      t(126, 590, e.outro.nome + "  ·  " + e.outro.partido, { s: 22, b: true, max: 430 }) + t(798, 590, pct(e.outro.pct) + "  ·  " + inteiro(e.outro.votos) + " votos", { s: 20, c: "#c9d6e6", a: "end" });
    o += mapaEleito(e, 868, 150, 0.54);
    if (e.el) o += t(1030, 520, "venceu em " + e.nUf + (e.nUf === 1 ? " estado" : " estados"), { s: 22, b: true, a: "middle" }) +
      t(1030, 548, e.outro ? nomeCurto(e.outro) + ": " + e.nOutro : "", { s: 16, c: C.apagado, a: "middle" });
    return svg(W, H, o + t(73, 690, (s ? "urnas apuradas " + pct(s.pct) + "  ·  " : "") + "Fonte: TSE" + (e.el ? " — eleito declarado no boletim oficial" : ""), { s: 14, c: C.apagado2 }));
  };
  G["eleito-v"] = function () {
    var W = 540, H = 960, e = eleitoPres(), c = e.lider, o = "", s = e.b ? e.b.secoes : null;
    o += r(35, 48, 6, 38, C.destaque) + t(53, 80, e.el ? "PRESIDENTE ELEITO" : "PRESIDENTE", { s: 30, b: true, ls: 1 }) +
      t(53, 106, e.el ? "Eleições 2026 · declarado pelo TSE" : "aguardando o TSE declarar o eleito", { s: 14, c: C.apagado, max: 450 }) + seloV(W);
    if (!c) return svg(W, H, marcaVazio() + o + t(270, 480, "aguardando o boletim do TSE", { s: 18, c: C.apagado, a: "middle" }));
    o += r(35, 168, 470, 560, "rgba(8,14,32,0.84)", 12) + r(35, 168, 470, 8, cor(c), 4);
    o += fotoOuSilhueta(urlFoto(c), 150, 200, 240, 320);
    o += t(270, 568, c.nome, { s: 38, b: true, a: "middle", max: 440, nome: true }) + t(270, 598, c.partido, { s: 20, c: C.apagado, a: "middle" });
    if (e.el) o += r(185, 616, 170, 44, C.verde, 6) + t(270, 648, "ELEITO", { s: 28, b: true, a: "middle", ls: 3 });
    else o += t(270, 645, c.segundo_turno ? "vai ao 2º turno" : "lidera a apuração", { s: 20, b: true, c: "#ffd43b", a: "middle" });
    o += t(270, 708, pct(c.pct) + "  ·  " + inteiro(c.votos) + " votos", { s: 22, b: true, a: "middle", max: 440 });
    if (e.outro) o += r(35, 744, 6, 40, cor(e.outro), 2) + t(52, 763, e.outro.nome + " · " + e.outro.partido, { s: 17, b: true, max: 300 }) +
      t(52, 783, inteiro(e.outro.votos) + " votos", { s: 13, c: C.apagado }) + t(505, 773, pct(e.outro.pct), { s: 24, b: true, a: "end" });
    o += mapaEleito(e, 35, 800, 0.2);
    if (e.el) o += t(205, 850, "venceu em", { s: 15, c: C.apagado }) + t(205, 884, e.nUf + (e.nUf === 1 ? " estado" : " estados"), { s: 28, b: true });
    return svg(W, H, o + t(35, 950, (s ? "urnas " + pct(s.pct) + " · " : "") + "Fonte: TSE", { s: 12, c: C.apagado2 }));
  };

  // ======================= ANALISE POLITICA (3.28) ==========================
  // 10 telas para o debate da bancada. So numero do TSE (e, no Senado, da
  // tabela da redacao em senado-config.js). Conta que e ESTIMATIVA aparece
  // escrita como estimativa no rodape.
  function cabAn(v, W, tit, sub, f) {
    return v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, tit, { s: 26, b: true, ls: 1, max: 450 }) + t(53, 106, sub, { s: 13, c: C.apagado, max: 470 }) + seloV(W, seloDe(f))
             : t(73, 57, tit, { s: 34, b: true, ls: 1, max: 640 }) + t(73, 85, sub, { s: 15, c: C.apagado, max: 640 }) + seloH(W, seloDe(f));
  }
  function vazioAn(v, tit, sub, f, msg) {
    var W = v ? 540 : 1280, H = v ? 960 : 720;
    return svg(W, H, marcaVazio() + cabAn(v, W, tit, sub, f) + t(W / 2, H / 2, msg, { s: v ? 16 : 22, c: C.apagado, a: "middle", max: W - 60 }));
  }
  function rodAn(v, txt) { return v ? t(35, 950, txt, { s: 10, c: C.apagado2, max: 470 }) : t(73, 708, txt, { s: 11, c: C.apagado2, max: 1134 }); }
  function ppTxt(d, casas) { return (d > 0.0001 ? "+" : d < -0.0001 ? "−" : "") + Math.abs(d).toFixed(casas == null ? 1 : casas).replace(".", ",") + " p.p."; }
  function milTxt(n) {
    n = Math.abs(n || 0);
    if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 1 : 2).replace(".", ",") + " mi";
    if (n >= 1e4) return Math.round(n / 1e3) + " mil";
    return inteiro(n);
  }
  function pctCandAn(x, c) { var k = x ? candidatos(x).filter(function (y) { return String(y.numero) === String(c.numero); })[0] : null; return k && k.pct != null ? +k.pct : null; }
  function fin2(f) { if (!f.br || f.turno !== 2) return null; var cs = candidatos(f.br).slice(0, 2); return cs.length === 2 ? cs : null; }
  function painelAn(x, y, w, h) { return r(x, y, w, h, "rgba(8,14,32,0.84)", 8); }
  function chip(x, y, txt, fundo, cTxt, s) { s = s || 12; var w = Math.round(txt.length * s * 0.62 + 14); return r(x, y - s - 3, w, s + 8, fundo, 3) + t(x + w / 2, y, txt, { s: s, b: true, c: cTxt || "#0b1220", a: "middle" }); }
  function hhmmTse(h) { var m = /^(\d{1,2}):(\d{2})/.exec(String(h || "")); return m ? ("0" + m[1]).slice(-2) + ":" + m[2] : "—"; }
  // barra dividida A | B (fracao de A entre os dois)
  function barraAB(x, y, w, h, fa, A, B) {
    fa = Math.max(0, Math.min(1, fa));
    return r(x, y, w, h, cor(B), 3) + (fa > 0 ? r(x, y, Math.max(3, w * fa), h, cor(A), 3) : "") + r(x + w / 2 - 1, y - 2, 2, h + 4, "rgba(255,255,255,0.65)", 0);
  }
  var ALIAS_SG = { "REP": "REPUBLICANOS", "PCDOB": "PCDOB", "SOLIDARIEDADE": "SOLIDARIEDADE", "UNIAO": "UNIÃO" };
  function normSg(s) { var k = String(s || "").toUpperCase().replace(/[\s.]+/g, ""); return ALIAS_SG[k] || k; }
  function coligDe(c) {
    var l = comoLista(c && c.coligacao);
    if (!l.length && c) {
      var t1 = fontePres(true), k = t1.guardado ? candidatos(t1.br).filter(function (x) { return String(x.numero) === String(c.numero); })[0] : null;
      l = comoLista(k && k.coligacao);
    }
    if (!l.length && c && c.partido) l = [c.partido];
    var vistos = {}; return l.map(normSg).filter(function (s) { if (!s || vistos[s]) return false; vistos[s] = 1; return true; });
  }

  // ---- A1. GOVERNABILIDADE: a base de cada finalista -----------------------
  function baseDe(c) {
    var cl = coligDe(c), cm = camara(), sn = senado(), nCam = 0, nSen = 0, nGov = 0, govs = [], dec = 0;
    cm.ps.forEach(function (p) { if (cl.indexOf(normSg(p.sigla)) >= 0) nCam += +p.em2027 || 0; });
    sn.ps.forEach(function (p) { if (cl.indexOf(normSg(p.sigla)) >= 0) nSen += +p.em2027 || 0; });
    Object.keys(DEP_UF).forEach(function (k) {
      var st = govEstado(k);
      if ((st.tipo === "eleito1" || st.tipo === "eleito2") && st.c) { dec++; if (cl.indexOf(normSg(st.c.partido)) >= 0) { nGov++; govs.push(k.toUpperCase()); } }
    });
    return { cl: cl, cam: nCam, camTot: cm.vagas || 513, camLidos: cm.eleitos, sen: nSen, senTot: sn.total2027 || 81, gov: nGov, govs: govs, govDec: dec };
  }
  function medidor(x, y, w, n, tot, marcas, c, rot, k) {
    var o = t(x, y, rot, { s: Math.round(13 * k), b: true, c: "#c9d6e6", ls: 1 }) + t(x + w, y, n + " de " + tot, { s: Math.round(20 * k), b: true, a: "end" });
    var yb = y + 10 * k, hb = 16 * k;
    o += r(x, yb, w, hb, C.trilho, 4) + (n > 0 ? r(x, yb, Math.max(4, w * Math.min(1, n / tot)), hb, c, 4) : "");
    // rotulos das marcas: o 1o termina na marca, o 2o comeca nela (nao se encostam)
    marcas.forEach(function (m, i) { var xm = x + w * m[0] / tot; o += r(xm - 1, yb - 4, 2, hb + 8, "#ffffff", 0) + t(xm + (i ? 4 : -4), yb + hb + 14 * k, m[1], { s: Math.round(10 * k), c: C.apagado, a: i ? "start" : "end" }); });
    return o;
  }
  function telaGovernab(v) {
    var f = fontePres(false), cs = fin2(f), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "GOVERNABILIDADE";
    var sub = "a base de cada finalista: partidos da coligação no Congresso de 2027 e governadores eleitos";
    if (!cs) return vazioAn(v, tit, sub, f, "disponível no 2º turno");
    var cm = camara();
    if (!cm.eleitos) return vazioAn(v, tit, sub, f, "aguardando a Câmara (ESTADOS.bat)");
    var o = cabAn(v, W, tit, sub, f), k = v ? 0.8 : 1;
    cs.forEach(function (c, i) {
      var b = baseDe(c), x = v ? 35 : 73 + i * 575, y = v ? 170 + i * 380 : 108, w = v ? 470 : 559, hh = v ? 365 : 560, cc = cor(c);
      o += painelAn(x, y, w, hh) + r(x, y, w, 6, cc, 3);
      o += t(x + 18, y + 40 * k, c.nome, { s: Math.round(24 * k), b: true, max: w - 36 }) + t(x + 18, y + 64 * k, c.partido + (c.eleito ? " · ELEITO" : ""), { s: Math.round(15 * k), c: C.apagado });
      o += t(x + 18, y + 92 * k, "COLIGAÇÃO: " + b.cl.join(" · "), { s: Math.round(13 * k), c: "#c9d6e6", max: w - 36 });
      var x0 = x + 18, wm = w - 36, y0 = y + (v ? 125 : 140);
      o += medidor(x0, y0, wm, b.cam, b.camTot, [[257, "maioria 257"], [308, "PEC 308"]], cc, "CÂMARA (deputados de 2027)", k);
      o += medidor(x0, y0 + (v ? 78 : 120), wm, b.sen, b.senTot, [[41, "maioria 41"], [49, "PEC 49"]], cc, "SENADO (a partir de 2027)", k);
      o += medidor(x0, y0 + (v ? 156 : 240), wm, b.gov, 27, [[14, "metade 14"]], cc, "GOVERNADORES ELEITOS", k);
      var falta = 257 - b.cam;
      o += t(x0, y0 + (v ? 222 : 340), falta > 0 ? "faltam " + falta + " deputados para a maioria simples" : "a coligação já tem maioria simples na Câmara",
        { s: Math.round(15 * k), b: true, c: falta > 0 ? "#ffd8a8" : "#8ce99a", max: wm });
      if (!v && b.govs.length) o += t(x0, y0 + 368, "Estados: " + b.govs.join(" "), { s: 13, c: C.apagado, max: wm });
      if (!v) o += t(x0, y0 + 396, b.govDec + " de 27 governadores já definidos" + (cm.eleitos < 513 ? " · Câmara: " + cm.eleitos + " de 513 eleitos lidos" : ""), { s: 12, c: C.apagado2, max: wm });
    });
    return svg(W, H, o + rodAn(v, "Fonte: TSE (coligação registrada, Câmara, governadores) e senado-config.js (Senado, tabela da redação) · partidos fora da coligação podem aderir depois"));
  }
  G["governab-h"] = function () { return telaGovernab(false); };
  G["governab-v"] = function () { return telaGovernab(true); };

  // ---- A2. CAPITAL × INTERIOR -----------------------------------------------
  function capInt() {
    var f = fontePres(false), cs = fin2(f); if (!cs) return null;
    var cp = D().capitais || {}, A = cs[0], B = cs[1], sa = { ac: 0, bc: 0, ai: 0, bi: 0 };
    var ls = Object.keys(DEP_UF).map(function (k) {
      var x = f.uf(k), c = cp[k]; if (!x || !c || !c.tem) return null;
      var ac = votosDe(c, A), bc = votosDe(c, B), ai = votosDe(x, A) - ac, bi = votosDe(x, B) - bc;
      if (ac + bc <= 0 || ai + bi <= 0) return null;
      sa.ac += ac; sa.bc += bc; sa.ai += ai; sa.bi += bi;
      var pc = ac / (ac + bc), pi = ai / (ai + bi);
      return { k: k, cap: String(c.nome || "").toUpperCase(), pc: pc, pi: pi, div: (pc > 0.5) !== (pi > 0.5), gap: Math.abs(pc - pi) };
    }).filter(Boolean);
    return { f: f, A: A, B: B, ls: ls, bc: sa.ac + sa.bc > 0 ? sa.ac / (sa.ac + sa.bc) : null, bi: sa.ai + sa.bi > 0 ? sa.ai / (sa.ai + sa.bi) : null };
  }
  // 3.28.5: em DUAS telas (parte 1 e 2), letras maiores - metade dos
  // estados em cada, na mesma ordem (divididos primeiro).
  function telaCapInt(v, parte) {
    parte = parte || 1;
    var ci = capInt(), f = fontePres(false), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "CAPITAL × INTERIOR" + (parte === 2 ? " (2/2)" : " (1/2)");
    var sub = "Presidente · em cada estado, a capital × o resto do estado (interior = estado − capital)";
    if (!ci) return vazioAn(v, tit, sub, f, "disponível no 2º turno");
    if (!ci.ls.length) return vazioAn(v, tit, sub, f, "aguardando os boletins das capitais (GRAFICOS.bat)");
    var A = ci.A, B = ci.B, o = cabAn(v, W, tit, sub, f), divs = ci.ls.filter(function (l) { return l.div; });
    function resumo(x, y, w, rot, fa, k) {
      return t(x, y, rot, { s: Math.round(14 * k), b: true, c: "#c9d6e6", ls: 2 }) + barraAB(x, y + 10 * k, w, 20 * k, fa, A, B) +
        t(x, y + 52 * k, nomeCurto(A) + " " + pct(100 * fa), { s: Math.round(18 * k), b: true }) + t(x + w, y + 52 * k, pct(100 - 100 * fa) + " " + nomeCurto(B), { s: Math.round(18 * k), b: true, a: "end" });
    }
    var ls = ci.ls.slice().sort(function (p, q) { return (q.div - p.div) || (q.gap - p.gap); });
    var meio = Math.ceil(ls.length / 2), parteLs = parte === 2 ? ls.slice(meio) : ls.slice(0, meio);
    var rotDiv = divs.length ? divs.length + (divs.length === 1 ? " ESTADO" : " ESTADOS") + " ONDE A CAPITAL E O INTERIOR ESCOLHERAM LADOS DIFERENTES" : "EM TODOS OS ESTADOS LIDOS, CAPITAL E INTERIOR TÊM O MESMO LÍDER";
    if (parte === 2) rotDiv += " · continuação";
    if (!v) {
      o += painelAn(73, 100, 1134, 88) + resumo(93, 126, 520, "TODAS AS CAPITAIS", ci.bc || 0, 1) + resumo(667, 126, 520, "TODO O INTERIOR", ci.bi || 0, 1);
      o += t(73, 222, rotDiv, { s: 16, b: true, c: divs.length ? "#ffd8a8" : C.apagado, ls: 1, max: 1134 });
      parteLs.slice(0, 14).forEach(function (l, i) {
        var col = i < 7 ? 0 : 1, li = col ? i - 7 : i, x = 73 + col * 575, y = 236 + li * 64, hL = 58;
        o += r(x, y, 559, hL, l.div ? "rgba(255,216,168,0.14)" : (li % 2 ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.08)"), 5);
        if (l.div) o += r(x, y, 5, hL, "#ffd8a8", 2);
        o += t(x + 18, y + 38, l.k.toUpperCase(), { s: 28, b: true });
        o += t(x + 80, y + 24, "CAPITAL", { s: 12, b: true, c: C.apagado, ls: 1 }) + barraAB(x + 156, y + 13, 190, 13, l.pc, A, B) + t(x + 440, y + 26, pct(100 * l.pc), { s: 18, b: true, a: "end" });
        o += t(x + 80, y + 48, "INTERIOR", { s: 12, b: true, c: C.apagado, ls: 1 }) + barraAB(x + 156, y + 37, 190, 13, l.pi, A, B) + t(x + 440, y + 50, pct(100 * l.pi), { s: 18, b: true, a: "end" });
        if (l.div) o += pilula(x + 547, y + 36, "DIVIDIDO", "#ffd8a8", 11, true);
      });
      return svg(W, H, o + rodAn(false, "Fonte: TSE — boletim de Presidente do estado e da capital · % = " + nomeCurto(A) + " entre os dois finalistas · interior = estado menos a capital"));
    }
    o += painelAn(35, 150, 470, 160) + resumo(53, 178, 434, "TODAS AS CAPITAIS", ci.bc || 0, 0.9) + resumo(53, 252, 434, "TODO O INTERIOR", ci.bi || 0, 0.9);
    o += t(35, 342, divs.length ? "CAPITAL ≠ INTERIOR: " + divs.length + (divs.length === 1 ? " estado" : " estados") + (parte === 2 ? " · continuação" : "") : "mesmo líder na capital e no interior" + (parte === 2 ? " · continuação" : ""), { s: 15, b: true, c: divs.length ? "#ffd8a8" : C.apagado, max: 470 });
    parteLs.slice(0, 14).forEach(function (l, i) {
      var y = 356 + i * 41;
      o += r(35, y, 470, 37, l.div ? "rgba(255,216,168,0.14)" : (i % 2 ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.08)"), 4) + t(47, y + 26, l.k.toUpperCase(), { s: 19, b: true });
      o += t(92, y + 15, "cap", { s: 11, c: C.apagado }) + barraAB(122, y + 7, 160, 9, l.pc, A, B) + t(355, y + 16, pct(100 * l.pc), { s: 14, b: true, a: "end" });
      o += t(92, y + 31, "int", { s: 11, c: C.apagado }) + barraAB(122, y + 23, 160, 9, l.pi, A, B) + t(355, y + 32, pct(100 * l.pi), { s: 14, b: true, a: "end" });
      if (l.div) o += pilula(497, y + 24, "DIVIDIDO", "#ffd8a8", 10, true);
    });
    return svg(W, H, o + rodAn(true, "Fonte: TSE · % de " + nomeCurto(A) + " entre os dois · interior = estado − capital"));
  }
  G["capint-h"] = function () { return telaCapInt(false, 1); };
  G["capint-v"] = function () { return telaCapInt(true, 1); };
  G["capint2-h"] = function () { return telaCapInt(false, 2); };
  G["capint2-v"] = function () { return telaCapInt(true, 2); };

  // ---- A3. PARA ONDE FORAM OS VOTOS (estimativa) ----------------------------
  function transfDe(x1, x2, A, B) {
    var a1 = pctCandAn(x1, A), b1 = pctCandAn(x1, B), a2 = pctCandAn(x2, A), b2 = pctCandAn(x2, B);
    if (a1 == null || b1 == null || a2 == null || b2 == null || !(a2 + b2 > 0)) return null;
    var da = a2 - a1, db = b2 - b1, ok = da >= 0 && db >= 0 && da + db > 0;
    return { a1: a1, b1: b1, a2: a2, b2: b2, outros: Math.max(0, 100 - a1 - b1), da: da, db: db, shA: ok ? da / (da + db) : null };
  }
  function telaTransf(v) {
    var f1 = fontePres(true), f2 = fontePres(false), cs = fin2(f2), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "PARA ONDE FORAM OS VOTOS";
    var sub = "Presidente · quanto cada finalista cresceu do 1º para o 2º turno (em pontos dos votos válidos)";
    if (!cs) return vazioAn(v, tit, sub, f2, "disponível no 2º turno");
    if (!f1.guardado) return vazioAn(v, tit, sub, f2, "1º turno ainda não guardado");
    if (!(f2.br.secoes && f2.br.secoes.pct > 0)) return vazioAn(v, tit, sub, f2, "aguardando as primeiras urnas do 2º turno");
    var A = cs[0], B = cs[1], tb = transfDe(f1.br, f2.br, A, B), o = cabAn(v, W, tit, sub, f2), k = v ? 0.82 : 1;
    if (!tb) return vazioAn(v, tit, sub, f2, "os finalistas não estão no boletim do 1º turno guardado");
    var elim = candidatos(f1.br).filter(function (c) { return String(c.numero) !== String(A.numero) && String(c.numero) !== String(B.numero) && c.votos > 0; }).slice(0, 3);
    var txtElim = elim.map(function (c) { return nomeCurto(c) + " " + pct(c.pct); }).join(" · ");
    var xP = v ? 35 : 73, wP = v ? 470 : 1134, yP = v ? 165 : 100, hP = v ? 250 : 200;
    o += painelAn(xP, yP, wP, hP);
    o += t(xP + 20, yP + 34 * k, "NO 1º TURNO, " + pct(tb.outros).replace("%", "") + "% VOTARAM EM OUTROS CANDIDATOS", { s: Math.round(19 * k), b: true, max: wP - 40 });
    o += t(xP + 20, yP + 58 * k, txtElim, { s: Math.round(14 * k), c: C.apagado, max: wP - 40 });
    var wb = wP - 40, yb = yP + (v ? 85 : 84);
    if (tb.shA != null) {
      o += barraAB(xP + 20, yb, wb, 26 * k, tb.shA, A, B);
      if (v) o += t(xP + 20, yb + 50, nomeCurto(A) + " " + ppTxt(tb.da), { s: 19, b: true, max: wb }) + t(xP + 20 + wb, yb + 76, ppTxt(tb.db) + " " + nomeCurto(B), { s: 19, b: true, a: "end", max: wb });
      else o += t(xP + 20, yb + 56 * k, nomeCurto(A) + " " + ppTxt(tb.da), { s: Math.round(22 * k), b: true }) + t(xP + 20 + wb, yb + 56 * k, ppTxt(tb.db) + " " + nomeCurto(B), { s: Math.round(22 * k), b: true, a: "end" });
      o += t(xP + 20, yb + (v ? 102 : 82 * k), "estimativa: " + nomeCurto(A) + " ficou com " + pct(100 * tb.shA).replace(",00", "") + " do crescimento", { s: Math.round(14 * k), c: "#c9d6e6", max: wb });
    } else {
      o += t(xP + 20, yb + 30 * k, nomeCurto(A) + " " + ppTxt(tb.da) + "   ·   " + nomeCurto(B) + " " + ppTxt(tb.db), { s: Math.round(22 * k), b: true, max: wb });
      o += t(xP + 20, yb + 58 * k, "um dos dois perdeu pontos: a divisão não se aplica", { s: Math.round(14 * k), c: C.apagado, max: wb });
    }
    var ls = Object.keys(DEP_UF).map(function (kk) { var x = transfDe(f1.uf(kk), f2.uf(kk), A, B); return x && x.shA != null && f2.uf(kk).secoes && f2.uf(kk).secoes.pct > 0 ? { k: kk, x: x } : null; }).filter(Boolean);
    ls.sort(function (p, q) { return q.x.shA - p.x.shA; });
    var y0 = yP + hP + (v ? 34 : 34);
    o += t(xP, y0 - 8, "POR ESTADO · parte do crescimento que foi para " + nomeCurto(A), { s: Math.round(13 * k), b: true, c: "#c9d6e6", ls: 1, max: wP });
    var nCol = v ? 1 : 3, porCol = v ? 13 : 9, wCol = v ? 470 : 366, passo = v ? 30 : 38;
    ls.slice(0, nCol * porCol).forEach(function (l, i) {
      var col = Math.floor(i / porCol), li = i % porCol, x = xP + col * (wCol + 18), y = y0 + li * passo;
      o += r(x, y, wCol, passo - 4, li % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.06)", 4) + t(x + 10, y + passo / 2 + 4, l.k.toUpperCase(), { s: Math.round(14 * k), b: true });
      o += barraAB(x + 50, y + (passo - 4) / 2 - 5, wCol - 140, 10, l.x.shA, A, B) + t(x + wCol - 10, y + passo / 2 + 4, pct(100 * l.x.shA).replace(",00", ""), { s: Math.round(14 * k), b: true, a: "end" });
    });
    return svg(W, H, o + rodAn(v, "ESTIMATIVA pela diferença de percentuais entre os turnos (TSE) — não é pesquisa: mistura quem mudou de voto, quem só votou num turno e quem anulou"));
  }
  G["transf-h"] = function () { return telaTransf(false); };
  G["transf-v"] = function () { return telaTransf(true); };

  // ---- A4. A ABSTENCAO DECIDIU? ----------------------------------------------
  function abstDec(f1, f2, A, B, x1, x2) {
    var e1 = x1 && x1.eleitorado, e2 = x2 && x2.eleitorado; if (!e1 || !e2) return null;
    var a1 = +e1.pct_abstencao, a2 = +e2.pct_abstencao; if (!(a1 >= 0) || !(a2 >= 0)) return null;
    var base = +e2.em_totalizadas || ((+e2.comparecimento || 0) + (+e2.abstencao || 0)); if (!(base > 0)) return null;
    var extra = (a2 - a1) / 100 * base, marg = Math.abs(votosDe(x2, A) - votosDe(x2, B));
    return { a1: a1, a2: a2, d: a2 - a1, extra: extra, marg: marg, supera: extra > 0 && extra > marg };
  }
  // selo com largura folgada (letra maiuscula em negrito e mais larga)
  function pilula(x, y, txt, fundo, s, alinhaFim) {
    var w = Math.round(txt.length * s * 0.74 + 18), x0 = alinhaFim ? x - w : x;
    return r(x0, y - s - 5, w, s + 11, fundo, 4) + t(x0 + w / 2, y + 1, txt, { s: s, b: true, c: "#0b1220", a: "middle" });
  }
  // 3.28.5: em DUAS telas (parte 1 e 2), letras maiores - metade dos
  // estados em cada, na mesma ordem (os que superam a diferença primeiro).
  function telaAbstDec(v, parte) {
    parte = parte || 1;
    var f1 = fontePres(true), f2 = fontePres(false), cs = fin2(f2), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "A ABSTENÇÃO DECIDIU?" + (parte === 2 ? " (2/2)" : " (1/2)");
    var sub = "eleitores em casa a mais no 2º turno × diferença entre os finalistas · urnas já apuradas";
    if (!cs) return vazioAn(v, tit, sub, f2, "disponível no 2º turno");
    if (!f1.guardado) return vazioAn(v, tit, sub, f2, "1º turno ainda não guardado");
    if (!(f2.br.secoes && f2.br.secoes.pct > 0)) return vazioAn(v, tit, sub, f2, "aguardando as primeiras urnas do 2º turno");
    var A = cs[0], B = cs[1], nb = abstDec(f1, f2, A, B, f1.br, f2.br), o = cabAn(v, W, tit, sub, f2), k = v ? 0.82 : 1;
    var ls = Object.keys(DEP_UF).map(function (kk) { var x = abstDec(f1, f2, A, B, f1.uf(kk), f2.uf(kk)); return x && f2.uf(kk).secoes && f2.uf(kk).secoes.pct > 0 ? { k: kk, x: x } : null; }).filter(Boolean);
    ls.sort(function (p, q) { return (q.x.supera - p.x.supera) || (q.x.extra - p.x.extra); });
    var nSup = ls.filter(function (l) { return l.x.supera; }).length, xP = v ? 35 : 73, wP = v ? 470 : 1134;
    var yB = v ? 150 : 100, hB = v ? 118 : 100;
    o += painelAn(xP, yB, wP, hB);
    if (nb) {
      o += t(xP + 20, yB + (v ? 32 : 36), "BRASIL: abstenção " + pct1v(nb.a1) + " → " + pct1v(nb.a2) + " (" + ppTxt(nb.d) + ")", { s: v ? 19 : 24, b: true, max: wP - (v ? 40 : 220) });
      o += t(xP + 20, yB + (v ? 62 : 72), (nb.extra > 0 ? milTxt(nb.extra) + " eleitores a mais em casa" : milTxt(-nb.extra) + " eleitores a mais foram votar") + "  ·  diferença entre os dois: " + milTxt(nb.marg) + " votos",
        { s: v ? 15 : 19, c: "#e7eef7", max: wP - 40 });
      var selB = nb.supera ? "SUPERA A DIFERENÇA" : "NÃO SUPERA";
      if (v) o += pilula(xP + wP - 20, yB + 96, selB, nb.supera ? "#ffd8a8" : "#8ce99a", 13, true);
      else o += pilula(xP + wP - 20, yB + 40, selB, nb.supera ? "#ffd8a8" : "#8ce99a", 16, true);
    }
    var y0 = yB + hB + (v ? 36 : 40);
    o += t(xP, y0 - 12, (nSup ? "EM " + nSup + (nSup === 1 ? " ESTADO" : " ESTADOS") + " A ABSTENÇÃO A MAIS SUPERA A DIFERENÇA" : "EM NENHUM ESTADO A ABSTENÇÃO A MAIS SUPERA A DIFERENÇA") + (parte === 2 ? " · continuação" : ""),
      { s: v ? 13 : 16, b: true, c: nSup ? "#ffd8a8" : "#c9d6e6", ls: 1, max: wP });
    var meio = Math.ceil(ls.length / 2), parteLs = parte === 2 ? ls.slice(meio) : ls.slice(0, meio);
    var nCol = v ? 1 : 2, porCol = v ? 14 : 7, wCol = v ? 470 : 559, passo = v ? 43 : 64, hL = passo - 6;
    if (!parteLs.length) o += t(W / 2, y0 + 80, "todos os estados apurados estão na parte 1", { s: v ? 16 : 20, c: C.apagado, a: "middle" });
    parteLs.slice(0, nCol * porCol).forEach(function (l, i) {
      var col = Math.floor(i / porCol), li = i % porCol, x = xP + col * (wCol + 16), y = y0 + li * passo, x2 = l.x;
      o += r(x, y, wCol, hL, x2.supera ? "rgba(255,216,168,0.14)" : (li % 2 ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.08)"), 5);
      if (x2.supera) o += r(x, y, 5, hL, "#ffd8a8", 2);
      var txtCasa = (x2.extra >= 0 ? "+" + milTxt(x2.extra) + " em casa" : milTxt(-x2.extra) + " a mais votaram") + "  ·  diferença " + milTxt(x2.marg);
      if (!v) {
        o += t(x + 18, y + 38, l.k.toUpperCase(), { s: 28, b: true });
        o += t(x + 84, y + 24, "abstenção " + pct1v(x2.a1) + " → " + pct1v(x2.a2) + "  (" + ppTxt(x2.d) + ")", { s: 16, c: "#c9d6e6", max: wCol - (x2.supera ? 260 : 100) });
        o += t(x + 84, y + 48, txtCasa, { s: 18, b: true, max: wCol - 100 });
        if (x2.supera) o += pilula(x + wCol - 12, y + 22, "SUPERA A DIFERENÇA", "#ffd8a8", 11, true);
      } else {
        o += t(x + 12, y + 26, l.k.toUpperCase(), { s: 20, b: true });
        o += t(x + 58, y + 16, "abstenção " + pct1v(x2.a1) + " → " + pct1v(x2.a2) + " (" + ppTxt(x2.d) + ")", { s: 13, c: "#c9d6e6", max: wCol - (x2.supera ? 140 : 70) });
        o += t(x + 58, y + 33, txtCasa, { s: 14, b: true, max: wCol - 70 });
        if (x2.supera) o += pilula(x + wCol - 10, y + 17, "SUPERA", "#ffd8a8", 10, true);
      }
    });
    return svg(W, H, o + rodAn(v, "Fonte: TSE — abstenção do 1º turno (final) × 2º turno, sobre o eleitorado das seções já apuradas · não diz em quem o ausente votaria"));
  }
  G["abstdec-h"] = function () { return telaAbstDec(false, 1); };
  G["abstdec-v"] = function () { return telaAbstDec(true, 1); };
  G["abstdec2-h"] = function () { return telaAbstDec(false, 2); };
  G["abstdec2-v"] = function () { return telaAbstDec(true, 2); };

  // ---- A5. A HORA DA DEFINICAO ----------------------------------------------
  function trocasLideranca() {
    var ev = D().evolucao, ps = comoLista(ev && ev.pontos), n = 0, ant = null, desde = null;
    ps.forEach(function (p) {
      var c = p.c || {}, best = null, bv = -1;
      Object.keys(c).forEach(function (k) { if (+c[k] > bv) { bv = +c[k]; best = k; } });
      if (best == null) return;
      if (ant != null && best !== ant) { n++; desde = p; }
      if (ant == null) desde = p;
      ant = best;
    });
    var nm = ev && ev.nomes && ant ? ev.nomes[ant] : null;
    return { trocas: n, lider: nm ? nm.nome : "", desde: desde };
  }
  function telaDefinicao(v) {
    var f = fontePres(false), cs = fin2(f), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "A HORA DA DEFINIÇÃO";
    var sub = "quando cada disputa do 2º turno ficou decidida (horário do boletim do TSE)";
    if (!cs) return vazioAn(v, tit, sub, f, "disponível no 2º turno");
    var o = cabAn(v, W, tit, sub, f), df = D().definicao, tl = trocasLideranca(), k = v ? 0.85 : 1;
    var xP = v ? 35 : 73, wP = v ? 470 : 520, yP = v ? 165 : 100, hP = v ? 255 : 580;
    o += painelAn(xP, yP, wP, hP) + t(xP + 20, yP + 30, "PRESIDENTE", { s: 14, b: true, c: "#c9d6e6", ls: 2 });
    if (df && df.nome) {
      var cE = cs.filter(function (c) { return String(c.numero) === String(df.numero); })[0] || cs[0];
      o += r(xP + 20, yP + 46, 6, 66 * k, cor(cE), 2) + t(xP + 36, yP + 76 * k, df.nome, { s: Math.round(26 * k), b: true, max: wP - 60 });
      o += t(xP + 36, yP + 104 * k, df.tipo === "tse" ? "ELEITO — declarado pelo TSE" : "MATEMATICAMENTE ELEITO", { s: Math.round(15 * k), b: true, c: "#8ce99a" });
      o += t(xP + 20, yP + 160 * k, hhmmTse(df.hora), { s: Math.round(60 * k), b: true }) + t(xP + 20, yP + 186 * k, "com " + pct(df.urnas) + " das urnas apuradas", { s: Math.round(16 * k), c: "#c9d6e6" });
    } else {
      o += t(xP + 20, yP + 80 * k, "AINDA NÃO DEFINIDO", { s: Math.round(26 * k), b: true });
      o += t(xP + 20, yP + 108 * k, "urnas: " + pct(f.br.secoes ? f.br.secoes.pct : 0) + " · " + diferenca(cs), { s: Math.round(13 * k), c: "#c9d6e6", max: wP - 40 });
    }
    var yT = yP + (v ? 222 : 240);
    o += t(xP + 20, yT, "LIDERANÇA TROCOU DE MÃOS: " + tl.trocas + (tl.trocas === 1 ? " VEZ" : " VEZES"), { s: Math.round(15 * k), b: true, max: wP - 40 });
    if (tl.desde && tl.lider) o += t(xP + 20, yT + 24 * k, tl.lider + " lidera desde " + hhmm(Date.parse(tl.desde.t)) + " (" + pct(tl.desde.u) + " das urnas)", { s: Math.round(13 * k), c: "#c9d6e6", max: wP - 40 });
    if (!v) o += t(xP + 20, yT + 60, "MATEMATICAMENTE ELEITO = o 1º tem mais votos que o 2º", { s: 12, c: C.apagado }) + t(xP + 20, yT + 78, "somado a TODOS os eleitores das seções que faltam", { s: 12, c: C.apagado });
    // governadores
    var dg = E().definicoes_gov || {}, lst = Object.keys(dg).map(function (kk) { var x = dg[kk]; return { k: kk, x: x, h: hhmmTse(x.hora) }; });
    lst.sort(function (p, q) { return p.h.localeCompare(q.h) || p.k.localeCompare(q.k); });
    var abertos = Object.keys(DEP_UF).filter(function (kk) { var st = govEstado(kk); return st.tipo === "segundo" && !dg[kk]; });
    var xG = v ? 35 : 613, wG = v ? 470 : 594, yG = v ? 440 : 100, hG = v ? 480 : 580;
    o += painelAn(xG, yG, wG, hG) + t(xG + 20, yG + 30, "GOVERNADORES DO 2º TURNO — ORDEM DA DEFINIÇÃO", { s: Math.round(14 * k), b: true, c: "#c9d6e6", ls: 1, max: wG - 40 });
    if (!lst.length) o += t(xG + 20, yG + 70, "nenhum governador definido ainda", { s: Math.round(18 * k), c: C.apagado });
    var passo = v ? 34 : 40;
    lst.slice(0, v ? 11 : 12).forEach(function (l, i) {
      var y = yG + 52 + i * passo;
      o += r(xG + 14, y, wG - 28, passo - 5, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 4);
      o += t(xG + 26, y + passo / 2 + 3, l.h, { s: Math.round(18 * k), b: true }) + t(xG + 96, y + passo / 2 + 3, l.k.toUpperCase(), { s: Math.round(16 * k), b: true, c: "#7fb8ff" });
      o += t(xG + 140, y + passo / 2 + 3, l.x.nome + " (" + l.x.partido + ")", { s: Math.round(14 * k), b: true, max: wG - 300 });
      o += t(xG + wG - 26, y + passo / 2 + 3, pct(l.x.urnas) + (l.x.tipo === "tse" ? " · TSE" : " · matemático"), { s: Math.round(12 * k), c: "#c9d6e6", a: "end" });
    });
    if (abertos.length) o += t(xG + 20, yG + hG - 18, "ainda em aberto: " + abertos.map(function (x) { return x.toUpperCase(); }).join(" "), { s: Math.round(14 * k), b: true, c: "#ffd8a8", max: wG - 40 });
    return svg(W, H, o + rodAn(v, "Fonte: TSE — hora do boletim em que a disputa ficou decidida (TSE ou conta com os números do próprio boletim)"));
  }
  G["definicao-h"] = function () { return telaDefinicao(false); };
  G["definicao-v"] = function () { return telaDefinicao(true); };

  // ---- A6. SEM ESTE ESTADO, QUEM VENCERIA? ----------------------------------
  function telaSemUf(v) {
    var f = fontePres(false), cs = fin2(f), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "SEM ESTE ESTADO, QUEM VENCERIA?";
    var sub = "Presidente · a diferença nacional tirando os votos de um estado de cada vez";
    if (!cs) return vazioAn(v, tit, sub, f, "disponível no 2º turno");
    var A = cs[0], B = cs[1], M = votosDe(f.br, A) - votosDe(f.br, B);
    if (!(M > 0)) return vazioAn(v, tit, sub, f, "aguardando as primeiras urnas do 2º turno");
    var ls = Object.keys(DEP_UF).map(function (k) { var x = f.uf(k); if (!x) return null; var d = votosDe(x, A) - votosDe(x, B); return { k: k, d: d, sem: M - d }; }).filter(Boolean);
    ls.sort(function (p, q) { return q.d - p.d; });
    var vira = ls.filter(function (l) { return l.sem < 0; }), o = cabAn(v, W, tit, sub, f), k = v ? 0.82 : 1, xP = v ? 35 : 73, wP = v ? 470 : 1134;
    o += painelAn(xP, v ? 165 : 100, wP, v ? 120 : 90);
    o += t(xP + 20, v ? 198 : 134, nomeCurto(A) + " à frente por " + inteiro(M) + " votos", { s: Math.round(24 * k), b: true, max: wP - 40 });
    o += t(xP + 20, v ? 228 : 166, vira.length ? vira.length + (vira.length === 1 ? " estado" : " estados") + " sozinho(s) mudaria(m) o resultado: " + vira.map(function (l) { return l.k.toUpperCase(); }).join(" ") : "nenhum estado sozinho muda o resultado: a vantagem é maior que o saldo de qualquer estado",
      { s: Math.round(16 * k), b: true, c: vira.length ? "#ffd8a8" : "#8ce99a", max: wP - 40 });
    var y0 = v ? 320 : 222, n = v ? 14 : 12, passo = v ? 42 : 38, max = Math.max.apply(null, ls.map(function (l) { return Math.abs(l.d); }).concat([1]));
    o += t(xP, y0 - 10, "OS ESTADOS QUE MAIS PESAM (saldo de " + nomeCurto(A) + " sobre " + nomeCurto(B) + ")", { s: Math.round(13 * k), b: true, c: "#c9d6e6", ls: 1, max: wP });
    var top = ls.slice().sort(function (p, q) { return Math.abs(q.d) - Math.abs(p.d); }).slice(0, v ? n : 2 * n);
    top.forEach(function (l, i) {
      var col = v ? 0 : Math.floor(i / n), li = v ? i : i % n, wC = v ? 470 : 559, x = xP + col * (wC + 16), y = y0 + li * passo;
      var c = l.d >= 0 ? A : B, wBar = v ? 110 : 150, wb = wBar * Math.abs(l.d) / max, pn = function (cc) { return String(cc.nome || "").split(" ")[0]; };
      o += r(x, y, wC, passo - 4, l.sem < 0 ? "rgba(255,216,168,0.12)" : (li % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.06)"), 4);
      o += t(x + 10, y + passo / 2 + 4, l.k.toUpperCase(), { s: 15, b: true }) + r(x + 50, y + passo / 2 - 6, Math.max(3, wb), 12, cor(c), 3);
      o += t(x + 58 + wBar, y + passo / 2 + 4, (l.d >= 0 ? "+" : "−") + milTxt(l.d) + " " + pn(c), { s: Math.round(13 * k), b: true, max: 130 });
      o += t(x + wC - 10, y + passo / 2 + 4, l.sem < 0 ? "sem ele: " + pn(B) + " vence" : "sem ele: " + pn(A) + " +" + milTxt(l.sem), { s: Math.round(13 * k), b: l.sem < 0, c: l.sem < 0 ? "#ffd8a8" : "#c9d6e6", a: "end", max: wC - wBar - 200 });
    });
    return svg(W, H, o + rodAn(v, "Fonte: TSE — conta: diferença nacional (inclui o exterior) menos a diferença do estado · só matemática, sem projeção"));
  }
  G["semuf-h"] = function () { return telaSemUf(false); };
  G["semuf-v"] = function () { return telaSemUf(true); };

  // ---- A7. QUANTO CADA ESTADO SE MOVEU: 2022 -> 2026 ------------------------
  function telaPendulo(v) {
    var f = fontePres(false), cs = fin2(f), R = ref22(), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "QUANTO CADA ESTADO SE MOVEU";
    var sub = "Presidente · 2º turno de 2022 × 2º turno de 2026 · diferença entre os partidos dos dois finalistas";
    if (!cs) return vazioAn(v, tit, sub, f, "disponível no 2º turno");
    if (!R) return vazioAn(v, tit, sub, f, "aguardando o 2º turno de 2022 do TSE (ESTADOS.bat)");
    var A = cs[0], B = cs[1], sa = String(A.partido).toUpperCase(), sb = String(B.partido).toUpperCase();
    function mov(r22, x26) {
      if (!r22 || r22[sa] == null || r22[sb] == null || !x26) return null;
      var a = pctCandAn(x26, A), b = pctCandAn(x26, B); if (a == null || b == null || !(a + b > 0)) return null;
      var m22 = +r22[sa] - +r22[sb], m26 = a - b; return { m22: m22, m26: m26, s: m26 - m22 };
    }
    var nb = mov(R.br, f.br);
    if (!nb) return vazioAn(v, tit, sub, f, sa + " ou " + sb + " não disputou o 2º turno de 2022: não há o que comparar");
    var ls = Object.keys(DEP_UF).map(function (k) { var x = f.uf(k); var m = x && x.secoes && x.secoes.pct > 0 ? mov((R.ufs || {})[k], x) : null; return m ? { k: k, m: m } : null; }).filter(Boolean);
    ls.sort(function (p, q) { return q.m.s - p.m.s; });
    var o = cabAn(v, W, tit, sub, f), k = v ? 0.82 : 1, xP = v ? 35 : 73, wP = v ? 470 : 1134;
    function lado(m) { return m >= 0 ? sa + " +" + Math.abs(m).toFixed(1).replace(".", ",") : sb + " +" + Math.abs(m).toFixed(1).replace(".", ","); }
    o += painelAn(xP, v ? 165 : 100, wP, v ? 110 : 80);
    o += t(xP + 20, v ? 196 : 132, "BRASIL: 2022 " + lado(nb.m22) + " → 2026 " + lado(nb.m26), { s: Math.round(20 * k), b: true, max: wP - 40 });
    o += t(xP + 20, v ? 226 : 160, "o país se moveu " + Math.abs(nb.s).toFixed(1).replace(".", ",") + " pontos na direção do " + (nb.s >= 0 ? sa : sb), { s: Math.round(15 * k), c: "#c9d6e6", max: wP - 40 });
    var y0 = v ? 305 : 210, n = v ? 15 : 13, passo = v ? 40 : 34, max = Math.max.apply(null, ls.map(function (l) { return Math.abs(l.m.s); }).concat([1]));
    var lv = v ? ls.slice(0, 8).concat(ls.slice(-7)) : ls;
    lv.slice(0, v ? n : 2 * n + 1).forEach(function (l, i) {
      var col = v ? 0 : Math.floor(i / (n + 1)), li = v ? i : i % (n + 1), wC = v ? 470 : 559, x = xP + col * (wC + 16), y = y0 + li * passo;
      var meio = x + 60 + (wC - 200) / 2, wb = ((wC - 200) / 2) * Math.abs(l.m.s) / max, c = l.m.s >= 0 ? A : B;
      o += r(x, y, wC, passo - 4, li % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.06)", 4) + t(x + 10, y + passo / 2 + 4, l.k.toUpperCase(), { s: 15, b: true });
      o += r(meio - 1, y + 3, 2, passo - 10, "rgba(255,255,255,0.35)", 0);
      o += l.m.s >= 0 ? r(meio + 1, y + passo / 2 - 7, Math.max(3, wb), 12, cor(A), 3) : r(meio - 1 - Math.max(3, wb), y + passo / 2 - 7, Math.max(3, wb), 12, cor(B), 3);
      o += t(x + wC - 10, y + passo / 2 + 4, Math.abs(l.m.s).toFixed(1).replace(".", ",") + " p.p. → " + (l.m.s >= 0 ? sa : sb), { s: Math.round(12 * k), b: true, a: "end", c: "#c9d6e6" });
    });
    return svg(W, H, o + rodAn(v, "Fonte: TSE — 2º turno de Presidente 2022 (final) e 2026 · diferença " + sa + " − " + sb + " em pontos dos votos válidos · 2018 por estado não está nos arquivos do TSE"));
  }
  G["pendulo-h"] = function () { return telaPendulo(false); };
  G["pendulo-v"] = function () { return telaPendulo(true); };

  // ---- A8. VOTO CRUZADO: governador × presidente ----------------------------
  function telaCruzado(v) {
    var f = fontePres(false), cs = fin2(f), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "VOTO CRUZADO";
    var sub = "governador eleito × quem lidera para Presidente no estado · campo = partidos da coligação de cada finalista";
    if (!cs) return vazioAn(v, tit, sub, f, "disponível no 2º turno");
    var cA = coligDe(cs[0]), cB = coligDe(cs[1]), grupos = { mesmo: [], oposto: [], fora: [] };
    Object.keys(DEP_UF).forEach(function (k) {
      var st = govEstado(k), lp = liderF(f, k);
      if (!(st.tipo === "eleito1" || st.tipo === "eleito2") || !st.c || !lp) return;
      var g = normSg(st.c.partido), meu = String(lp.numero) === String(cs[0].numero) ? cA : cB, outro = meu === cA ? cB : cA;
      var cls = meu.indexOf(g) >= 0 ? "mesmo" : outro.indexOf(g) >= 0 ? "oposto" : "fora";
      grupos[cls].push({ k: k, gov: st.c, pres: lp });
    });
    var n = grupos.mesmo.length + grupos.oposto.length + grupos.fora.length;
    if (!n) return vazioAn(v, tit, sub, f, "aguardando governadores eleitos e o Presidente nos estados");
    var o = cabAn(v, W, tit, sub, f), k = v ? 0.82 : 1;
    var cols = [["oposto", "CAMPO OPOSTO", "#ffd8a8", "governador da coligação do adversário de quem lidera ali"], ["mesmo", "MESMO CAMPO", "#8ce99a", "governador da coligação de quem lidera ali"], ["fora", "FORA DAS DUAS", "#c9d6e6", "partido do governador não está em nenhuma das duas coligações"]];
    cols.forEach(function (cc, j) {
      var ls = grupos[cc[0]], x = v ? 35 : 73 + j * 383, y = v ? 165 + j * 255 : 100, w = v ? 470 : 367, h = v ? 245 : 580;
      o += painelAn(x, y, w, h) + r(x, y, w, 5, cc[2], 3);
      o += t(x + 16, y + 36 * k, cc[1], { s: Math.round(20 * k), b: true, c: cc[2] }) + t(x + w - 16, y + 36 * k, ls.length + (ls.length === 1 ? " estado" : " estados"), { s: Math.round(18 * k), b: true, a: "end" });
      o += t(x + 16, y + 56 * k, cc[3], { s: Math.round(11 * k), c: C.apagado, max: w - 32 });
      var passo = v ? 28 : 44, max = v ? 5 : 11;
      ls.slice(0, max).forEach(function (l, i) {
        var yy = y + (v ? 78 : 78) + i * passo;
        o += t(x + 16, yy + 16, l.k.toUpperCase(), { s: Math.round(15 * k), b: true });
        o += t(x + 56, yy + (v ? 16 : 10), "gov " + l.gov.nome + " (" + l.gov.partido + ")", { s: Math.round(12 * k), b: true, max: w - 72 });
        if (!v) o += t(x + 56, yy + 28, "pres: " + nomeCurto(l.pres) + " " + pct(l.pres.pct), { s: 12, c: "#c9d6e6", max: w - 72 });
      });
      if (ls.length > max) o += t(x + 16, y + h - 12, "+ " + (ls.length - max) + ": " + ls.slice(max).map(function (l) { return l.k.toUpperCase(); }).join(" "), { s: Math.round(12 * k), c: C.apagado, max: w - 32 });
    });
    return svg(W, H, o + rodAn(v, "Fonte: TSE — governador eleito (1º ou 2º turno), Presidente no estado e coligações registradas · " + nomeCurto(cs[0]) + ": " + cA.join(", ") + " · " + nomeCurto(cs[1]) + ": " + cB.join(", ")));
  }
  G["cruzado-h"] = function () { return telaCruzado(false); };
  G["cruzado-v"] = function () { return telaCruzado(true); };

  // ---- A9. PERFIL DO ELEITORADO × RESULTADO --------------------------------
  function perfilUf(k) {
    var P = window.GCTSE_PERFIL, x = P && P.eleitorado && P.eleitorado.ufs ? P.eleitorado.ufs[k] : null; if (!x) return null;
    function fr(d, rots) { var gp = agruparPerfil(x, d); if (!gp || !gp.inf) return null; var s = 0; gp.itens.forEach(function (it) { if (rots.indexOf(it.rot) >= 0) s += it.a; }); return 100 * s / gp.inf; }
    return { sup: fr("escolaridade", ["Superior"]), jov: fr("idade", ["16 e 17", "18 a 24"]), ido: fr("idade", ["60 a 69", "70 ou mais"]), mul: fr("genero", ["Mulheres"]) };
  }
  function telaPerfilRes(v) {
    var f = fontePres(false), cs = fin2(f), W = v ? 540 : 1280, H = v ? 960 : 720, tit = "PERFIL DO ELEITORADO × RESULTADO";
    var sub = "os estados com mais eleitores de cada perfil e quem lidera para Presidente em cada um";
    if (!cs) return vazioAn(v, tit, sub, f, "disponível no 2º turno");
    var ls = Object.keys(DEP_UF).map(function (k) { var p = perfilUf(k), l = liderF(f, k); return p && l ? { k: k, p: p, l: l } : null; }).filter(Boolean);
    if (!ls.length) return vazioAn(v, tit, sub, f, "importe o perfil do eleitorado por estado (IMPORTAR-PERFIL-ELEITOR.bat)");
    var o = cabAn(v, W, tit, sub, f), k = v ? 0.82 : 1;
    var pain = [["sup", "MAIS ENSINO SUPERIOR"], ["jov", "MAIS JOVENS (16 A 24 ANOS)"], ["ido", "MAIS IDOSOS (60 ANOS OU MAIS)"], ["supMenos", "MENOS ENSINO SUPERIOR"]];
    pain.forEach(function (pn, j) {
      var campo = pn[0] === "supMenos" ? "sup" : pn[0], vs = ls.filter(function (l) { return l.p[campo] != null; }).sort(function (a, b) { return pn[0] === "supMenos" ? a.p[campo] - b.p[campo] : b.p[campo] - a.p[campo]; }).slice(0, v ? 5 : 6);
      var x = v ? 35 : 73 + (j % 2) * 575, y = v ? 165 + j * 192 : 100 + Math.floor(j / 2) * 296, w = v ? 470 : 559, h = v ? 182 : 284;
      var placar = {}; vs.forEach(function (l) { placar[l.l.numero] = (placar[l.l.numero] || 0) + 1; });
      var cTop = cs.filter(function (c) { return placar[c.numero]; }).sort(function (a, b) { return placar[b.numero] - placar[a.numero]; })[0];
      o += painelAn(x, y, w, h) + t(x + 16, y + 28 * k, pn[1], { s: Math.round(14 * k), b: true, c: "#c9d6e6", ls: 1, max: w - 32 });
      if (cTop) o += t(x + w - 16, y + 28 * k, String(cTop.nome).split(" ")[0] + " lidera em " + placar[cTop.numero] + " de " + vs.length, { s: Math.round(13 * k), b: true, a: "end", c: "#ffd8a8" });
      var passo = v ? 28 : 40;
      vs.forEach(function (l, i) {
        var yy = y + (v ? 42 : 46) + i * passo;
        o += r(x + 12, yy, w - 24, passo - 4, i % 2 ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)", 4);
        o += t(x + 22, yy + passo / 2 + 3, l.k.toUpperCase(), { s: Math.round(15 * k), b: true }) + t(x + 64, yy + passo / 2 + 3, pct1v(l.p[campo]) + " do eleitorado", { s: Math.round(13 * k), c: "#c9d6e6" });
        o += r(x + w - 230, yy + 5, 5, passo - 14, cor(l.l), 2) + t(x + w - 218, yy + passo / 2 + 3, String(l.l.nome).split(" ")[0], { s: Math.round(13 * k), b: true, max: 120 }) + t(x + w - 22, yy + passo / 2 + 3, pct(l.l.pct), { s: Math.round(14 * k), b: true, a: "end" });
      });
    });
    return svg(W, H, o + rodAn(v, "Fonte: TSE — perfil do eleitorado 2026 (Dados Abertos) e boletim de Presidente · descrição lado a lado: não mostra em quem cada grupo votou"));
  }
  G["perfilres-h"] = function () { return telaPerfilRes(false); };
  G["perfilres-v"] = function () { return telaPerfilRes(true); };

  // ---- A10. PRESIDENTE EM CADA CIDADE (mapa por municipio) ------------------
  var IDX_MUN = { em: "", ibge: {}, nome: {} };
  function indiceMun() {
    var R = window.GCTSE_MUN; if (!R || !R.ufs) return null;
    if (IDX_MUN.em === R.gravado_em) return IDX_MUN;
    var ib = {}, nm = {};
    Object.keys(R.ufs).forEach(function (u) { var m = R.ufs[u]; Object.keys(m).forEach(function (cd) { var x = comoLista(m[cd]); var rec = { uf: u, cd: cd, cdi: x[0], nome: x[1], urnas: x[2], votos: x[3] || {}, l1: x[4], p1: x[5] }; if (rec.cdi) ib[rec.cdi] = rec; nm[u + "|" + semAcento(rec.nome)] = rec; }); });
    IDX_MUN = { em: R.gravado_em, ibge: ib, nome: nm };
    return IDX_MUN;
  }
  function alvoMun() {
    var a = String(window.__gctseAlvo || "").toLowerCase();
    if (!a) { try { a = (new URLSearchParams(location.search).get("a") || "").toLowerCase(); } catch (e) { a = ""; } }
    return DEP_UF[a] ? a : "br";
  }
  // 3.29.5: o que a coleta MUNICIPIOS esta fazendo (gravado no municipios.js)
  function situacaoMun(R, lidos) {
    if (!R) return "aguardando a coleta dos municípios: abra o MUNICIPIOS.bat";
    var tot = +R.total || 0, pos = +R.pos || 0, err = String(R.ultimo_erro || "");
    if (err && !(+R.lidos_2t > 0)) return "o TSE não respondeu à coleta dos municípios: " + err.replace(/https?:\/\/[^ ]*\/dados\//, ".../") + " (veja logs\\municipios-*.log)";
    if (R.fase === "lista" || !tot) return "aguardando a lista de municípios do TSE (MUNICIPIOS.bat)";
    if (R.fase === "2t") return "lendo o 2º turno das cidades: " + inteiro(pos) + " de " + inteiro(tot) + " (o mapa aparece aos poucos)";
    return "sem voto do 2º turno nas cidades: confira se o MUNICIPIOS.bat está aberto (" + inteiro(lidos || 0) + " cidades no arquivo)";
  }
  function telaMunMapa(v) {
    var f = fontePres(false), cs = fin2(f), M = window.MAPA_MUN, R = window.GCTSE_MUN, a = alvoMun(), W = v ? 540 : 1280, H = v ? 960 : 720;
    var tit = a === "br" ? "PRESIDENTE EM CADA CIDADE" : "CIDADES — " + DEP_UF[a], sub = "quem lidera em cada município · cor forte = vantagem de 15 pontos ou mais";
    if (!cs) return vazioAn(v, tit, sub, f, "disponível no 2º turno");
    if (!M || !M.ufs) return vazioAn(v, tit, sub, f, "falta o arquivo do mapa (web\\mapa-municipios.js)");
    var ix = indiceMun(); if (!ix) return vazioAn(v, tit, sub, f, situacaoMun(R, 0));
    var A = cs[0], B = cs[1], ufsV = a === "br" ? Object.keys(M.ufs) : [a], bb = null;
    ufsV.forEach(function (u) { var b = M.ufs[u] && M.ufs[u].bbox; if (!b) return; bb = bb ? [Math.min(bb[0], b[0]), Math.min(bb[1], b[1]), Math.max(bb[2], b[2]), Math.max(bb[3], b[3])] : b.slice(); });
    if (!bb) return vazioAn(v, tit, sub, f, "estado sem mapa");
    var ax = v ? 35 : 73, ay = v ? 165 : 100, aw = v ? 470 : 700, ah = v ? 520 : 590;
    var esc0 = Math.min(aw / (bb[2] - bb[0]), ah / (bb[3] - bb[1])), ox = ax + (aw - (bb[2] - bb[0]) * esc0) / 2 - bb[0] * esc0, oy = ay + (ah - (bb[3] - bb[1]) * esc0) / 2 - bb[1] * esc0;
    var cont = { A: 0, B: 0, sem: 0, virouA: 0, virouB: 0, lidos: 0, fim: 0 }, paths = "", sw = (0.5 / esc0).toFixed(2);
    ufsV.forEach(function (u) {
      var mm = (M.ufs[u] || {}).mun || {};
      Object.keys(mm).forEach(function (ib) {
        var mun = mm[ib], rec = ix.ibge[ib] || ix.nome[u + "|" + semAcento(mun[0])], va = rec ? +rec.votos[A.numero] || 0 : 0, vb = rec ? +rec.votos[B.numero] || 0 : 0, fill = C.semDado, op = 1;
        if (rec) { cont.lidos++; if (+rec.urnas >= 100) cont.fim++; }
        if (va + vb > 0) {
          var lA = va >= vb, mg = Math.abs(va - vb) / (va + vb) * 100; fill = cor(lA ? A : B); op = mg >= 15 ? 1 : mg >= 5 ? 0.72 : 0.45;
          if (lA) cont.A++; else cont.B++;
          if (rec.l1 && String(rec.l1) !== String(lA ? A.numero : B.numero) && (String(rec.l1) === String(A.numero) || String(rec.l1) === String(B.numero))) { if (lA) cont.virouA++; else cont.virouB++; }
        } else cont.sem++;
        paths += '<path d="' + mun[1] + '" fill="' + fill + '"' + (op < 1 ? ' fill-opacity="' + op + '"' : "") + ' stroke="#0b1220" stroke-width="' + sw + '"/>';
      });
    });
    // 3.29.3: arquivo das cidades sem nenhum voto do 2o turno (MUNICIPIOS.bat
    // fechado ou ainda na 1a volta): diz o motivo em vez de um mapa cinza
    if (!(cont.A + cont.B)) return vazioAn(v, tit, sub, f, situacaoMun(R, cont.lidos));
    var o = cabAn(v, W, tit, sub, f) + '<g transform="translate(' + ox.toFixed(1) + " " + oy.toFixed(1) + ") scale(" + esc0.toFixed(5) + ')">' + paths + "</g>";
    var xs = v ? 35 : 800, ys = v ? 700 : 110, ws = v ? 470 : 407, k = v ? 0.85 : 1;
    o += painelAn(xs, ys, ws, v ? 220 : 570);
    var tot = cont.A + cont.B;
    [A, B].forEach(function (c, i) {
      var n = i ? cont.B : cont.A, yy = ys + (v ? 34 : 44) + i * (v ? 62 : 92);
      o += r(xs + 16, yy - 22 * k, 6, 50 * k, cor(c), 2) + t(xs + 32, yy, nomeCurto(c), { s: Math.round(20 * k), b: true, max: ws - 160 }) + t(xs + ws - 16, yy, inteiro(n), { s: Math.round(30 * k), b: true, a: "end" });
      o += t(xs + 32, yy + 22 * k, "lidera em " + (tot ? pct(100 * n / tot).replace(",00", "") : "—") + " das cidades com voto", { s: Math.round(13 * k), c: "#c9d6e6" });
    });
    var yv = ys + (v ? 164 : 250);
    if (D().turno1 && (cont.virouA + cont.virouB) > 0) {
      o += t(xs + 16, yv, "VIRARAM DESDE O 1º TURNO", { s: Math.round(13 * k), b: true, c: "#ffd8a8", ls: 1 });
      o += t(xs + 16, yv + 24 * k, nomeCurto(A) + " tomou " + cont.virouA + " · " + nomeCurto(B) + " tomou " + cont.virouB, { s: Math.round(15 * k), b: true, max: ws - 32 });
    }
    var yl = ys + (v ? 206 : 340);
    if (!v) {
      o += t(xs + 16, yl, "COR", { s: 12, b: true, c: "#c9d6e6", ls: 2 });
      [[1, "15 pontos ou mais"], [0.72, "5 a 15 pontos"], [0.45, "menos de 5 pontos"]].forEach(function (lg, i) {
        o += '<rect x="' + (xs + 16) + '" y="' + (yl + 12 + i * 26) + '" width="18" height="16" rx="2" fill="' + cor(A) + '" fill-opacity="' + lg[0] + '"/>' + '<rect x="' + (xs + 38) + '" y="' + (yl + 12 + i * 26) + '" width="18" height="16" rx="2" fill="' + cor(B) + '" fill-opacity="' + lg[0] + '"/>' + t(xs + 66, yl + 25 + i * 26, lg[1], { s: 13, c: "#c9d6e6" });
      });
      o += r(xs + 16, yl + 92, 40, 16, C.semDado, 2) + t(xs + 66, yl + 105, "sem voto ainda / sem boletim", { s: 13, c: "#c9d6e6" });
      o += t(xs + 16, ys + 540, "cidades lidas: " + inteiro(cont.lidos) + " · com 100% das urnas: " + inteiro(cont.fim), { s: 12, c: C.apagado, max: ws - 32 });
    } else o += t(xs + 16, ys + 206, "lidas: " + inteiro(cont.lidos) + " · 100%: " + inteiro(cont.fim), { s: 11, c: C.apagado });
    return svg(W, H, o + rodAn(v, "Fonte: TSE — boletim de Presidente de cada município (MUNICIPIOS.bat) · malha municipal: IBGE"));
  }
  G["munmapa-h"] = function () { return telaMunMapa(false); };
  G["munmapa-v"] = function () { return telaMunMapa(true); };

  // ---- TELA "AGUARDANDO O TSE" (automatica) ---------------------------------
  // Tela no ar sem o dado de que ela depende (antes das 17h, boletim ainda nao
  // lido, coleta recem-aberta): em vez de numeros zerados, uma tela limpa
  // com o nome da tela. Volta sozinha quando o dado chega.
  var SEM_PRESIDENTE = /^(pres1t|presloc1t|presmapa1t|regioes1t|senado|comparativo|mulheres|perfilcamara|camara|deputados|topdep|topfem|topsenfem|perfileleitor|foiurnas|menosvot|senvotos|gov22|assembleia|assembleias|governadores|govpartido|gov2t|gov12|senadores|senadores1|senadores2)-/;
  var DE_ESTADOS = /^(camara|deputados|topdep|topfem|topsenfem|menosvot|senvotos|gov22|assembleia|assembleias|governadores|govpartido|gov2t|gov12|senadores|senadores1|senadores2|govpres|governab|cruzado|pendulo)-/;
  // Presidente "tem dado" com o boletim do TSE publicado - inclusive ZERADO
  // (o 2o turno sai com 0% antes das 17h: e o dado real, como no app do TSE).
  function temPresidente() { var b = D().br; return !!(b && b.tem); }
  function temEstados() { return !!(window.GCTSE_ESTADOS && window.GCTSE_ESTADOS.gravado_em); }
  function telaAguardando(id) {
    var v = /-v$/.test(id), W = v ? 540 : 1280, H = v ? 960 : 720;
    var g = (window.GCTSE_GRAFICOS ? window.GCTSE_GRAFICOS.lista : []).filter(function (x) { return x.id === id; })[0], nm = String(g ? g.nome : "").toUpperCase();
    var sl = { texto: "AGUARDANDO APURAÇÃO", cor: C.trilho }; marcaVazio();
    var o = v ? r(35, 48, 6, 38, C.destaque) + t(53, 80, nm, { s: 26, b: true, ls: 1, max: 450 }) + seloV(W, sl) : t(73, 57, nm, { s: 34, b: true, ls: 1, max: 660 }) + seloH(W, sl);
    o += t(W / 2, H / 2 - (v ? 10 : 6), "AGUARDANDO O TSE", { s: v ? 34 : 52, b: true, a: "middle", ls: 3 });
    o += t(W / 2, H / 2 + (v ? 30 : 44), "os números aparecem assim que o TSE publicar", { s: v ? 16 : 22, c: C.apagado, a: "middle", max: W - 60 });
    return svg(W, H, o);
  }
  var VAZIA = false;
  function marcaVazio() { VAZIA = true; return ""; }
  function desenharTela(id) {
    if (!G[id]) return null;
    VAZIA = false;
    var out = ((!SEM_PRESIDENTE.test(id) && !temPresidente()) || (DE_ESTADOS.test(id) && !temEstados())) ? telaAguardando(id) : G[id]();
    if (VAZIA && typeof out === "string") out = out.replace("<svg", '<svg data-vazia="1"');
    return out;
  }
  // tem dado para ir ao ar? (o gerenciador e o rodizio perguntam)
  function temDados(id) {
    try { var o = desenharTela(id); return !!o && !VAZIA; } catch (e) { try { console.warn("tela " + id + " deu erro: " + e.message); } catch (x) { } return false; }
  }
  window.GCTSE_EXTERIOR_SEM_PAIS = exteriorSemPais;
  window.GCTSE_GRAFICOS = {
    lista: [
      { id: "eleito-h", nome: "Presidente eleito", f: "h" },
      { id: "presidente-h", nome: "Presidente — Brasil", f: "h" },
      { id: "votos-h", nome: "Como o Brasil votou", f: "h" },
      { id: "urnas-h", nome: "Apuração nacional", f: "h" },
      { id: "estados-h", nome: "Como cada estado votou", f: "h" },
      { id: "lideranca-h", nome: "Liderança por estado", f: "h" },
      { id: "abstencao-h", nome: "Abstenção, brancos e nulos", f: "h" },
      { id: "abstencao-mapa-h", nome: "Mapa da abstenção", f: "h" },
      { id: "pres2t-h", nome: "Presidente — 2º turno", f: "h" },
      { id: "senado-h", nome: "Senado: atual × 2027", f: "h" },
      { id: "comparativo-h", nome: "2018 × 2022 × 2026", f: "h" },
      { id: "camara-h", nome: "Câmara: bancadas 2027", f: "h" },
      { id: "evolucao-h", nome: "Evolução minuto a minuto (1º × 2º)", f: "h" },
      { id: "marcos-h", nome: "A noite da apuração (marcos)", f: "h" },
      { id: "duasnoites-h", nome: "As duas noites: 1º × 2º turno", f: "h" },
      { id: "deputados-h", nome: "Deputados federais eleitos", f: "h" },
      { id: "mulheres-h", nome: "Câmara: bancada feminina", f: "h" },
      { id: "apuracao-h", nome: "Apuração: regiões e estados", f: "h" },
      { id: "presmapa-h", nome: "Presidente + mapa", f: "h" },
      { id: "presmapa1t-h", nome: "Presidente + mapa — 1º turno", f: "h" },
      { id: "regioes-h", nome: "Presidente | Regiões", f: "h" },
      { id: "presloc-h", nome: "Presidente | Estado ou região", f: "h" },
      { id: "presloc1t-h", nome: "Presidente 1º turno | Estado ou região", f: "h" },
      { id: "regioes1t-h", nome: "Presidente 1º turno | Regiões", f: "h" },
      { id: "pres1t-h", nome: "Presidente — 1º turno (todos os candidatos)", f: "h" },
      { id: "governadores-h", nome: "Governadores (1º verde · 2º azul)", f: "h" },
      { id: "govpartido-h", nome: "Governadores por partido", f: "h" },
      { id: "senadores-h", nome: "Senadores eleitos (foto + partido)", f: "h" },
      { id: "senadores1-h", nome: "Senadores 1/2 (AC a PA)", f: "h" },
      { id: "senadores2-h", nome: "Senadores 2/2 (PB a TO)", f: "h" },
      { id: "turnos-h", nome: "1º × 2º turno: abstenção, brancos e nulos", f: "h" },
      { id: "virar-h", nome: "Ainda dá para virar?", f: "h" },
      { id: "gov2t-h", nome: "Governadores — 2º turno (placar)", f: "h" },
      { id: "gov12-h", nome: "Governadores: 1º × 2º turno", f: "h" },
      { id: "viradas-h", nome: "Estados que viraram (1º → 2º)", f: "h" },
      { id: "margem-h", nome: "Disputa mais apertada", f: "h" },
      { id: "ganho-h", nome: "Ganho de votos 1º → 2º turno", f: "h" },
      { id: "abstuf-h", nome: "Abstenção 1º × 2º por estado", f: "h" },
      { id: "abstreg-h", nome: "Abstenção 1º × 2º: regiões e estados", f: "h" },
      { id: "comparec-h", nome: "Comparecimento 1º × 2º desde 2002", f: "h" },
      { id: "turno22-h", nome: "2º turno: 2022 × 2026 por estado", f: "h" },
      { id: "capitais-h", nome: "Presidente nas capitais", f: "h" },
      { id: "cidades-h", nome: "Presidente nas maiores cidades", f: "h" },
      { id: "ganhouf-h", nome: "Onde cada um cresceu (1º → 2º por estado)", f: "h" },
      { id: "faltam-h", nome: "Onde ainda há votos para apurar", f: "h" },
      { id: "exterior-h", nome: "Brasileiros no exterior (por país)", f: "h" },
      { id: "excidades-h", nome: "Exterior: por cidade", f: "h" },
      { id: "excomp-h", nome: "Exterior: 1º × 2º turno", f: "h" },
      { id: "exfinal-h", nome: "Exterior: resultado 1º e 2º turno", f: "h" },
      { id: "saldo-h", nome: "De onde veio a vantagem (saldo por estado)", f: "h" },
      { id: "mudou22-h", nome: "Mudou de lado desde 2022", f: "h" },
      { id: "intensidade-h", nome: "Intensidade da vitória (mapa)", f: "h" },
      { id: "concentracao-h", nome: "Concentração do voto", f: "h" },
      { id: "abst22-h", nome: "Abstenção 2º turno: 2022 × 2026", f: "h" },
      { id: "brnulos-h", nome: "Brancos e nulos: 1º × 2º turno", f: "h" },
      { id: "menosvot-h", nome: "Eleitos com menos votos (Câmara)", f: "h" },
      { id: "senvotos-h", nome: "Senado: votos por partido", f: "h" },
      { id: "gov22-h", nome: "Governadores por partido: 2022 × 2026", f: "h" },
      { id: "decisivos-h", nome: "Estados decisivos (6 maiores eleitorados)", f: "h" },
      { id: "govpres-h", nome: "Governador × Presidente no estado", f: "h" },
      { id: "perfilcamara-h", nome: "Perfil da nova Câmara", f: "h" },
      { id: "assembleia-h", nome: "Assembleia Legislativa (por estado)", f: "h" },
      { id: "assembleias-h", nome: "Assembleias — Brasil (por partido)", f: "h" },
      { id: "topdep-h", nome: "10 deputados federais mais votados", f: "h" },
      { id: "topfem-h", nome: "10 deputadas mais votadas", f: "h" },
      { id: "topsenfem-h", nome: "Senadoras eleitas", f: "h" },
      { id: "perfileleitor-h", nome: "Perfil do eleitorado", f: "h" },
      { id: "foiurnas-h", nome: "Quem foi às urnas (perfil)", f: "h" },
      { id: "eleito-v", nome: "Presidente eleito", f: "v" },
      { id: "urnas-v", nome: "Urnas apuradas", f: "v" },
      { id: "votos-v", nome: "Brancos e nulos", f: "v" },
      { id: "presidente-v", nome: "Presidente", f: "v" },
      { id: "comparecimento-v", nome: "Comparecimento", f: "v" },
      { id: "lideranca-v", nome: "Liderança por estado", f: "v" },
      { id: "abstencao-v", nome: "Abstenção, brancos e nulos", f: "v" },
      { id: "abstencao-mapa-v", nome: "Mapa da abstenção", f: "v" },
      { id: "pres2t-v", nome: "Presidente — 2º turno", f: "v" },
      { id: "senado-v", nome: "Senado: 2027", f: "v" },
      { id: "comparativo-v", nome: "2018 × 2022 × 2026", f: "v" },
      { id: "camara-v", nome: "Câmara: bancadas 2027", f: "v" },
      { id: "evolucao-v", nome: "Evolução minuto a minuto (1º × 2º)", f: "v" },
      { id: "marcos-v", nome: "A noite da apuração (marcos)", f: "v" },
      { id: "duasnoites-v", nome: "As duas noites: 1º × 2º turno", f: "v" },
      { id: "deputados-v", nome: "Deputados federais eleitos", f: "v" },
      { id: "mulheres-v", nome: "Câmara: bancada feminina", f: "v" },
      { id: "apuracao-v", nome: "Apuração: regiões", f: "v" },
      { id: "presmapa-v", nome: "Presidente + mapa", f: "v" },
      { id: "presmapa1t-v", nome: "Presidente + mapa — 1º turno", f: "v" },
      { id: "regioes-v", nome: "Presidente | Regiões", f: "v" },
      { id: "presloc-v", nome: "Presidente | Estado ou região", f: "v" },
      { id: "presloc1t-v", nome: "Presidente 1º turno | Estado ou região", f: "v" },
      { id: "regioes1t-v", nome: "Presidente 1º turno | Regiões", f: "v" },
      { id: "pres1t-v", nome: "Presidente — 1º turno (todos os candidatos)", f: "v" },
      { id: "governadores-v", nome: "Governadores (1º verde · 2º azul)", f: "v" },
      { id: "govpartido-v", nome: "Governadores por partido", f: "v" },
      { id: "senadores-v", nome: "Senadores eleitos (foto + partido)", f: "v" },
      { id: "senadores1-v", nome: "Senadores 1/2 (AC a PA)", f: "v" },
      { id: "senadores2-v", nome: "Senadores 2/2 (PB a TO)", f: "v" },
      { id: "turnos-v", nome: "1º × 2º turno: abstenção, brancos e nulos", f: "v" },
      { id: "virar-v", nome: "Ainda dá para virar?", f: "v" },
      { id: "gov2t-v", nome: "Governadores — 2º turno (placar)", f: "v" },
      { id: "gov12-v", nome: "Governadores: 1º × 2º turno", f: "v" },
      { id: "viradas-v", nome: "Estados que viraram (1º → 2º)", f: "v" },
      { id: "margem-v", nome: "Disputa mais apertada", f: "v" },
      { id: "ganho-v", nome: "Ganho de votos 1º → 2º turno", f: "v" },
      { id: "abstuf-v", nome: "Abstenção 1º × 2º por estado", f: "v" },
      { id: "abstreg-v", nome: "Abstenção 1º × 2º: regiões e estados", f: "v" },
      { id: "comparec-v", nome: "Comparecimento 1º × 2º desde 2002", f: "v" },
      { id: "turno22-v", nome: "2º turno: 2022 × 2026 por estado", f: "v" },
      { id: "capitais-v", nome: "Presidente nas capitais", f: "v" },
      { id: "cidades-v", nome: "Presidente nas maiores cidades", f: "v" },
      { id: "ganhouf-v", nome: "Onde cada um cresceu (1º → 2º por estado)", f: "v" },
      { id: "faltam-v", nome: "Onde ainda há votos para apurar", f: "v" },
      { id: "exterior-v", nome: "Brasileiros no exterior (por país)", f: "v" },
      { id: "excidades-v", nome: "Exterior: por cidade", f: "v" },
      { id: "excomp-v", nome: "Exterior: 1º × 2º turno", f: "v" },
      { id: "exfinal-v", nome: "Exterior: resultado 1º e 2º turno", f: "v" },
      { id: "saldo-v", nome: "De onde veio a vantagem (saldo por estado)", f: "v" },
      { id: "mudou22-v", nome: "Mudou de lado desde 2022", f: "v" },
      { id: "intensidade-v", nome: "Intensidade da vitória (mapa)", f: "v" },
      { id: "concentracao-v", nome: "Concentração do voto", f: "v" },
      { id: "abst22-v", nome: "Abstenção 2º turno: 2022 × 2026", f: "v" },
      { id: "brnulos-v", nome: "Brancos e nulos: 1º × 2º turno", f: "v" },
      { id: "menosvot-v", nome: "Eleitos com menos votos (Câmara)", f: "v" },
      { id: "senvotos-v", nome: "Senado: votos por partido", f: "v" },
      { id: "gov22-v", nome: "Governadores por partido: 2022 × 2026", f: "v" },
      { id: "decisivos-v", nome: "Estados decisivos (6 maiores eleitorados)", f: "v" },
      { id: "govpres-v", nome: "Governador × Presidente no estado", f: "v" },
      { id: "perfilcamara-v", nome: "Perfil da nova Câmara", f: "v" },
      { id: "assembleia-v", nome: "Assembleia Legislativa (por estado)", f: "v" },
      { id: "assembleias-v", nome: "Assembleias — Brasil (por partido)", f: "v" },
      { id: "topdep-v", nome: "10 deputados federais mais votados", f: "v" },
      { id: "topfem-v", nome: "10 deputadas mais votadas", f: "v" },
      { id: "topsenfem-v", nome: "Senadoras eleitas", f: "v" },
      { id: "perfileleitor-v", nome: "Perfil do eleitorado", f: "v" },
      { id: "foiurnas-v", nome: "Quem foi às urnas (perfil)", f: "v" },
      { id: "governab-h", nome: "Governabilidade: a base de cada finalista", f: "h" },
      { id: "capint-h", nome: "Capital × interior (1/2)", f: "h" },
      { id: "capint2-h", nome: "Capital × interior (2/2)", f: "h" },
      { id: "transf-h", nome: "Para onde foram os votos (estimativa)", f: "h" },
      { id: "abstdec-h", nome: "A abstenção decidiu? (1/2)", f: "h" },
      { id: "abstdec2-h", nome: "A abstenção decidiu? (2/2)", f: "h" },
      { id: "definicao-h", nome: "A hora da definição", f: "h" },
      { id: "semuf-h", nome: "Sem este estado, quem venceria?", f: "h" },
      { id: "pendulo-h", nome: "Quanto cada estado se moveu (2022 → 2026)", f: "h" },
      { id: "cruzado-h", nome: "Voto cruzado: governador × presidente", f: "h" },
      { id: "perfilres-h", nome: "Perfil do eleitorado × resultado", f: "h" },
      { id: "munmapa-h", nome: "Presidente em cada cidade (mapa)", f: "h" },
      { id: "governab-v", nome: "Governabilidade: a base de cada finalista", f: "v" },
      { id: "capint-v", nome: "Capital × interior (1/2)", f: "v" },
      { id: "capint2-v", nome: "Capital × interior (2/2)", f: "v" },
      { id: "transf-v", nome: "Para onde foram os votos (estimativa)", f: "v" },
      { id: "abstdec-v", nome: "A abstenção decidiu? (1/2)", f: "v" },
      { id: "abstdec2-v", nome: "A abstenção decidiu? (2/2)", f: "v" },
      { id: "definicao-v", nome: "A hora da definição", f: "v" },
      { id: "semuf-v", nome: "Sem este estado, quem venceria?", f: "v" },
      { id: "pendulo-v", nome: "Quanto cada estado se moveu (2022 → 2026)", f: "v" },
      { id: "cruzado-v", nome: "Voto cruzado: governador × presidente", f: "v" },
      { id: "perfilres-v", nome: "Perfil do eleitorado × resultado", f: "v" },
      { id: "munmapa-v", nome: "Presidente em cada cidade (mapa)", f: "v" }
    ],
    desenhar: function (id) { return desenharTela(id); },
    temDados: function (id) { return temDados(id); },
    // Telas que trocam sozinhas (deputados): muda quando a tela da vez muda.
    pagina: function (id) {
      if (String(id).indexOf("deputados") !== 0) return "";
      var man = depManual(), sel = selecaoDep();
      if (man && !REG_DEP[man]) return "m:" + man;           // estado fixo: so troca pelo comando
      return (man || "a") + ":" + sel.pags.length + ":" + sel.ip;
    },
    // Telas dos deputados para a navegacao manual (gerenciador).
    depPaginas: function () { return paginasDeputados(true).map(function (p) { return { uf: p.uf, k: p.k, n: p.n, total: p.total }; }); },
    reiniciarPaginas: function () { T0_DEP = Date.now(); },
    ajustarSelos: ajustarSelos,
    dados: D,
    cor: cor,
    candidatos: function () { var d = D(); return d.br && d.br.tem ? candidatos(d.br) : []; }
  };
})();
